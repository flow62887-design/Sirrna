// v15.9: offline send queue, compact status strip, call history
const p=require('puppeteer-core');const sl=ms=>new Promise(r=>setTimeout(r,ms));
const T=(n,v)=>{console.log(v?'PASS':'FAIL',n);if(!v)process.exitCode=1};
const APP='file:///tmp/s/sirrna-source/android-nearby-test/app/src/main/assets/app.html';
(async()=>{const b=await p.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox','--allow-file-access-from-files'],headless:'new'});
const off={A:false};
async function mk(name){const ctx=await b.createBrowserContext();const pg=await ctx.newPage();await pg.setViewport({width:390,height:844});pg.errs=[];pg.on('pageerror',e=>pg.errs.push(e.message));
 await pg.setRequestInterception(true);pg.on('request',r=>{let u=r.url();if(name==='Alice'&&off.A&&/^https?:/.test(u))return r.abort('internetdisconnected');if(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/.test(u)||u.startsWith('https://fake-db'))return r.continue({url:u.replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/,'http://localhost:8098').replace('https://fake-db','http://localhost:8098')});r.continue()});
 await pg.goto(APP);await pg.type('#fbUrl','https://fake-db');await pg.type('#fbKey','k');await pg.type('#nm',name);await pg.click('#go');await pg.waitForFunction(()=>!document.querySelector('#home').classList.contains('hide'),{timeout:8000});return pg}
const A=await mk('Alice'),B=await mk('Bob');
const id=async q=>q.$eval('#myId',e=>e.textContent);
await A.type('#addId',await id(B));await A.click('#add');await sl(1200);await B.click('[data-a]');await sl(1500);
const fu=await A.evaluate(()=>Object.keys(JSON.parse(localStorage.sirrna_acct).friends)[0]);
// compact status strip
const sc=await A.evaluate(()=>({add:!!document.querySelector('#stc #addSt'),h:document.querySelector('#stCard').getBoundingClientRect().height,title:document.querySelector('#stCard b')}));
T('status strip has + tile, no title ('+Math.round(sc.h)+'px high)',sc.add&&!sc.title&&sc.h<90);
await A.click('#addSt');await sl(300);T('+ tile opens new-status sheet',await A.evaluate(()=>!document.querySelector('#modB')||document.querySelector('#mod').classList.contains('hide')===false));
await A.evaluate(()=>modal.close&&modal.close());
// offline send
off.A=true;
const r=await A.evaluate(async u=>{try{const m=await acct.send(u,'offline-hello');return m.st}catch(e){return 'err:'+e.message}},fu);
T('offline send does not throw, marked pending (st='+r+')',r===-1);
await A.evaluate(u=>openChat(u),fu);await sl(500);
T('pending mark shown in chat',await A.evaluate(()=>[...document.querySelectorAll('#chat .tk')].some(k=>k.textContent.includes('لسه ما اتبعتش'))));
T('Bob has not got it yet',!(await B.evaluate(()=>localStorage.sirrna_acct.includes('offline-hello'))));
T('queue persisted',await A.evaluate(()=>JSON.parse(localStorage.sirrna_acct).outbox.length===1));
await A.screenshot({path:'/tmp/qrl/f/v159-pending.png'});
off.A=false;await A.evaluate(()=>window.dispatchEvent(new Event('online')));await sl(2500);
T('delivered after internet returns',await B.evaluate(()=>localStorage.sirrna_acct.includes('offline-hello')));
T('queue empty + mark cleared',await A.evaluate(()=>JSON.parse(localStorage.sirrna_acct).outbox.length===0&&![...document.querySelectorAll('#chat .tk')].some(k=>k.textContent.includes('لسه'))));
// call history
await A.evaluate(u=>{logCall({uid:u,name:'Bob',dir:'out',secs:75});logCall({uid:u,name:'Bob',dir:'in',secs:0})},fu);
await A.evaluate(()=>{show('voice');renderVoice()});await sl(300);
const ch=await A.evaluate(()=>[...document.querySelectorAll('#vl .vrow .pv')].map(x=>x.textContent));
T('history rows: '+JSON.stringify(ch),ch.length>=3&&/01:15/.test(ch[1])&&/فايتة/.test(ch[0]));
await A.screenshot({path:'/tmp/qrl/f/v159-voice.png'});
await A.click('#clrCalls');await sl(200);T('history cleared',await A.evaluate(()=>getCalls().length===0));
console.log(A.errs.concat(B.errs).join('|')||'no page errors');
await b.close()})().catch(e=>{console.log('FAIL crash',e.message);process.exit(1)});
