// v22: replay protection, group cap, media upload retry + progress
const A = require("./accounts.js"); const assert = require("assert");
const base = (url) => url.replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/, "http://localhost:8098").replace("https://fake-db", "http://localhost:8098");
const rw = (url, o) => fetch(base(url), o);
const wait = (f, ms = 8000) => new Promise((ok, no) => { const s = Date.now(); (function p() { if (f()) return ok(); if (Date.now() - s > ms) return no(new Error("timeout " + f)); setTimeout(p, 40); })(); });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const ok = (m) => console.log("PASS", m);
function mk(fetchFn, pushUrl) { const ev = []; let data = null; const med = {};
  const pend = {};
  const store = { get: () => data, set: (d) => { data = JSON.parse(JSON.stringify(d)); }, dump: () => data, putMedia: async (k, v) => { med[k] = v; }, getMedia: async (k) => med[k], delMedia: async (k) => { delete med[k]; }, pendPut: async (v) => { pend[v.key] = v; }, listPuts: async () => Object.values(pend), delPut: async (k) => { delete pend[k]; } };
  const a = A.create((e) => ev.push(e), { databaseURL: "https://fake-db", apiKey: "k", pushUrl: pushUrl || "" }, store, fetchFn || rw); return { a, ev, store, pend }; }
(async () => {
  // ---------- 1. replay ----------
  const a = mk(), b = mk();
  await a.a.start("Alice"); await b.a.start("Bob");
  const bef = async (x, y) => { await x.a.addFriend(y.a.id); await wait(() => y.ev.some((e) => e.t === "request" && e.id === x.a.id)); await y.a.accept(y.ev.find((e) => e.t === "request" && e.id === x.a.id).uid); await wait(() => x.a.friends().find((f) => f.id === y.a.id).state === "friend"); };
  await bef(a, b);
  const ub = a.a.friends().find((f) => f.id === b.a.id).uid, ua = b.a.friends().find((f) => f.id === a.a.id).uid;
  b.a.stop(); await sleep(300);                       // Bob offline: the envelope waits in his inbox
  const sent = await a.a.send(ub, "one");
  await wait(() => true); await sleep(600);
  const q = await (await fetch(base(`https://fake-db/inbox/${ub}/q.json?auth=t`))).json();
  const env = Object.values(q || {})[0];
  assert(env && env.d && env.f, "captured the sealed envelope");
  await b.a.start("Bob");
  await wait(() => b.a.messages(ua).some((m) => m.t === "one"));
  assert.equal(b.a.messages(ua).filter((m) => m.i === sent.i).length, 1); ok("message delivered once");
  // replay the exact same sealed envelope into the inbox
  await fetch(base(`https://fake-db/inbox/${ub}/q?auth=t`), { method: "POST", body: JSON.stringify(env) });
  await sleep(1500);
  assert.equal(b.a.messages(ua).filter((m) => m.i === sent.i).length, 1); ok("replayed envelope dropped (no duplicate)");
  assert.equal(b.a.messages(ua).filter((m) => m.t === "one").length, 1); ok("replay did not add a second bubble");
  await a.a.send(ub, "two");
  await wait(() => b.a.messages(ua).some((m) => m.t === "two")); ok("a fresh message still arrives after a replay");

  // ---------- 2. group cap ----------
  assert.equal(a.a.maxGroup(), 30); ok("declared group cap is 30");
  const peers = [];
  const clearReq = () => a.store.set(Object.assign({}, a.store.dump(), { reqOut: [] }));
  for (let i = 0; i < 30; i++) { const p = mk(); await p.a.start("P" + i); peers.push(p); clearReq(); await bef(a, p); }
  const pids = peers.map((p) => a.a.friends().find((f) => f.id === p.a.id).uid);
  let big = ""; try { await a.a.createGroup("too big", pids); } catch (e) { big = e.message; }
  assert(/٣٠/.test(big), "expected the cap error, got: " + big); ok("creating a group with 30 friends (31 people) is refused");
  const g = await a.a.createGroup("team", pids.slice(0, 29)); ok("a group with 29 friends (30 people) is created");
  const gid = g.slice(2);
  assert.equal(Object.keys(a.a.groups().find((x) => x.chat === g).members).length, 30); ok("group holds exactly 30 members");
  let add = ""; try { await a.a.addMember(g, pids[29]); } catch (e) { add = e.message; }
  assert(/الحد/.test(add), "expected the add error, got: " + add); ok("adding a 31st member is refused");

  // ---------- 3. upload retry + progress ----------
  const puts = []; const progress = [];
  const flaky = (url, o) => {
    const u = String(url);
    if (u.indexOf("fake-worker.local/media/") >= 0) {
      puts.push((o && o.method) || "GET");
      if (puts.length < 3) return Promise.reject(new TypeError("Failed to fetch"));   // two network failures
      return Promise.resolve(new Response("", { status: 200 }));
    }
    return rw(url, o);
  };
  const e2 = mk(flaky, "https://fake-worker.local/notify"); await e2.a.start("Eve");
  const e2b = mk(flaky);
  await e2b.a.start("Fay"); await bef(e2, e2b);
  const uf = e2.a.friends().find((f) => f.id === e2b.a.id).uid;
  const buf = new Uint8Array(4000).buffer;
  const msg = await e2.a.sendFile(uf, "video/mp4", "clip.mp4", buf, (p, at) => progress.push([p, at]));
  assert.equal(puts.length, 3); ok("upload retried twice, then succeeded (3 PUTs)");
  assert(msg && msg.k === "r2" && msg.sz === 4000); ok("large media message created after the retry");
  assert(progress.some((p) => p[0] === -1)); ok("progress callback reported the retry");

  // permanent error: no retry
  const puts2 = [];
  const off = (url, o) => { const u = String(url); if (u.indexOf("fake-worker.local/media/") >= 0) { puts2.push(1); return Promise.resolve(new Response("", { status: 501 })); } return rw(url, o); };
  const e3 = mk(off, "https://fake-worker.local/notify"); await e3.a.start("Gina");
  const e4 = mk(off); await e4.a.start("Hal"); await bef(e3, e4);
  const u3 = e3.a.friends().find((f) => f.id === e4.a.id).uid;
  let m3 = ""; try { await e3.a.sendFile(u3, "video/mp4", "x.mp4", new Uint8Array(10).buffer, () => {}); } catch (e) { m3 = e.message; }
  assert.equal(m3, "r2_off"); assert.equal(puts2.length, 1); ok("501 (R2 not bound) fails fast with r2_off, no retries");

  // ---------- 3b. upload survives a dead network (resume later) ----------
  let dead = true; const tries = [];
  const sw = (url, o) => { const u = String(url); if (u.indexOf("fake-worker.local/media/") >= 0) { tries.push(1); return dead ? Promise.reject(new TypeError("Failed to fetch")) : Promise.resolve(new Response("", { status: 200 })); } return rw(url, o); };
  const pr1 = mk(sw, "https://fake-worker.local/notify"); await pr1.a.start("Rana");
  const pr2 = mk(sw); await pr2.a.start("Sami"); await bef(pr1, pr2);
  const ur = pr1.a.friends().find((f) => f.id === pr2.a.id).uid;
  let perr = ""; try { await pr1.a.sendFile(ur, "video/mp4", "big.mp4", new Uint8Array(5000).buffer, () => {}); } catch (e) { perr = e.message; }
  assert(/النت قطع/.test(perr), "expected the pending message, got: " + perr);
  assert.equal(Object.keys(pr1.pend).length, 1); assert.equal(tries.length, 3); ok("a dead network keeps the encrypted file on the phone (3 tries, then parked)");
  dead = false;
  const n = await pr1.a.retryPending();
  assert.equal(n, 1); assert.equal(Object.keys(pr1.pend).length, 0);
  const sentNow = pr1.a.messages(ur).filter((m) => m.k === "r2" && m.sz === 5000);
  assert.equal(sentNow.length, 1); ok("when the net comes back the parked file uploads and the message appears once");
  const n2 = await pr1.a.retryPending(); assert.equal(n2, 0); ok("the queue is empty afterwards (no duplicate sends)");

  // ---------- 4. search filters ----------
  await a.a.send(ub, "شوف اللينك https://example.com/x");
  await wait(() => b.a.messages(ua).some((m) => /example\.com/.test(m.t)));
  const all = a.a.searchMessages("شوف");
  const links = a.a.searchMessages("example", { type: "links" });
  const texts = a.a.searchMessages("example", { type: "text" });
  assert(all.length >= 1); assert(links.length === 1); assert(texts.length === 1);
  assert(a.a.searchMessages("شوف", { type: "media" }).length === 0); ok("search filters: links / text / media");

  // ---------- 5. repeat request to the same stranger is not re-sent ----------
  const st1 = mk(); await st1.a.start("Stranger");
  const r1 = await a.a.addFriend(st1.a.id);
  await wait(() => st1.ev.some((e) => e.t === "request"));
  const r2 = await a.a.addFriend(st1.a.id);
  await sleep(400);
  assert.equal(r1, "sent"); assert.equal(r2, "pending");
  assert.equal(st1.ev.filter((e) => e.t === "request").length, 1); ok("a repeated request to the same person is not sent twice");

  console.log("ALL v22 TESTS DONE");
  process.exit(0);
})().catch((e) => { console.error("FAIL", e.message); process.exit(1); });
