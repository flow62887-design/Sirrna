// v17: message tones play on the Android notification stream (native Sounds), not the media stream; WebAudio stays as browser fallback
const p=require('puppeteer-core');const sl=ms=>new Promise(r=>setTimeout(r,ms));const fs=require('fs');
const T=(n,v)=>{console.log(v?'PASS':'FAIL',n);if(!v)process.exitCode=1};
const SRC='/tmp/s/sirrna-source/android-nearby-test/app/src/';
const JS=fs.readFileSync(SRC+'main/assets/app.html','utf8');
const SJ=fs.readFileSync(SRC+'main/java/app/sirrna/nearby/Sounds.java','utf8');
const HUB=fs.readFileSync(SRC+'main/java/app/sirrna/nearby/Hub.java','utf8');
// static checks
T('Sounds.java plays on notification stream',/USAGE_NOTIFICATION/.test(SJ));
T('silent mode: no sound',/RINGER_MODE_SILENT/.test(SJ));
T('vibrate mode: vibrates instead',/RINGER_MODE_VIBRATE/.test(SJ)&&/vibrate\(/.test(SJ));
T('Hub exposes playTone to JS',/@JavascriptInterface\s+public void playTone/.test(HUB));
T('same 4 tones in Java and JS',(()=>{
 const TONES=eval('({'+JS.match(/TONES=\{([^}]*)\}/)[1]+'})');
 const jv=n=>TONES[n].map(x=>x[0]+','+x[1]).join(';');
 const gv=n=>{const m=SJ.match(new RegExp(n.toUpperCase()+'\\s*=\\s*(\\{\\{[^;]*?\\}\\});'));return m?[...m[1].matchAll(/\{\s*(\d+)\s*,\s*(\.\d+)f\s*\}/g)].map(x=>x[1]+','+parseFloat(x[2])).join(';'):''};
 return ['ding','pop','chime','drop'].every(n=>{const a=jv(n),b=gv(n);if(a!==b)console.log(' mismatch',n,a,b);return a&&a===b})})());
const i0=JS.indexOf('function playTone');const pt=i0>-1?JS.slice(i0,i0+700):'';
T('JS prefers native bridge, WebAudio fallback kept',pt.indexOf('Nearby.playTone')>-1&&pt.indexOf('Nearby.playTone')<pt.indexOf('AudioContext'));
(async()=>{
const b=await p.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox','--allow-file-access-from-files','--autoplay-policy=no-user-gesture-required'],headless:'new'});
// 1) with the Android bridge mocked: tones must go native
const pg=await b.newPage();pg.errs=[];pg.on('pageerror',e=>pg.errs.push(e.message));
await pg.evaluateOnNewDocument(()=>{window.__tones=[];window.Nearby={playTone(k){window.__tones.push(k)}}});
await pg.goto('file://'+SRC+'main/assets/app.html');await sl(1500);
await pg.evaluate(()=>playTone('chime'));
T('tone goes to native bridge when present',await pg.evaluate(()=>window.__tones.join()==='chime'));
await pg.evaluate(()=>window.__v15({t:'message',uid:'u1',name:'اختبار',kind:'text',text:'أهلًا'}));
T('incoming message plays its default tone natively (ding)',await pg.evaluate(()=>window.__tones.join()==='chime,ding'));
await pg.evaluate(()=>{SET.snd.u2='pop';window.__v15({t:'message',uid:'u2',name:'تاني',kind:'text',text:'x'})});
T('per-chat tone choice respected (pop)',await pg.evaluate(()=>window.__tones.join()==='chime,ding,pop'));
await pg.evaluate(()=>playTone('none'));
T('"بدون صوت" plays nothing',await pg.evaluate(()=>window.__tones.length===3));
T('no page errors with bridge',pg.errs.length===0);
// 2) without the bridge (plain browser): WebAudio fallback must still work
const pg2=await b.newPage();pg2.errs=[];pg2.on('pageerror',e=>pg2.errs.push(e.message));
await pg2.evaluateOnNewDocument(()=>{window.__ac=0;const O=window.AudioContext||window.webkitAudioContext;window.AudioContext=window.webkitAudioContext=function(){window.__ac++;return new O()}});
await pg2.goto('file://'+SRC+'main/assets/app.html');await sl(1500);
await pg2.evaluate(()=>playTone('ding'));
T('WebAudio fallback in browser (no bridge)',await pg2.evaluate(()=>window.__ac===1));
T('no page errors without bridge',pg2.errs.length===0);
await b.close()})()
