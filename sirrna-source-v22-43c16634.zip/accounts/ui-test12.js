// v16: IBM Plex Sans Arabic bundled offline; used everywhere; OFL in About
const p=require('puppeteer-core');const sl=ms=>new Promise(r=>setTimeout(r,ms));const fs=require('fs');
const T=(n,v)=>{console.log(v?'PASS':'FAIL',n);if(!v)process.exitCode=1};
const AS='/tmp/s/sirrna-source/android-nearby-test/app/src/main/assets/';
(async()=>{T('font files bundled',fs.existsSync(AS+'fonts/IBMPlexSansArabic-Regular.ttf')&&fs.existsSync(AS+'fonts/IBMPlexSansArabic-Bold.ttf')&&fs.existsSync(AS+'fonts/OFL.txt'));
const b=await p.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox','--allow-file-access-from-files'],headless:'new'});
const reqs=[];const g=await b.newPage();g.on('request',r=>{if(/^https?:/.test(r.url()))reqs.push(r.url())});g.errs=[];g.on('pageerror',e=>g.errs.push(e.message));
await g.goto('file://'+AS+'app.html');await sl(1500);
await g.evaluate(()=>document.fonts.load('16px Plex','ا'));await g.evaluate(()=>document.fonts.load('bold 16px Plex','ا'));await sl(500);
const r=await g.evaluate(()=>({loaded:[...document.fonts].filter(f=>f.status==='loaded').map(f=>f.family+' '+f.weight),body:getComputedStyle(document.body).fontFamily,btn:getComputedStyle(document.querySelector('button')).fontFamily,inp:getComputedStyle(document.querySelector('input')).fontFamily,sel:getComputedStyle(document.querySelector('select')).fontFamily,digits:document.fonts.check('16px Plex','0123456789')}));
console.log(JSON.stringify(r));
T('Regular+Bold loaded',r.loaded.filter(x=>/Plex/.test(x)).length>=2);
T('body/button/input/select use Plex',[r.body,r.btn,r.inp,r.sel].every(x=>/Plex/.test(x)));
T('digits covered by Plex',r.digits);
T('no network font requests',reqs.length===0);
T('OFL in About',await g.evaluate(()=>/SIL OPEN FONT LICENSE/i.test(document.body.textContent)&&/IBM Plex Sans Arabic/.test(document.body.textContent)));
T('no page errors',g.errs.length===0);
await b.close()})()
