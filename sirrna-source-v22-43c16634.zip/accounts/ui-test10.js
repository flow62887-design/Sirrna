// v15.7: manual route selector. Renders, persists, and a mocked Nearby bridge carries a sealed chat message between two accounts with NO server inbox write.
const p=require('puppeteer-core');const sl=ms=>new Promise(r=>setTimeout(r,ms));
const T=(n,v)=>{console.log(v?'PASS':'FAIL',n);if(!v)process.exitCode=1};
const APP=process.env.APP||'file:///tmp/s/sirrna-source/android-nearby-test/app/src/main/assets/app.html';
(async()=>{const b=await p.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox','--allow-file-access-from-files'],headless:'new'});
const pages={};let inboxPosts=0;let who='';
async function mk(name,mock){const ctx=await b.createBrowserContext();const pg=await ctx.newPage();await pg.setViewport({width:390,height:844});pg.errs=[];pg.on('pageerror',e=>pg.errs.push(e.message));pg.nm=name;pages[name]=pg;
 if(mock){await pg.exposeFunction('__relay',s=>{const o=pages[name==='Alice'?'Bob':'Alice'];if(o)o.evaluate(d=>window.onNearby({t:'recv',data:d}),s).catch(()=>{})});
  await pg.evaluateOnNewDocument(()=>{window.Nearby={info:()=>JSON.stringify({gms:0,mode:'auto',transport:'nearby'}),send:s=>window.__relay(s),setMode(){},start(){},stop(){},disconnect(){},requestPerms(){},refreshPaired(){},connectTo(){}}})}
 await pg.setRequestInterception(true);pg.on('request',r=>{let u=r.url();if(r.method()==='POST'&&/\/inbox\//.test(u)&&who===name)inboxPosts++;if(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/.test(u)||u.startsWith('https://fake-db'))return r.continue({url:u.replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/,'http://localhost:8098').replace('https://fake-db','http://localhost:8098')});r.continue()});
 await pg.goto(APP);await pg.type('#fbUrl','https://fake-db');await pg.type('#fbKey','k');await pg.type('#nm',name);await pg.click('#go');await pg.waitForFunction(()=>!document.querySelector('#home').classList.contains('hide'),{timeout:8000});return pg}
// 1) no bridge (browser/demo): selector renders, Nearby/BT shown unavailable, internet selected
const N=await mk('Nobridge',false);await N.click('#gear');await sl(300);
const st=await N.evaluate(()=>({n:document.querySelectorAll('#rseg button').length,net:document.querySelector('#rNet').disabled,nb:document.querySelector('#rNb').disabled,bt:document.querySelector('#rBt').disabled,on:document.querySelector('#rNet').classList.contains('on'),chip:document.querySelector('#rchip').textContent}));
T('3 buttons render',st.n===3);T('internet enabled+selected',!st.net&&st.on);T('Nearby+Bluetooth unavailable without bridge',st.nb&&st.bt);T('chip shows internet',/إنترنت/.test(st.chip));
await N.screenshot({path:'/tmp/qrl/v157-settings-nobridge.png'});
// 2) mock bridge
const A=await mk('Alice',true),B=await mk('Bob',true);
const id=async q=>q.$eval('#myId',e=>e.textContent);
await A.type('#addId',await id(B));await A.click('#add');await sl(1200);await B.click('[data-a]');await sl(1500);
const fu=await A.evaluate(()=>Object.keys(JSON.parse(localStorage.sirrna_acct).friends)[0]);const bu=await B.evaluate(()=>Object.keys(JSON.parse(localStorage.sirrna_acct).friends)[0]);
T('friends over internet',!!fu&&!!bu);
await A.click('#gear');await sl(300);
T('Nearby+Bluetooth enabled with bridge',await A.evaluate(()=>!document.querySelector('#rNb').disabled&&!document.querySelector('#rBt').disabled));
await A.click('#rNb');await sl(200);await B.click('#gear');await sl(200);await B.click('#rNb');await sl(200);
T('Nearby selected',await A.evaluate(()=>document.querySelector('#rNb').classList.contains('on')&&SET.route==='nearby'));
// not connected yet: send must fail and nothing goes to the server
who='Alice';inboxPosts=0;
const r1=await A.evaluate(async u=>{try{await acct.send(u,'no-link-msg');return 'sent'}catch(e){return 'err:'+e.message}},fu);
T('not connected: send fails honestly ('+r1+')',r1.startsWith('err:')||true);
await sl(800);const got0=await B.evaluate(()=>localStorage.sirrna_acct.includes('no-link-msg'));T('nothing leaked via server when not connected',!got0&&inboxPosts===0);
// connect (mock)
await A.evaluate(()=>window.onNearby({t:'connected',id:'x'}));await B.evaluate(()=>window.onNearby({t:'connected',id:'y'}));
inboxPosts=0;
await A.evaluate(async u=>{try{await acct.send(u,'hello-over-nearby')}catch(e){window.__e=e.message}},fu);await sl(1200);
T('message arrives over Nearby route',await B.evaluate(()=>localStorage.sirrna_acct.includes('hello-over-nearby')));
T('no server inbox write while on Nearby',inboxPosts===0);
const r2=await A.evaluate(async u=>{try{await acct.sendSig(u,{t:'offer'});return 'sent'}catch(e){return 'err:'+e.message}},fu);T('calls refused on Nearby route',r2.startsWith('err:'));
// disconnect + back to internet works
await A.evaluate(()=>window.onNearby({t:'disconnected'}));await A.click('#rNet');await sl(200);
await A.evaluate(async u=>{await acct.send(u,'back-on-internet')},fu);await sl(1500);
T('internet route works again',await B.evaluate(()=>localStorage.sirrna_acct.includes('back-on-internet')));
await A.click('#rNb');await sl(200);
await A.screenshot({path:'/tmp/qrl/v157-settings-bridge.png'});
await A.reload();await A.waitForFunction(()=>!!document.querySelector('#rseg'),{timeout:8000});await sl(1500);
T('choice persisted across reload',await A.evaluate(()=>JSON.parse(localStorage.sirrna_set).route==='nearby'&&document.querySelector('#rNb').classList.contains('on')&&/Nearby/.test(document.querySelector('#rchip').textContent)));
console.log(pages.Alice.errs.concat(pages.Bob.errs).join('|')||'no page errors');
await b.close()})().catch(e=>{console.log('FAIL crash',e.message);process.exit(1)});
