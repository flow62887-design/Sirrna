#!/bin/sh
# Compiles all Java sources against Android 14 (API 34) + Play Services/Firebase jars. Proves: syntax and types/symbols resolve. Does NOT prove: Gradle config, manifest merge, runtime behaviour.
cd "$(dirname "$0")/../android-nearby-test/app/src" || exit 1
CP=/tmp/jc/android-all.jar:$(ls /tmp/jc/x/*.jar | tr '\n' ':')
rm -rf /tmp/jc/out && mkdir /tmp/jc/out
/tmp/jc/j17/bin/javac -encoding UTF-8 -proc:none -Xlint:-options -source 8 -target 8 -cp "$CP" -d /tmp/jc/out main/java/app/sirrna/nearby/*.java fcm/java/app/sirrna/nearby/*.java 2>&1
echo "javac exit: $?"
