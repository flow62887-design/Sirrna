# سرّنا: الكود المصدري

## الفولدرات
- `android-nearby-test/` مشروع أندرويد (Gradle) لتجربة الاتصال القريب بدون إنترنت.
  - `app/src/main/java/app/sirrna/nearby/MainActivity.java`: بيفتح WebView ويحمّل الواجهة.
  - `Hub.java`: بيختار طريقة الاتصال. Nearby لو Google Play services سليمة، وإلا بلوتوث. وفيه خيار إجبار البلوتوث.
  - `NearbyBridge.java`: الاتصال عن طريق Google Nearby Connections.
  - `BtBridge.java`: الاتصال عن طريق بلوتوث RFCOMM (للموبايلات من غير Google، زي الهواوي).
  - `app/src/main/assets/index.html`: شاشة التجربة (HTML/JS) فيها فحص الموبايل وكود الأمان (PIN) والرسايل والـ Ping.
  - `app/src/main/AndroidManifest.xml`: التصاريح.
  - `mock-test-nt.js`: اختبار في الكروم بموبايلين وهميين (محتاج puppeteer-core).
- `full-ui/index.html`: الواجهة الكاملة (النسخة v5، ملف واحد، بيانات تجريبية ومحلية). النسخة دي لسه مش موصولة بالاتصال القريب ولا Firebase.

## البناء
محتاج JDK 17 وأندرويد SDK 34 (build-tools 34.0.0) وGradle 8.7.
1. اعمل ملف `local.properties` فيه سطر: `sdk.dir=مسار الـ SDK`.
2. شغّل: `gradle assembleDebug`
3. الـ APK هيطلع في `app/build/outputs/apk/debug/app-debug.apk`.

## ملاحظات
- كود الأمان بيتأكد إن الطرف التاني يعرف الكود (HMAC-SHA256 على الـ JS). ده مش تشفير end-to-end.
- Nearby والبلوتوث مش بيتكلموا مع بعض: الموبايلين لازم يستخدموا نفس الطريقة.
- الكود ده لسه ما اتجرّبش على موبايلات حقيقية بالكامل (Nearby اتجرّب مرة وطلع إن Google Play services على الهواوي مش أصلية).
