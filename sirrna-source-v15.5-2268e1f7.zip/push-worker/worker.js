/* Sirrna push sender: a free Cloudflare Worker (or any JS runtime with fetch + WebCrypto).
   POST /notify  Authorization: Bearer <sender's Firebase ID token>  {"to":"<recipient uid>","k":"msg"|"call"}
   - verifies the Firebase ID token (RS256, Google's public keys), so only signed-in Sirrna users can use it
   - reads the recipient's FCM token from your Realtime Database (/push/<uid>, using the sender's own token)
   - sends a DATA-ONLY FCM message {k}. No text, no names, no IDs ever pass through here.
   Variables to set in Cloudflare: FB_PROJECT_ID, DB_URL (plain), SA_JSON (secret: the service-account JSON from Firebase). */
const b64u = (u) => btoa(String.fromCharCode(...new Uint8Array(u))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const unb64u = (s) => Uint8Array.from(atob(s.replace(/-/g, "+").replace(/_/g, "/")), (c) => c.charCodeAt(0));
const J = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", "access-control-allow-origin": "*", "access-control-allow-headers": "authorization,content-type" } });
let jwks = null, jwksAt = 0, access = null, accessExp = 0; const hits = new Map();

async function verify(idToken, env) {
  const [h, p, s] = String(idToken).split("."); if (!h || !p || !s) throw new Error("bad token");
  const head = JSON.parse(new TextDecoder().decode(unb64u(h))), pay = JSON.parse(new TextDecoder().decode(unb64u(p)));
  if (head.alg !== "RS256") throw new Error("alg");
  if (!jwks || Date.now() - jwksAt > 3600e3) { const r = await fetch("https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com"); if (!r.ok) throw new Error("jwks"); jwks = (await r.json()).keys; jwksAt = Date.now(); }
  const jwk = jwks.find((k) => k.kid === head.kid); if (!jwk) throw new Error("kid");
  const key = await crypto.subtle.importKey("jwk", jwk, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]);
  if (!(await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, unb64u(s), new TextEncoder().encode(h + "." + p)))) throw new Error("sig");
  const now = Math.floor(Date.now() / 1000);
  if (pay.aud !== env.FB_PROJECT_ID || pay.iss !== "https://securetoken.google.com/" + env.FB_PROJECT_ID || !pay.sub || pay.exp < now || pay.iat > now + 300) throw new Error("claims");
  return pay.sub;
}
async function fcmAccess(env) {
  if (access && Date.now() < accessExp - 60e3) return access;
  const sa = JSON.parse(env.SA_JSON), now = Math.floor(Date.now() / 1000);
  const hd = b64u(new TextEncoder().encode(JSON.stringify({ alg: "RS256", typ: "JWT" })));
  const cl = b64u(new TextEncoder().encode(JSON.stringify({ iss: sa.client_email, scope: "https://www.googleapis.com/auth/firebase.messaging", aud: "https://oauth2.googleapis.com/token", iat: now, exp: now + 3600 })));
  const pem = sa.private_key.replace(/-----[A-Z ]+-----/g, "").replace(/\s+/g, "");
  const key = await crypto.subtle.importKey("pkcs8", Uint8Array.from(atob(pem), (c) => c.charCodeAt(0)), { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
  const sig = b64u(await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(hd + "." + cl)));
  const r = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: "grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=" + hd + "." + cl + "." + sig });
  if (!r.ok) throw new Error("oauth " + r.status); const j = await r.json(); access = j.access_token; accessExp = Date.now() + (j.expires_in || 3600) * 1000; return access;
}
export default {
  async fetch(req, env) {
    if (req.method === "OPTIONS") return J({});
    if (req.method !== "POST" || new URL(req.url).pathname !== "/notify") return J({ error: "not found" }, 404);
    let sender; const idt = (req.headers.get("authorization") || "").replace(/^Bearer /, "");
    try { sender = await verify(idt, env); } catch (e) { return J({ error: "unauthorized" }, 401); }
    let b; try { b = await req.json(); } catch (e) { return J({ error: "bad json" }, 400); }
    if (!b || typeof b.to !== "string" || !/^[A-Za-z0-9]{20,40}$/.test(b.to) || (b.k !== "msg" && b.k !== "call")) return J({ error: "bad request" }, 400);
    const w = Math.floor(Date.now() / 60000), hk = sender + ":" + w; const n = (hits.get(hk) || 0) + 1; hits.set(hk, n); if (hits.size > 5000) hits.clear();
    if (n > 40) return J({ error: "slow down" }, 429); // best effort per-isolate limit, not a guarantee
    const tr = await fetch(env.DB_URL.replace(/\/$/, "") + "/push/" + b.to + ".json?auth=" + encodeURIComponent(idt));
    const rec = tr.ok ? await tr.json() : null; if (!rec || !rec.t) return J({ ok: false, why: "no token" }, 200);
    const at = await fcmAccess(env);
    const r = await fetch("https://fcm.googleapis.com/v1/projects/" + env.FB_PROJECT_ID + "/messages:send", { method: "POST", headers: { authorization: "Bearer " + at, "content-type": "application/json" },
      body: JSON.stringify({ message: { token: rec.t, data: { k: b.k }, android: { priority: "HIGH", ttl: b.k === "call" ? "45s" : "86400s" } } }) });
    return J({ ok: r.ok, status: r.status }, 200);
  },
};
