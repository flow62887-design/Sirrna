import w from "./worker.js"; import assert from "node:assert"; import { generateKeyPairSync, createSign } from "node:crypto";
const ok=(m)=>console.log("PASS",m);
const kp=await crypto.subtle.generateKey({name:"RSASSA-PKCS1-v1_5",modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:"SHA-256"},true,["sign","verify"]);
const pubJwk={...(await crypto.subtle.exportKey("jwk",kp.publicKey)),kid:"k1",alg:"RS256"};
const sa=generateKeyPairSync("rsa",{modulusLength:2048}); const saPem=sa.privateKey.export({type:"pkcs8",format:"pem"});
const env={FB_PROJECT_ID:"proj",DB_URL:"https://db.example",SA_JSON:JSON.stringify({client_email:"x@y",private_key:saPem})};
const b64u=(u)=>Buffer.from(u).toString("base64url");
async function tok(over={},kid="k1"){const now=Math.floor(Date.now()/1000);const h=b64u(JSON.stringify({alg:"RS256",kid}));const p=b64u(JSON.stringify({aud:"proj",iss:"https://securetoken.google.com/proj",sub:"S".repeat(28),iat:now,exp:now+3600,...over}));const s=b64u(await crypto.subtle.sign("RSASSA-PKCS1-v1_5",kp.privateKey,new TextEncoder().encode(h+"."+p)));return h+"."+p+"."+s}
let fcmBody=null,dbAuth=null,calls=0;
globalThis.fetch=async(u,o={})=>{u=String(u);
 if(u.includes("/jwk/"))return new Response(JSON.stringify({keys:[pubJwk]}));
 if(u.startsWith("https://db.example/push/")){dbAuth=u;return new Response(JSON.stringify(u.includes("NOTOKEN")?null:{t:"devicetoken123"}))}
 if(u.includes("oauth2.googleapis.com")){assert(o.body.includes("assertion="));return new Response(JSON.stringify({access_token:"AT",expires_in:3600}))}
 if(u.includes("fcm.googleapis.com")){calls++;fcmBody=JSON.parse(o.body);assert.equal(o.headers.authorization,"Bearer AT");return new Response("{}",{status:200})}
 throw new Error("unexpected "+u)};
const call=async(t,body,method="POST")=>w.fetch(new Request("https://w.example/notify",{method,headers:{authorization:"Bearer "+t,"content-type":"application/json"},body:method==="POST"?JSON.stringify(body):undefined}),env);
const to="R".repeat(28);
let r=await call(await tok(),{to,k:"call"});let j=await r.json();assert(j.ok&&j.status===200);ok("valid token: FCM sent");
assert.deepEqual(fcmBody.message.data,{k:"call"});assert.equal(fcmBody.message.token,"devicetoken123");assert.equal(fcmBody.message.android.priority,"HIGH");assert.equal(fcmBody.message.android.ttl,"45s");assert(!JSON.stringify(fcmBody).match(/notification|title|body|text/));ok("payload is data-only {k}, high priority, no content fields");
assert(dbAuth.includes("auth="));ok("token read with the sender's own ID token");
assert.equal((await call("bad.token.here",{to,k:"msg"})).status,401);ok("garbage token rejected");
assert.equal((await call(await tok({exp:1}),{to,k:"msg"})).status,401);ok("expired token rejected");
assert.equal((await call(await tok({aud:"other"}),{to,k:"msg"})).status,401);ok("token for another project rejected");
const forged=(await tok()).split(".");forged[1]=b64u(JSON.stringify({aud:"proj",iss:"https://securetoken.google.com/proj",sub:"EVIL".repeat(7),iat:1,exp:9999999999}));assert.equal((await call(forged.join("."),{to,k:"msg"})).status,401);ok("forged payload (bad signature) rejected");
assert.equal((await call(await tok(),{to,k:"text-with-secret"})).status,400);assert.equal((await call(await tok(),{to:"../x",k:"msg"})).status,400);ok("bad kind / bad uid rejected");
const before=calls;j=await (await call(await tok(),{to:"NOTOKEN"+"X".repeat(20),k:"msg"})).json();assert(!j.ok&&calls===before);ok("recipient without token: nothing sent");
assert.equal((await call(await tok(),null,"GET")).status,404);ok("GET not allowed");
let last;for(let i=0;i<45;i++)last=await call(await tok({sub:"L".repeat(28)}),{to,k:"msg"});assert.equal(last.status,429);ok("rate limit kicks in");
