# صفحة روابط الدعوة (GitHub Pages، مجاني)
**مهم:** GitHub Pages المجاني بيشتغل مع ريبو **عام** بس (الريبو الخاص محتاج اشتراك). عشان كده اعمل ريبو **عام تاني** صغير (مثلًا `sirrna-site`) فيه الملف `i.html` ده بس. مفيش فيه أي سر ولا كود التطبيق.
1. GitHub ← New repository ← اسمه `sirrna-site` ← Public ← Create.
2. Add file ← Upload files ← ارفع `i.html` ← Commit.
3. Settings ← Pages ← Source: "Deploy from a branch" ← Branch: `main` / folder `/ (root)` ← Save. بعد دقيقة الصفحة بتبقى على `https://USERNAME.github.io/sirrna-site/i.html`.
4. (اختياري) عشان زرار تنزيل الـ APK: Releases ← Draft a new release ← ارفع ملف الـ APK ← Publish ← انسخ لينك الملف ← افتح `i.html` للتعديل وحطه في `APK_URL`.
5. في سرّنا: الإعدادات ← "رابط صفحة الدعوة" ← الصق `https://USERNAME.github.io/sirrna-site` ← من بعدها روابط الدعوة (أصدقاء ومجموعات) بتبقى https وبتتبعت في أي شات.
**اللي بتعمله الصفحة:** بتفتح سرّنا لو مثبّت (على كروم أندرويد)، ولو مش مثبّت بتودّي لتنزيل الـ APK. **غير مجرّبة على موبايل حقيقي** (الـ intent link بيشتغل على كروم؛ المتصفحات التانية ممكن تعرض الزرار بس).
