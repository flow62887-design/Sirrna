#!/usr/bin/env bash
# Runs inside the emulator job (adb is already connected to the booted emulator).
API="$1"; OUT="emu/out-$API"; mkdir -p "$OUT"
adb install -r apk/app-debug.apk || { echo "install failed" ; adb logcat -d > "$OUT/logcat.txt"; exit 1; }
adb logcat -c
( cd emu && OUT="../$OUT/shots" node cdp-smoke.js ) 2>&1 | tee "$OUT/smoke.log"
RC=${PIPESTATUS[0]}
adb logcat -d > "$OUT/logcat.txt"
adb shell getprop ro.build.version.release > "$OUT/android-version.txt"
exit $RC
