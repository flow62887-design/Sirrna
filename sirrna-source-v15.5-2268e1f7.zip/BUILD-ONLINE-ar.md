# بناء الـ APK أونلاين مجانًا (GitHub Actions)
1. اعمل حساب GitHub مجاني وريبو **خاص** جديد (اسمه sirrna مثلًا).
2. ارفع محتوى فولدر sirrna-source كله (المجلدات android-nearby-test وaccounts وonline وفولدر .github المخفي) في جذر الريبو. لو الرفع من المتصفح مش بيرفع الفولدرات المخفية، اعمل الملف .github/workflows/build-apk.yml من زر Add file > Create new file والصق محتواه.
3. تبويب Actions > "Build Sirrna APK" > Run workflow. بعد حوالي ٥ إلى ١٠ دقايق افتح التشغيل ونزّل الـ artifact اسمه sirrna-apk (فيه app-debug.apk).
4. مفتاح توقيع ثابت (عشان التحديثات تتثبت فوق بعض من غير مسح): اعمل مفتاح مرة واحدة، وحطه في Settings > Secrets and variables > Actions باسم KEYSTORE_B64 (الملف بعد base64) وKEYSTORE_PASS. من غيرهم كل بناء بيطلع بمفتاح مؤقت مختلف، فلازم تمسح النسخة القديمة قبل ما تثبت الجديدة. المفتاح وكلمة السر ما تتبعتش في الشات.
   أمر عمل المفتاح (على أي كمبيوتر فيه Java): keytool -genkeypair -v -keystore sirrna.jks -alias sirrna -keyalg RSA -keysize 2048 -validity 10000   ثم   base64 -w0 sirrna.jks
5. الباقة المجانية للريبوهات الخاصة فيها دقايق كفاية لبناء كل فترة. مفيش كارت مطلوب في الحساب المجاني على حد علمي، لكن ما اتأكدتش من التسجيل في مصر.
