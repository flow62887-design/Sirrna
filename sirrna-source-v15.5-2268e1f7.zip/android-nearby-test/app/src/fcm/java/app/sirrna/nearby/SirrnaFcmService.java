package app.sirrna.nearby;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

/** Compiled only when app/google-services.json exists (see app/build.gradle). Data-only push, no content: k=msg or k=call. */
public class SirrnaFcmService extends FirebaseMessagingService {
    @Override
    public void onNewToken(String token) {
        Notif.saveToken(this, token);
    }

    @Override
    public void onMessageReceived(RemoteMessage m) {
        Map<String, String> d = m.getData();
        String k = d == null ? null : d.get("k");
        if ("call".equals(k)) Notif.showCall(this);
        else if ("msg".equals(k)) Notif.showMsg(this);
    }
}
