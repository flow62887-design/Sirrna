/* Sirrna DEMO mode. Everything here runs inside the app, offline. NOTHING leaves the phone.
   - an in-page fake of the Firebase REST + SSE protocol (same shape the app already speaks)
   - simulated friends are real SirrnaAccounts instances talking to Bob's instance through that fake,
     so messages, receipts, polls, groups, view-once and reactions go through the real app code.
   What is simulated: the people, their replies, voice notes (a synthetic tone, not speech), the call (UI only, no audio).
   Data is reset on every launch. */
(function(){
if(!window.SIRRNA_DEMO)return;
const HOST="https://demo.local";
["sirrna_acct","sirrna_pins","sirrna_mute","sirrna.dr"].forEach(k=>localStorage.removeItem(k));
localStorage.setItem("sirrna_cfg",JSON.stringify({databaseURL:HOST,apiKey:"demo",name:"بوب"}));
// ---------- fake backend ----------
let tree={},n=0;const subs=[];const enc=new TextEncoder();
const segs=p=>p.replace(/\.json$/,"").split("/").filter(Boolean);
const get=p=>segs(p).reduce((o,k)=>(o==null?null:(o[k]===undefined?null:o[k])),tree);
function prune(o){for(const k of Object.keys(o))if(o[k]&&typeof o[k]==="object"){prune(o[k]);if(!Object.keys(o[k]).length)delete o[k]}}
function set(p,v){const s=segs(p);if(!s.length){tree=v||{};return}let o=tree;for(const k of s.slice(0,-1))o=o[k]=(o[k]&&typeof o[k]==="object"?o[k]:{});if(v===null)delete o[s[s.length-1]];else o[s[s.length-1]]=v;prune(tree)}
function notify(p){for(const s of subs){const sp=s.path;if(p.startsWith(sp)||sp.startsWith(p)){try{s.c.enqueue(enc.encode(`event: put\ndata: ${JSON.stringify({path:"/",data:get(sp)})}\n\n`))}catch(e){}}}}
const J=(o,st)=>new Response(JSON.stringify(o),{status:st||200,headers:{"content-type":"application/json"}});
const realFetch=window.fetch.bind(window);
window.fetch=async function(url,o){
  url=String(url);o=o||{};
  if(/identitytoolkit\.googleapis\.com.*signUp/.test(url)){const id="uid"+(++n);return J({idToken:"t:"+id,refreshToken:"r:"+id,localId:id})}
  if(/securetoken\.googleapis\.com/.test(url)){const r=/refresh_token=([^&]+)/.exec(String(o.body||""))[1];const id=r.slice(2);return J({id_token:"t:"+id,refresh_token:r,user_id:id})}
  if(!url.startsWith(HOST))return realFetch(url,o);
  const u=new URL(url);const p=u.pathname.replace(/\.json$/,"");const m=(o.method||"GET").toUpperCase();
  if(m==="GET"&&o.headers&&/event-stream/.test(o.headers.accept||"")){
    let sub;const body=new ReadableStream({start(c){sub={path:p,c};subs.push(sub);c.enqueue(enc.encode(`event: put\ndata: ${JSON.stringify({path:"/",data:get(p)})}\n\n`));if(o.signal)o.signal.addEventListener("abort",()=>{const i=subs.indexOf(sub);if(i>=0)subs.splice(i,1);try{c.close()}catch(e){}})},cancel(){const i=subs.indexOf(sub);if(i>=0)subs.splice(i,1)}});
    return new Response(body,{status:200,headers:{"content-type":"text/event-stream"}})}
  if(m==="GET")return J(get(p));
  if(m==="PUT"){const v=JSON.parse(o.body);set(p,v);notify(p);return J(v)}
  if(m==="DELETE"){set(p,null);notify(p);return J(null)}
  if(m==="POST"){const k="-k"+String(++n).padStart(6,"0");set(p+"/"+k,JSON.parse(o.body));notify(p);return J({name:k})}
  return new Response("",{status:405});
};
// ---------- helpers ----------
const sl=ms=>new Promise(r=>setTimeout(r,ms));
const rnd=a=>a[Math.floor(Math.random()*a.length)];
function wavB64(){const sr=8000,N=sr*2,b=new Uint8Array(44+N);const dv=new DataView(b.buffer);const w=(o,s)=>[...s].forEach((c,i)=>b[o+i]=c.charCodeAt(0));
  w(0,"RIFF");dv.setUint32(4,36+N,true);w(8,"WAVEfmt ");dv.setUint32(16,16,true);dv.setUint16(20,1,true);dv.setUint16(22,1,true);dv.setUint32(24,sr,true);dv.setUint32(28,sr,true);dv.setUint16(32,1,true);dv.setUint16(34,8,true);w(36,"data");dv.setUint32(40,N,true);
  for(let i=0;i<N;i++){const t=i/sr;const env=Math.max(0,Math.sin(t*9)**2)*(.5+.5*Math.sin(t*3.1));const f=170+60*Math.sin(t*5);b[44+i]=128+Math.round(60*env*Math.sin(2*Math.PI*f*t))}
  let s="";for(let i=0;i<b.length;i+=0x8000)s+=String.fromCharCode.apply(null,b.subarray(i,i+0x8000));return btoa(s)}
function imgB64(t1,c1,c2,txt){const c=document.createElement("canvas");c.width=360;c.height=240;const x=c.getContext("2d");const g=x.createLinearGradient(0,0,360,240);g.addColorStop(0,c1);g.addColorStop(1,c2);x.fillStyle=g;x.fillRect(0,0,360,240);
  x.fillStyle="rgba(255,255,255,.25)";x.beginPath();x.arc(280,60,50,0,7);x.fill();x.beginPath();x.arc(70,200,70,0,7);x.fill();x.fillStyle="#fff";x.font="bold 34px sans-serif";x.textAlign="center";x.fillText(txt||"",180,130);return c.toDataURL("image/jpeg",.6).split(",")[1]}
const mem=()=>{let d=null;const med={};return{get:()=>d,set:x=>{d=JSON.parse(JSON.stringify(x))},putMedia:async(k,v)=>{med[k]=v},getMedia:async k=>med[k]||null}};
// ---------- people ----------
const CFG={databaseURL:HOST,apiKey:"demo"};
const P={};
const PEOPLE=[
 {k:"mama",name:"ماما",about:"ربنا يحفظكم",rep:["ربنا يحفظك يا حبيبي","كلت ولا لسه؟","خلي بالك من نفسك","هتيجي الجمعة؟ هعمل محشي"]},
 {k:"ahmed",name:"أحمد (الشغل)",about:"مهندس برمجيات",rep:["تمام، هبعتلك الملف النهاردة","ثانية وراجعلك","ماشي يا هندسة","نخلصه قبل الخميس إن شاء الله"]},
 {k:"mona",name:"منى",about:"",rep:["هههه","اه والله","طب وبعدين؟","حلو أوي!"]},
 {k:"youssef",name:"يوسف",about:"كورة وبس",rep:["الماتش النهاردة 9","هتيجي؟","عليا الحلو","ماشي"]},
 {k:"sara",name:"سارة",about:"تصوير وسفر",rep:["شكرًا","هبعتلك الصور","جميل!","استنى هشوف"]}
];
async function waitFor(f,ms){const t=Date.now();while(!f()){if(Date.now()-t>(ms||15000))return false;await sl(120)}return true}
function badge(){const d=document.createElement("div");d.id="demoBadge";d.textContent="ديمو · بيانات وهمية ومبتروحش بره الموبايل";d.style.cssText="position:fixed;top:1px;left:50%;transform:translateX(-50%);z-index:99;font:10px system-ui,sans-serif;padding:1px 10px;border-radius:0 0 10px 10px;background:#ffb02e;color:#201400;pointer-events:none;white-space:nowrap";document.body.appendChild(d)}
function simCalls(){
  const $=s=>document.querySelector(s);let t0=0,tm=null,to=null;
  const show=(name,inc)=>{$("#callv").classList.remove("hide");$("#cnm").textContent=name;$("#cav").textContent=name.slice(0,1);$("#cav").classList.add("rg");$("#cst").textContent=inc?"مكالمة صوتية واردة (ديمو)...":"بيرن... (ديمو)";$("#cacc").classList.toggle("hide",!inc);$("#cmute").classList.toggle("hide",inc);if(inc){try{navigator.vibrate&&navigator.vibrate([300,200,300])}catch(e){}}};
  const end=()=>{clearTimeout(to);clearInterval(tm);$("#callv").classList.add("hide")};
  const conn=()=>{clearTimeout(to);$("#cav").classList.remove("rg");$("#cacc").classList.add("hide");$("#cmute").classList.remove("hide");t0=Date.now();clearInterval(tm);tm=setInterval(()=>{const s=Math.floor((Date.now()-t0)/1000);$("#cst").textContent="ديمو (مفيش صوت) "+String(Math.floor(s/60)).padStart(2,"0")+":"+String(s%60).padStart(2,"0")},500)};
  callUI.call=async(uid,name)=>{show(name,false);to=setTimeout(conn,2800)};
  $("#cend").onclick=end;$("#cacc").onclick=conn;$("#cmute").onclick=()=>{const m=$("#cmute");m.dataset.m=m.dataset.m==="1"?"0":"1"};
  return{ring:name=>{show(name,true);to=setTimeout(end,25000)}}}
function replier(p,spec){
  return e=>{
    try{
      if(e.t!=="message")return;
      const bobId=window.__bobUid;
      if(e.group){if(!/ · بوب$/.test(e.name||""))return;if(P._chAds&&e.uid===P._chAds)return;if(Math.random()<.35)return;
        setTimeout(async()=>{try{await p.groupTyping(e.uid);await sl(1400);await p.send(e.uid,rnd(spec.rep))}catch(x){}},900+Math.random()*1500);return}
      if(e.uid!==bobId)return;
      setTimeout(()=>p.markRead(bobId).catch(()=>{}),600);
      setTimeout(async()=>{try{await p.typing(bobId);await sl(1200+Math.random()*1500);
        if(e.kind==="img"){await p.react(bobId,e.id,"❤️").catch(()=>{});await p.send(bobId,"حلوة الصورة!")}
        else if(e.kind==="voice"){await p.send(bobId,"سمعتها، تمام")}
        else await p.send(bobId,rnd(spec.rep))}catch(x){}},1000);
    }catch(x){}}}
async function seed(){
  const bob=acct;const bobId=bob.id;
  await waitFor(()=>bob.id);window.__bobUid=null;
  // make peers
  for(const s of PEOPLE){
    const holder={};const pp=SirrnaAccounts.create(e=>holder.f&&holder.f(e),CFG,mem());holder.f=replier(pp,s);
    await pp.start(s.name);try{await pp.setProfile(s.about||"",null)}catch(e){}
    P[s.k]=pp;pp.__spec=s}
  // friends: peers request Bob, Bob accepts
  for(const s of PEOPLE){try{await P[s.k].addFriend(bobId)}catch(e){}}
  await waitFor(()=>PEOPLE.every(s=>bob.friends().some(f=>f.real===s.name)),20000);
  for(const f of bob.friends())if(f.state==="in"){try{await bob.accept(f.uid)}catch(e){}}
  await waitFor(()=>bob.friends().filter(f=>f.state==="friend").length>=PEOPLE.length,20000);
  const uidOf=nm=>(bob.friends().find(f=>f.real===nm)||{}).uid;
  const bobUidFor={};// each peer's uid as seen by itself differs from Bob's; peers use Bob's uid string
  window.__bobUid=null;
  // Bob's uid from a peer's view: friend with id===bobId
  const bUid=k=>(P[k].friends().find(f=>f.id===bobId)||{}).uid;
  for(const s of PEOPLE){const u=bUid(s.k);if(u){window.__bobUid=u;break}}
  // each peer has the same uid for Bob (uid is global): check
  window.__bobUid=bUid("mama");
  const say=async(k,t,gap)=>{await P[k].send(bUid(k),t);await sl(gap||350)};
  const bobSay=async(k,t,gap)=>{await bob.send(uidOf(P[k].__spec.name),t);await sl(gap||350)};
  // history
  await say("mama","صباح الخير يا حبيبي");await say("mama","هتيجي الجمعة نتغدى سوا؟");await bobSay("mama","صباح النور يا ماما، أكيد هاجي");await say("mama","ربنا يخليك، هعمل محشي وفراخ");
  await say("ahmed","وصلك ملف التصميم؟");await bobSay("ahmed","اه وصلني، شغال عليه");await say("ahmed","تمام، نخلصه قبل الخميس");
  await say("sara","بص الصورة اللي صورتها امبارح");
  try{await P.sara.sendMedia(bUid("sara"),"img","image/jpeg",imgB64("","#2f6fed","#46b4c8","غروب الإسكندرية"),"")}catch(e){}
  await bobSay("sara","جميلة جدًا! 😍");
  try{await P.youssef.sendMedia(bUid("youssef"),"img","image/jpeg",imgB64("","#7a4fd6","#2f6fed","سر (مرة واحدة)"),"",true)}catch(e){}
  await say("youssef","الماتش النهاردة الساعة ٩ هتيجي؟");
  try{await P.mona.sendMedia(bUid("mona"),"voice","audio/wav",wavB64(),"")}catch(e){}
  await say("mona","بعتلك رسالة صوتية (في الديمو هي نغمة مش صوت حقيقي)");
  // sticker
  try{await P.mona.sendExtra(bUid("mona"),{k:"stk",s:"a_party"})}catch(e){}
  // group + channel
  try{const g=await bob.createGroup("شلة الشغل",["أحمد (الشغل)","سارة","يوسف"].map(uidOf).filter(Boolean));
    await waitFor(()=>["ahmed","sara","youssef"].every(k=>P[k].groups().length),15000);
    const gc=k=>P[k].groups()[0].chat;
    await P.ahmed.send(gc("ahmed"),"صباح الخير يا شباب، اجتماع الساعة ١١");await sl(300);await P.sara.send(gc("sara"),"تمام معاكم");await sl(300);
    const pm=await P.ahmed.sendExtra(gc("ahmed"),{k:"poll",t:"نتغدى فين النهاردة؟",po:["كشري","حواوشي","بيتزا"],pm:0});await sl(400);
    await P.sara.vote(gc("sara"),pm.i,2).catch(()=>{});await P.youssef.vote(gc("youssef"),pm.i,0).catch(()=>{});
    await P.ahmed.send(gc("ahmed"),"التصويت مفتوح، رأيك إيه يا بوب؟")}catch(e){console.log("grp",e)}
  try{await bob.createGroup("العيلة",["ماما","منى"].map(uidOf).filter(Boolean));
    await waitFor(()=>P.mama.groups().length,15000);
    await P.mama.send(P.mama.groups()[0].chat,"الجمعة الساعة ٢ الغدا عندي");await sl(300);await P.mona.send(P.mona.groups()[0].chat,"هجيب الحلو")}catch(e){}
  try{const ch=await bob.createGroup("أخبار سرّنا",PEOPLE.map(s=>uidOf(s.name)).filter(Boolean),true);await bob.send(ch,"أهلًا بيكم في قناة أخبار سرّنا (ديمو). الإعلانات هنا بس.")}catch(e){}
  // statuses
  try{await P.ahmed.postStatus("يوم شغل طويل ☕","#1f6f8b");await P.sara.postStatus("رحلة الساحل",null,{m:"image/jpeg",b:imgB64("","#d9822b","#c2417b","الساحل")});await P.youssef.postStatus("يلا ماتش النهاردة ⚽","#1f9d6b")}catch(e){}
  // later: incoming voice call
  const sc=simCalls();setTimeout(()=>sc.ring("ماما"),60000);
  // random proactive messages
  setInterval(()=>{try{const s=rnd(PEOPLE);if(s.k==="mama"||Math.random()<.5)P[s.k].send(bUid(s.k),rnd(["عامل إيه؟","وحشتني","فينك؟","شفت الخبر ده؟"]))}catch(e){}},45000);
  window.__demoReady=true;
}
function start(){badge();(async()=>{await waitFor(()=>{try{return acct&&acct.id}catch(e){return false}},30000);try{simCalls()}catch(e){}await seed()})().catch(e=>console.log("demo seed failed",e))}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",start);else start();
})();
