package app.sirrna.nearby;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.nearby.Nearby;
import com.google.android.gms.nearby.connection.AdvertisingOptions;
import com.google.android.gms.nearby.connection.ConnectionInfo;
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback;
import com.google.android.gms.nearby.connection.ConnectionResolution;
import com.google.android.gms.nearby.connection.ConnectionsClient;
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes;
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo;
import com.google.android.gms.nearby.connection.DiscoveryOptions;
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback;
import com.google.android.gms.nearby.connection.Payload;
import com.google.android.gms.nearby.connection.PayloadCallback;
import com.google.android.gms.nearby.connection.PayloadTransferUpdate;
import com.google.android.gms.nearby.connection.Strategy;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Thin transport bridge: advertise + discover, connect to one peer, move strings.
 * All app logic (PIN check, messages, ack, ping) lives in assets/index.html.
 */
public class NearbyBridge {
    private static final String SERVICE = "app.sirrna.nearby.test";
    private final Activity act;
    private final WebView wv;
    private final ConnectionsClient cc;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final String myId = String.format("%04x", new Random().nextInt(0xFFFF));
    private String myName = "";
    private String peerId = null;
    private boolean connected = false;
    private boolean running = false;
    private final Map<String, String> found = new HashMap<>();
    private final Set<String> requested = new HashSet<>();

    public NearbyBridge(Activity a, WebView w) {
        act = a;
        wv = w;
        cc = Nearby.getConnectionsClient(a);
    }

    private void emit(JSONObject o) {
        final String js = "window.onNearby&&window.onNearby(" + o.toString() + ")";
        main.post(() -> wv.evaluateJavascript(js, null));
    }

    private void ev(String type, String... kv) {
        try {
            JSONObject o = new JSONObject();
            o.put("t", type);
            for (int i = 0; i + 1 < kv.length; i += 2) o.put(kv[i], kv[i + 1]);
            emit(o);
        } catch (Exception ignored) {
        }
    }

    private List<String> neededPerms() {
        List<String> p = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) {
            p.add(Manifest.permission.BLUETOOTH_ADVERTISE);
            p.add(Manifest.permission.BLUETOOTH_CONNECT);
            p.add(Manifest.permission.BLUETOOTH_SCAN);
            p.add(Manifest.permission.NEARBY_WIFI_DEVICES);
        } else if (Build.VERSION.SDK_INT >= 31) {
            p.add(Manifest.permission.BLUETOOTH_ADVERTISE);
            p.add(Manifest.permission.BLUETOOTH_CONNECT);
            p.add(Manifest.permission.BLUETOOTH_SCAN);
            p.add(Manifest.permission.ACCESS_FINE_LOCATION);
        } else {
            p.add(Manifest.permission.ACCESS_FINE_LOCATION);
            p.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        return p;
    }

    private List<String> missing() {
        List<String> m = new ArrayList<>();
        for (String p : neededPerms())
            if (act.checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) m.add(p.replace("android.permission.", ""));
        return m;
    }

    void permissionsResult() {
        ev("perms", "missing", missing().toString());
    }

    @JavascriptInterface
    public String info() {
        try {
            JSONObject o = new JSONObject();
            o.put("sdk", Build.VERSION.SDK_INT);
            o.put("model", Build.MANUFACTURER + " " + Build.MODEL);
            o.put("gms", GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(act));
            BluetoothManager bm = (BluetoothManager) act.getSystemService(Context.BLUETOOTH_SERVICE);
            BluetoothAdapter ad = bm == null ? null : bm.getAdapter();
            o.put("bt", ad != null && ad.isEnabled());
            WifiManager wm = (WifiManager) act.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            o.put("wifi", wm != null && wm.isWifiEnabled());
            LocationManager lm = (LocationManager) act.getSystemService(Context.LOCATION_SERVICE);
            o.put("loc", lm != null && lm.isLocationEnabled());
            o.put("locNeeded", Build.VERSION.SDK_INT <= 32);
            o.put("missing", new JSONArray(missing()));
            o.put("myId", myId);
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    @JavascriptInterface
    public void requestPerms() {
        List<String> m = new ArrayList<>();
        for (String p : neededPerms()) if (act.checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) m.add(p);
        if (m.isEmpty()) {
            permissionsResult();
            return;
        }
        act.runOnUiThread(() -> act.requestPermissions(m.toArray(new String[0]), 7));
    }

    @JavascriptInterface
    public void start(String name) {
        main.post(() -> startInternal(name));
    }

    private void startInternal(String name) {
        if (!missing().isEmpty()) {
            ev("error", "msg", "perms: " + missing());
            return;
        }
        myName = (name == null ? "" : name).replace("|", " ");
        running = true;
        found.clear();
        requested.clear();
        peerId = null;
        connected = false;
        String local = myId + "|" + myName;
        cc.startAdvertising(local, SERVICE, lifecycle,
                new AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build())
                .addOnSuccessListener(v -> ev("log", "msg", "advertising ok id=" + myId))
                .addOnFailureListener(e -> ev("error", "msg", "advertising: " + e.getMessage()));
        cc.startDiscovery(SERVICE, discovery,
                new DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build())
                .addOnSuccessListener(v -> ev("log", "msg", "discovery ok"))
                .addOnFailureListener(e -> ev("error", "msg", "discovery: " + e.getMessage()));
    }

    @JavascriptInterface
    public void stop() {
        main.post(() -> {
            running = false;
            connected = false;
            peerId = null;
            cc.stopAdvertising();
            cc.stopDiscovery();
            cc.stopAllEndpoints();
            ev("stopped");
        });
    }

    @JavascriptInterface
    public void send(String data) {
        if (peerId == null || !connected) {
            ev("error", "msg", "send: not connected");
            return;
        }
        cc.sendPayload(peerId, Payload.fromBytes(data.getBytes(StandardCharsets.UTF_8)))
                .addOnFailureListener(e -> ev("error", "msg", "send: " + e.getMessage()));
    }

    @JavascriptInterface
    public void disconnect() {
        main.post(() -> {
            if (peerId != null) cc.disconnectFromEndpoint(peerId);
            connected = false;
            peerId = null;
        });
    }

    private final EndpointDiscoveryCallback discovery = new EndpointDiscoveryCallback() {
        @Override
        public void onEndpointFound(String id, DiscoveredEndpointInfo info) {
            String n = info.getEndpointName();
            found.put(id, n);
            ev("found", "id", id, "name", n);
            if (connected || peerId != null) return;
            String theirId = n.contains("|") ? n.substring(0, n.indexOf('|')) : n;
            // Tie-break so both phones do not request at the same moment.
            long delay = myId.compareTo(theirId) < 0 ? 0 : 6000;
            main.postDelayed(() -> request(id), delay);
        }

        @Override
        public void onEndpointLost(String id) {
            found.remove(id);
            ev("lost", "id", id);
        }
    };

    private void request(String id) {
        if (!running || connected || peerId != null || !found.containsKey(id) || requested.contains(id)) return;
        requested.add(id);
        cc.requestConnection(myId + "|" + myName, id, lifecycle)
                .addOnFailureListener(e -> {
                    requested.remove(id);
                    ev("error", "msg", "request: " + e.getMessage());
                });
    }

    private final ConnectionLifecycleCallback lifecycle = new ConnectionLifecycleCallback() {
        @Override
        public void onConnectionInitiated(String id, ConnectionInfo info) {
            if (connected || (peerId != null && !peerId.equals(id))) {
                cc.rejectConnection(id);
                ev("log", "msg", "rejected extra endpoint " + id);
                return;
            }
            peerId = id;
            ev("initiated", "id", id, "name", info.getEndpointName(), "digits", info.getAuthenticationDigits());
            cc.acceptConnection(id, payloads);
        }

        @Override
        public void onConnectionResult(String id, ConnectionResolution r) {
            int code = r.getStatus().getStatusCode();
            if (code == ConnectionsStatusCodes.STATUS_OK) {
                connected = true;
                peerId = id;
                cc.stopAdvertising();
                cc.stopDiscovery();
                ev("connected", "id", id);
            } else {
                if (id.equals(peerId)) peerId = null;
                requested.remove(id);
                ev("error", "msg", "connection result " + code + " " + ConnectionsStatusCodes.getStatusCodeString(code));
            }
        }

        @Override
        public void onDisconnected(String id) {
            if (id.equals(peerId)) {
                peerId = null;
                connected = false;
            }
            requested.remove(id);
            ev("disconnected", "id", id);
        }
    };

    private final PayloadCallback payloads = new PayloadCallback() {
        @Override
        public void onPayloadReceived(String id, Payload p) {
            if (p.getType() == Payload.Type.BYTES && p.asBytes() != null)
                ev("recv", "data", new String(p.asBytes(), StandardCharsets.UTF_8));
        }

        @Override
        public void onPayloadTransferUpdate(String id, PayloadTransferUpdate u) {
        }
    };
}
