package app.sirrna.nearby;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * No-GMS transport: classic Bluetooth RFCOMM between two phones that are already paired in system settings.
 * Secure (encrypted by the Bluetooth link) RFCOMM. Same event contract as NearbyBridge.
 */
public class BtBridge {
    static final UUID APP_UUID = UUID.fromString("7b1f3c52-6a0e-4c1d-9d57-5e1a2f0c8b31");
    private final Activity act;
    private final WebView wv;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService writer = Executors.newSingleThreadExecutor();
    private volatile BluetoothServerSocket server;
    private volatile BluetoothSocket sock;
    private volatile DataOutputStream out;
    private volatile boolean running = false;
    private volatile boolean connecting = false;
    private volatile int gen = 0;

    BtBridge(Activity a, WebView w) {
        act = a;
        wv = w;
    }

    private void ev(String type, String... kv) {
        try {
            JSONObject o = new JSONObject();
            o.put("t", type);
            for (int i = 0; i + 1 < kv.length; i += 2) o.put(kv[i], kv[i + 1]);
            emit(o);
        } catch (Exception ignored) {
        }
    }

    private void emit(JSONObject o) {
        final String js = "window.onNearby&&window.onNearby(" + o.toString() + ")";
        main.post(() -> wv.evaluateJavascript(js, null));
    }

    private BluetoothAdapter adapter() {
        BluetoothManager bm = (BluetoothManager) act.getSystemService(Context.BLUETOOTH_SERVICE);
        return bm == null ? null : bm.getAdapter();
    }

    List<String> neededPerms() {
        List<String> p = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31) p.add(Manifest.permission.BLUETOOTH_CONNECT);
        return p;
    }

    List<String> missing() {
        List<String> m = new ArrayList<>();
        for (String p : neededPerms())
            if (act.checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) m.add(p.replace("android.permission.", ""));
        return m;
    }

    boolean btOn() {
        BluetoothAdapter a = adapter();
        return a != null && a.isEnabled();
    }

    boolean hasBt() {
        return adapter() != null;
    }

    void paired() {
        try {
            BluetoothAdapter a = adapter();
            JSONArray arr = new JSONArray();
            if (a != null && missing().isEmpty()) {
                for (BluetoothDevice d : a.getBondedDevices()) {
                    JSONObject o = new JSONObject();
                    o.put("a", d.getAddress());
                    o.put("n", d.getName() == null ? d.getAddress() : d.getName());
                    arr.put(o);
                }
            }
            JSONObject o = new JSONObject();
            o.put("t", "paired");
            o.put("list", arr);
            emit(o);
        } catch (Exception ignored) {
        }
    }

    void start(String name) {
        if (!hasBt()) { ev("error", "msg", "الموبايل ده مفيهوش بلوتوث"); return; }
        if (!btOn()) { ev("error", "msg", "شغّل البلوتوث الأول"); return; }
        if (!missing().isEmpty()) { ev("error", "msg", "perms: " + missing()); return; }
        closeAll();
        running = true;
        final int g = ++gen;
        paired();
        ev("log", "msg", "bluetooth listening (RFCOMM, paired devices only)");
        new Thread(() -> {
            try {
                server = adapter().listenUsingRfcommWithServiceRecord("sirrna", APP_UUID);
                while (running && g == gen) {
                    BluetoothSocket s = server.accept();
                    if (sock != null || connecting) { try { s.close(); } catch (Exception ignored) {} continue; }
                    attach(s, g);
                    break;
                }
            } catch (Exception e) {
                if (running && g == gen) ev("error", "msg", "listen: " + e.getMessage());
            }
        }, "bt-accept").start();
    }

    void connectTo(String addr) {
        if (!running) { ev("error", "msg", "اضغط ابدأ الأول"); return; }
        if (sock != null || connecting) return;
        connecting = true;
        final int g = gen;
        ev("log", "msg", "connecting to " + addr);
        ev("status", "msg", "connecting");
        new Thread(() -> {
            try {
                BluetoothDevice d = adapter().getRemoteDevice(addr);
                BluetoothSocket s = d.createRfcommSocketToServiceRecord(APP_UUID);
                try { adapter().cancelDiscovery(); } catch (Exception ignored) {}
                s.connect();
                attach(s, g);
            } catch (Exception e) {
                connecting = false;
                ev("error", "msg", "connect: " + e.getMessage() + " (التاني لازم يكون ضاغط ابدأ وفاتح التطبيق)");
            }
        }, "bt-connect").start();
    }

    private void attach(BluetoothSocket s, int g) {
        try {
            sock = s;
            connecting = false;
            try { if (server != null) server.close(); } catch (Exception ignored) {}
            DataInputStream in = new DataInputStream(s.getInputStream());
            out = new DataOutputStream(s.getOutputStream());
            String nm = s.getRemoteDevice().getName();
            ev("initiated", "id", s.getRemoteDevice().getAddress(), "name", "x|" + (nm == null ? "" : nm), "digits", "");
            ev("connected", "id", s.getRemoteDevice().getAddress());
            new Thread(() -> {
                try {
                    while (true) ev("recv", "data", in.readUTF());
                } catch (Exception e) {
                    if (sock == s) {
                        sock = null;
                        out = null;
                        try { s.close(); } catch (Exception ignored) {}
                        ev("disconnected", "id", "");
                    }
                }
            }, "bt-read").start();
        } catch (Exception e) {
            connecting = false;
            ev("error", "msg", "attach: " + e.getMessage());
        }
    }

    void send(String data) {
        final DataOutputStream o = out;
        if (o == null) { ev("error", "msg", "send: not connected"); return; }
        writer.execute(() -> {
            try {
                synchronized (o) { o.writeUTF(data); o.flush(); }
            } catch (Exception e) {
                ev("error", "msg", "send: " + e.getMessage());
            }
        });
    }

    private void closeAll() {
        running = false;
        gen++;
        connecting = false;
        try { if (server != null) server.close(); } catch (Exception ignored) {}
        server = null;
        BluetoothSocket s = sock;
        sock = null;
        out = null;
        try { if (s != null) s.close(); } catch (Exception ignored) {}
    }

    void disconnect() {
        BluetoothSocket s = sock;
        sock = null;
        out = null;
        try { if (s != null) s.close(); } catch (Exception ignored) {}
        ev("disconnected", "id", "");
    }

    void stop() {
        closeAll();
        ev("stopped");
    }
}
