package app.sirrna.nearby;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

/** Receives the text typed in the notification reply box and hands it to the running app. */
public class ReplyReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        String uid = i.getStringExtra("uid");
        Bundle r = android.app.RemoteInput.getResultsFromIntent(i);
        CharSequence t = r == null ? null : r.getCharSequence("reply");
        boolean ok = uid != null && t != null && t.length() > 0 && Hub.deliverReply(uid, t.toString());
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null && uid != null) nm.cancel(Math.abs(uid.hashCode()));
        if (!ok) Toast.makeText(c, "افتح سرّنا الأول عشان الرد يتبعت", Toast.LENGTH_LONG).show();
    }
}
