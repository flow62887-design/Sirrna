package app.sirrna.nearby;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView wv;
    private Hub bridge;
    private PermissionRequest pendingReq;
    private android.webkit.GeolocationPermissions.Callback pendingGeo;
    private String pendingGeoOrigin;
    private android.webkit.ValueCallback<Uri[]> fileCb;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (android.os.Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true); }
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        wv = new WebView(this);
        wv.setBackgroundColor(Color.BLACK);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        WebView.setWebContentsDebuggingEnabled(true);
        wv.setWebViewClient(new WebViewClient());
        wv.getSettings().setMediaPlaybackRequiresUserGesture(false);
        s.setGeolocationEnabled(true);
        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(final String origin, final android.webkit.GeolocationPermissions.Callback cb) {
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) cb.invoke(origin, true, false);
                    else { pendingGeo = cb; pendingGeoOrigin = origin; requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 9); }
                });
            }
            @Override
            public boolean onShowFileChooser(WebView w, android.webkit.ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try { startActivityForResult(p.createIntent(), 77); }
                catch (Exception e) { fileCb = null; return false; }
                return true;
            }
            @Override
            public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> {
                    java.util.List<String> need = new java.util.ArrayList<>();
                    for (String r : req.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.CAMERA);
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO);
                    }
                    if (need.isEmpty()) req.grant(req.getResources());
                    else { pendingReq = req; requestPermissions(need.toArray(new String[0]), 8); }
                });
            }
        });
        bridge = new Hub(this, wv);
        wv.addJavascriptInterface(bridge, "Nearby");
        setContentView(wv);
        handleIntent(getIntent(), true);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == 77) {
            if (fileCb != null) fileCb.onReceiveValue(android.webkit.WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    protected void onResume() { super.onResume(); Notif.fg = true; Notif.clearCall(this); }

    @Override
    protected void onPause() { super.onPause(); Notif.fg = false; }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 10) return;
        if (code == 9) {
            if (pendingGeo != null) { pendingGeo.invoke(pendingGeoOrigin, res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED, false); pendingGeo = null; }
            return;
        }
        if (code == 8) {
            if (pendingReq != null) {
                boolean allOk = res.length > 0;
                for (int g : res) if (g != PackageManager.PERMISSION_GRANTED) allOk = false;
                if (allOk) pendingReq.grant(pendingReq.getResources()); else pendingReq.deny();
                pendingReq = null;
            }
            return;
        }
        bridge.permissionsResult();
    }

    /** sirrna://add?id=XXXX opens the chat app and adds the friend; otherwise the original test page. Start the chat app with the test page via ?test. */
    private void handleIntent(Intent in, boolean first) {
        Uri u = in == null ? null : in.getData();
        if (u != null && "sirrna".equals(u.getScheme())) {
            if ("join".equals(u.getHost())) {
                String g = u.getQueryParameter("g"), ad = u.getQueryParameter("a");
                if (g != null && ad != null && g.matches("[a-f0-9]{12}") && ad.matches("[A-Za-z2-9]{10}")) {
                    String link = "sirrna://join?g=" + g + "&a=" + ad.toUpperCase();
                    if (first) wv.loadUrl("file:///android_asset/app.html#/join?g=" + g + "&a=" + ad.toUpperCase());
                    else wv.evaluateJavascript("window.onSirrnaLink&&window.onSirrnaLink('" + link + "')", null);
                } else if (first) wv.loadUrl("file:///android_asset/app.html");
                return;
            }
            String id = u.getQueryParameter("id");
            if (id == null || !id.matches("[A-Za-z2-9]{10}")) { if (first) wv.loadUrl("file:///android_asset/app.html"); return; }
            if (first) wv.loadUrl("file:///android_asset/app.html#/add?id=" + id.toUpperCase());
            else wv.evaluateJavascript("window.onSirrnaLink&&window.onSirrnaLink('sirrna://add?id=" + id.toUpperCase() + "')", null);
        } else if (first) wv.loadUrl("file:///android_asset/app.html");
    }

    @Override
    protected void onNewIntent(Intent in) {
        super.onNewIntent(in);
        handleIntent(in, false);
    }

    @Override
    protected void onDestroy() {
        bridge.stop();
        Hub.inst = null;
        super.onDestroy();
    }

    private void setEnabledBackFallback() {
        // home screen: normal system behaviour (leave the app)
        super.onBackPressed();
    }

    @Override
    public void onBackPressed() {
        // Ask the web app first (closes sheet/modal/call overlay, chat -> home). Only when it has nothing left to close do we leave the app.
        wv.evaluateJavascript("(function(){try{return window.__back?window.__back():false}catch(e){return false}})()", value -> {
            if (!"true".equals(value)) {
                setEnabledBackFallback();
            }
        });
    }
}
