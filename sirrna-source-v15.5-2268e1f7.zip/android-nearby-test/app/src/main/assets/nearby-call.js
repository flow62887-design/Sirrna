/* Voice call over the Nearby / Bluetooth text channel (index.html page). Pure JavaScript, no native code:
   mic -> 8 kHz mu-law (8 kB/s) -> AES-256-GCM with the session key (S.key) -> "V:" frames over Nearby.send().
   Limits: telephone quality, 0.2-0.6 s delay, needs the two phones in range, speaker mode echoes (use headphones). */
(function () {
  const RATE = 8000, FR = 320; // 40 ms frames
  const enc8 = (x) => { const s = x < 0 ? 0x80 : 0; x = Math.min(32635, Math.abs(Math.round(x * 32767))) + 132; let e = 7; for (let m = 0x4000; (x & m) === 0 && e > 0; e--, m >>= 1); return ~(s | (e << 4) | ((x >> (e + 3)) & 15)) & 255; };
  const dec8 = (u) => { u = ~u & 255; const t = (((u & 15) << 3) + 132) << ((u & 0x70) >> 4); return ((u & 0x80) ? 132 - t : t - 132) / 32768; };
  const b64e = (u) => { let s = ""; for (const c of u) s += String.fromCharCode(c); return btoa(s); }, b64d = (t) => Uint8Array.from(atob(t), (c) => c.charCodeAt(0));
  let st = null; // {ac, stream, node, src, mute, next, buf:[], rx:0, tx:0, timer, state}
  let UI = () => {};
  async function sealFrame(bytes) { const iv = crypto.getRandomValues(new Uint8Array(12)); const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, S.key, bytes)); const r = new Uint8Array(12 + ct.length); r.set(iv); r.set(ct, 12); return "V:" + b64e(r); }
  async function openFrame(d) { const r = b64d(d.slice(2)); return new Uint8Array(await crypto.subtle.decrypt({ name: "AES-GCM", iv: r.slice(0, 12) }, S.key, r.slice(12))); }
  async function ctl(c) { try { Nearby.send(await seal({ call: c })); } catch (e) {} }
  async function startAudio() {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true }, video: false });
    const ac = new (window.AudioContext || window.webkitAudioContext)(); await ac.resume();
    const src = ac.createMediaStreamSource(stream), node = ac.createScriptProcessor(2048, 1, 1), sink = ac.createGain(); sink.gain.value = 0;
    const ratio = ac.sampleRate / RATE; let acc = [], pos = 0;
    node.onaudioprocess = (e) => { if (!st || st.state !== "live") return; const inp = e.inputBuffer.getChannelData(0);
      for (let i = 0; i < inp.length; i++) { pos += 1; acc.push(st.mute ? 0 : inp[i]); if (acc.length >= ratio * FR) { const out = new Uint8Array(FR); for (let k = 0; k < FR; k++) { const a = Math.floor(k * ratio), b = Math.max(a + 1, Math.floor((k + 1) * ratio)); let sum = 0; for (let j = a; j < b; j++) sum += acc[j] || 0; out[k] = enc8(sum / (b - a)); } acc = acc.slice(Math.ceil(ratio * FR)); st.tx++; sealFrame(out).then((m) => { try { Nearby.send(m); } catch (e) {} }); } } };
    src.connect(node); node.connect(sink); sink.connect(ac.destination);
    Object.assign(st, { ac, stream, node, src });
  }
  function play(bytes) { if (!st || !st.ac) return; const ac = st.ac, n = bytes.length, buf = ac.createBuffer(1, n, RATE), ch = buf.getChannelData(0); let e = 0; for (let i = 0; i < n; i++) { ch[i] = dec8(bytes[i]); e += Math.abs(ch[i]); } st.rx++; st.energy = (st.energy || 0) + e;
    const now = ac.currentTime; if (!st.next || st.next < now) st.next = now + 0.12; if (st.next - now > 0.6) return; // too far behind: drop frame to keep delay bounded
    const s = ac.createBufferSource(); s.buffer = buf; s.connect(ac.destination); s.start(st.next); st.next += n / RATE; }
  function end(send, why) { if (!st) return; const c = st; st = null; clearInterval(c.timer); try { c.node && c.node.disconnect(); c.stream && c.stream.getTracks().forEach((t) => t.stop()); c.ac && c.ac.close(); } catch (e) {} if (send) ctl("end"); UI({ state: "ended", why: why || "", tx: c.tx, rx: c.rx, energy: c.energy || 0 }); }
  const api = {
    setUI(f) { UI = f; }, active: () => !!st, stats: () => st && { tx: st.tx, rx: st.rx, energy: st.energy || 0 },
    async call() { if (st) return; if (!S.verified || !S.key) throw new Error("الاتصال لسه مش جاهز أو الكود مش متحقق"); st = { state: "calling", tx: 0, rx: 0 }; UI({ state: "calling" }); await ctl("ring"); st.timer = setTimeout(() => { if (st && st.state === "calling") end(true, "no answer"); }, 30000); },
    async accept() { if (!st || st.state !== "ringing") return; try { st.state = "live"; await startAudio(); await ctl("accept"); UI({ state: "live" }); } catch (e) { end(true, e.message); } },
    decline() { end(true, "declined"); }, hangup() { end(true, "hangup"); }, mute(m) { if (st) st.mute = m; },
    async ctl(c) { if (c === "ring") { if (st) { ctl("busy"); return; } st = { state: "ringing", tx: 0, rx: 0 }; st.timer = setTimeout(() => { if (st && st.state === "ringing") end(true, "missed"); }, 30000); UI({ state: "ringing" }); }
      else if (c === "accept" && st && st.state === "calling") { clearTimeout(st.timer); st.state = "live"; try { await startAudio(); UI({ state: "live" }); } catch (e) { end(true, e.message); } }
      else if (c === "end") end(false, "ended by peer"); else if (c === "busy") end(false, "busy"); },
    async frame(d) { if (!st || st.state !== "live") return; try { play(await openFrame(d)); } catch (e) {} },
  };
  window.NearbyCall = api;
})();
