# تشغيل الأونلاين (Firebase مجاني)
1. console.firebase.google.com > Add project (من غير Analytics).
2. Build > Authentication > Get started > Sign-in method > فعّل Anonymous.
3. Build > Realtime Database > Create database > اختار Start in locked mode.
4. تبويب Rules والصق:
{ "rules": { "r": { "$room": { ".read": "auth != null", ".write": "auth != null" } } } }
   وبعدين Publish.
5. Project settings > General > Your apps > Web (</>) > سجّل تطبيق. خد apiKey، ووخد databaseURL من صفحة Realtime Database (فوق).
6. في التطبيق: فعّل "اتصال أونلاين"، الصق databaseURL وapiKey، اكتب نفس الكود (١٠+ حروف) على الموبايلين، وابدأ.
المفاتيح تتكتب في التطبيق بس. متبعتهاش في الشات.
حدود: الرسايل بتتشفّر AES-GCM بمفتاح من الكود، فجوجل مش بتشوف النص، لكن مفيش تشفير end-to-end حقيقي: لو الكود ضعيف أو اتسرب، أي حد يعرف اسم الغرفة (مشتق منه) يقدر يخمّنه ويقرأ. مفيش إشعارات وانت مقفل التطبيق، ولا رسايل بتتحفظ لحد ما التاني يدخل.
