const O = require("./online.js"); const assert = require("assert");
const rw = (url, o) => fetch(url.replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/, "http://localhost:8099").replace("https://fake-db", "http://localhost:8099"), o);
function mk(secret) { const ev = []; const t = O.create((e) => ev.push(e), { databaseURL: "https://fake-db", apiKey: "k", secret }, rw); return { t, ev }; }
const wait = (f, ms = 8000) => new Promise((ok, no) => { const s = Date.now(); (function p() { if (f()) return ok(); if (Date.now() - s > ms) return no(new Error("timeout " + f)); setTimeout(p, 50); })(); });
(async () => {
  const A = mk("correct-horse-battery"), B = mk("correct-horse-battery"), C = mk("another-secret-code!");
  await A.t.start("A"); await new Promise(r => setTimeout(r, 300)); await B.t.start("B"); await C.t.start("C");
  await wait(() => A.ev.some(e => e.t === "connected") && B.ev.some(e => e.t === "connected"));
  console.log("both connected; peer names:", A.ev.find(e=>e.t==="initiated").name, B.ev.find(e=>e.t==="initiated").name);
  A.t.send("M:hello"); B.t.send("M:reply");
  await wait(() => B.ev.some(e => e.t === "recv" && e.data === "M:hello") && A.ev.some(e => e.t === "recv" && e.data === "M:reply"));
  console.log("messages both ways OK");
  assert(!C.ev.some(e => e.t === "connected" || e.t === "recv")); console.log("wrong-secret client saw nothing OK");
  A.t.stop(); console.log("stopped A"); await wait(() => B.ev.some(e => e.t === "disconnected")); console.log("disconnect propagated OK");
  B.t.stop(); C.t.stop(); console.log("all done"); process.exit(0);
})().catch(e => { console.error("FAIL", e); process.exit(1); });
