// minimal fake of Firebase auth + RTDB (POST push + SSE stream), for local tests only
const http = require("http");
const rooms = {}, subs = {}; let n = 0;
http.createServer((req, res) => {
  const u = new URL(req.url, "http://x");
  if (u.pathname.endsWith("accounts:signUp")) { res.end(JSON.stringify({ idToken: "tok" + ++n, refreshToken: "ref" })); return; }
  if (u.pathname.startsWith("/v1/token")) { res.end(JSON.stringify({ id_token: "tok" + ++n, refresh_token: "ref" })); return; }
  if (!u.searchParams.get("auth")) { res.statusCode = 401; res.end("{}"); return; }
  const room = u.pathname.split("/")[2];
  rooms[room] = rooms[room] || {}; subs[room] = subs[room] || [];
  if (req.method === "POST") { let b = ""; req.on("data", (d) => b += d); req.on("end", () => {
    const k = "-k" + ++n; rooms[room][k] = JSON.parse(b);
    subs[room].forEach((s) => s.write(`event: put\ndata: ${JSON.stringify({ path: "/" + k, data: rooms[room][k] })}\n\n`));
    res.end(JSON.stringify({ name: k })); }); return; }
  res.writeHead(200, { "content-type": "text/event-stream" });
  res.write(`event: put\ndata: ${JSON.stringify({ path: "/", data: Object.keys(rooms[room]).length ? rooms[room] : null })}\n\n`);
  subs[room].push(res); req.on("close", () => subs[room] = subs[room].filter((s) => s !== res));
}).listen(8099, () => console.log("fake up"));
