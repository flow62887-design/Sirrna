const A = require("./accounts.js"); const assert = require("assert");
const rw = (url, o) => fetch(url.replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/, "http://localhost:8098").replace("https://fake-db", "http://localhost:8098"), o);
const wait = (f, ms = 8000) => new Promise((ok, no) => { const s = Date.now(); (function p() { if (f()) return ok(); if (Date.now() - s > ms) return no(new Error("timeout " + f)); setTimeout(p, 40); })(); });
function mk() { const ev = []; let data = null; const med = {}; const store = { get: () => data, set: (d) => { data = JSON.parse(JSON.stringify(d)); }, dump: () => data, putMedia: async (k, v) => { med[k] = v; }, getMedia: async (k) => med[k], delMedia: async (k) => { delete med[k]; } };
  const a = A.create((e) => ev.push(e), { databaseURL: "https://fake-db", apiKey: "k" }, store, rw); return { a, ev, store }; }
const ok = (m) => console.log("PASS", m);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  const a = mk(), b = mk(), c = mk(), d = mk();
  b.a.setDefaultTtl(3600);
  for (const [x, n] of [[a, "Alice"], [b, "Bob"], [c, "Carol"], [d, "Dave"]]) await x.a.start(n);
  const bef = async (x, y) => { await x.a.addFriend(y.a.id); await wait(() => y.ev.some((e) => e.t === "request" && e.id === x.a.id)); await y.a.accept(y.ev.find((e) => e.t === "request" && e.id === x.a.id).uid); await wait(() => x.a.friends().find((f) => f.id === y.a.id).state === "friend"); };
  await a.a.setProfile("hello there", "QUJD");
  await bef(a, b); await bef(a, c);
  const u = (x, y) => x.a.friends().find((f) => f.id === y.a.id).uid; const ab = u(a, b), ba = u(b, a), ac = u(a, c), ca = u(c, a);
  await wait(() => b.a.friends().find((f) => f.uid === ba).about === "hello there"); assert.equal(b.a.friends().find((f) => f.uid === ba).ph, "QUJD"); ok("profile about+photo delivered to a new friend on friendship");
  await a.a.setProfile("changed", ""); await wait(() => c.a.friends().find((f) => f.uid === ca).about === "changed"); ok("profile update reaches existing friends");
  await assert.rejects(() => a.a.setProfile("x", "!!!bad")); ok("profile photo validated");
  a.a.setNick(ab, "Bobby"); assert.equal(a.a.friends().find((f) => f.uid === ab).name, "Bobby"); assert.equal(a.a.friends().find((f) => f.uid === ab).real, "Bob"); a.a.setNick(ab, ""); assert.equal(a.a.friends().find((f) => f.uid === ab).name, "Bob"); ok("nickname local only, clearable");
  await wait(() => b.a.ttl(ba) === 3600); ok("default disappearing timer applied to a new chat (Bob side)");
  // group info
  const g = await a.a.createGroup("شلة", [ab, ac]); await wait(() => b.a.groups().length && c.a.groups().length);
  await a.a.setGroupInfo(g, { ds: "وصف", ph: "QUJD", wo: true }); await wait(() => b.a.groups()[0].wo && c.a.groups()[0].ds === "وصف"); assert.equal(b.a.groups()[0].ph, "QUJD"); ok("group description + photo + admin-only synced to members");
  await assert.rejects(() => b.a.setGroupInfo(g, { ds: "x" })); ok("non-admin cannot edit group info");
  await assert.rejects(() => b.a.send(g, "hi")); await a.a.send(g, "from admin"); await wait(() => c.a.messages(g).length === 1); ok("admin-only-write: member blocked locally, admin posts");
  // receiver-side enforcement: force a member message through
  const before = a.a.messages(g).length; await b.a.setGroupInfo; 
  await a.a.setGroupInfo(g, { wo: false }); await wait(() => !b.a.groups()[0].wo); await b.a.send(g, "now allowed"); await wait(() => a.a.messages(g).length === before + 1); ok("turning admin-only off lets members post");
  // invite link: Dave joins via code, not a friend of Alice yet
  const link = a.a.groupInviteLink(g); assert(/^sirrna:\/\/join\?g=[a-f0-9]{12}&a=[A-Z2-9]{10}/.test(link)); assert.throws(() => b.a.groupInviteLink(g)); ok("invite link only from admins");
  assert.equal(await d.a.requestJoin(link), "friend-first");
  await wait(() => a.ev.some((e) => e.t === "request" && e.id === d.a.id)); await a.a.accept(a.ev.find((e) => e.t === "request" && e.id === d.a.id).uid);
  await wait(() => a.a.joinRequests().length === 1); assert.equal(a.a.joinRequests()[0].name, "Dave"); ok("join request waits for admin approval (after friend step, automatic)");
  assert(!d.a.groups().length); await a.a.approveJoin(a.a.joinRequests()[0].gid, a.a.joinRequests()[0].uid); await wait(() => d.a.groups().length === 1); assert(!a.a.joinRequests().length); ok("admin approves -> member joins");
  assert.equal(await d.a.requestJoin(link), "already"); ok("re-joining refused");
  console.log("DONE"); process.exit(0);
})().catch((e) => { console.error("FAIL", e); process.exit(1); });
