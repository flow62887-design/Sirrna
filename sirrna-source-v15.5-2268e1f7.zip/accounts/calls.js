/* Sirrna voice calls: WebRTC audio, signalling through the same encrypted inbox as messages (kind "sig").
   Audio itself goes peer-to-peer (DTLS-SRTP, encrypted). STUN is public; TURN is only used if the user types one in settings.
   Without TURN, calls fail when both phones are behind strict/carrier NAT. Nothing here is a relay. */
(function (root) {
  const DEFAULT_ICE = [{ urls: "stun:stun.l.google.com:19302" }, { urls: "stun:stun1.l.google.com:19302" }];
  function create(acct, on, getIce) {
    let cur = null; // {c, uid, name, pc, dir, stream, pend:[], remoteSet, timer}
    const rid = () => Array.from(crypto.getRandomValues(new Uint8Array(6)), (x) => x.toString(16).padStart(2, "0")).join("");
    const ice = () => ({ iceServers: (getIce && getIce()) || DEFAULT_ICE });
    const emit = (state, extra) => on(Object.assign({ state, uid: cur && cur.uid, name: cur && cur.name, dir: cur && cur.dir }, extra || {}));
    function end(send, why) {
      if (!cur) return; const c = cur; cur = null; clearTimeout(c.timer);
      try { c.pc && c.pc.close(); } catch (e) {}
      try { c.stream && c.stream.getTracks().forEach((t) => t.stop()); } catch (e) {}
      if (send) acct.sendSig(c.uid, { c: c.c, t: "end" }).catch(() => {});
      on({ state: "ended", uid: c.uid, name: c.name, dir: c.dir, why: why || "", secs: c.t0 ? Math.round((Date.now() - c.t0) / 1000) : 0 });
    }
    function mkpc() {
      const pc = new RTCPeerConnection(ice()); cur.pc = pc;
      pc.onicecandidate = (e) => { if (e.candidate && cur) acct.sendSig(cur.uid, { c: cur.c, t: "ice", ic: e.candidate.toJSON() }).catch(() => {}); };
      pc.ontrack = (e) => { on({ state: "remote", stream: e.streams[0] }); };
      pc.onconnectionstatechange = () => { if (!cur) return;
        if (pc.connectionState === "connected") { cur.t0 = cur.t0 || Date.now(); clearTimeout(cur.timer); emit("connected"); }
        else if (pc.connectionState === "failed") end(true, "failed: no direct route (TURN may be needed)");
        else if (pc.connectionState === "disconnected") setTimeout(() => { if (cur && cur.pc === pc && pc.connectionState !== "connected") end(true, "dropped"); }, 8000); };
      return pc; }
    async function mic() { return navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true }, video: false }); }
    async function flush() { if (!cur || !cur.remoteSet) return; for (const c of cur.pend.splice(0)) await cur.pc.addIceCandidate(c).catch(() => {}); }
    return {
      active: () => !!cur,
      async call(uid, name) {
        if (cur) throw new Error("في مكالمة شغالة");
        cur = { c: rid(), uid, name, dir: "out", pend: [], remoteSet: false };
        try { cur.stream = await mic(); const pc = mkpc(); cur.stream.getTracks().forEach((t) => pc.addTrack(t, cur.stream));
          const o = await pc.createOffer(); await pc.setLocalDescription(o); emit("calling");
          await acct.sendSig(uid, { c: cur.c, t: "offer", sdp: o.sdp });
          cur.timer = setTimeout(() => end(true, "no answer"), 45000);
        } catch (e) { const m = e.message; end(false, m); throw e; } },
      async accept() { const c = cur; if (!c || c.dir !== "in" || !c.offer) return;
        try { c.stream = await mic(); const pc = mkpc(); c.stream.getTracks().forEach((t) => pc.addTrack(t, c.stream));
          await pc.setRemoteDescription({ type: "offer", sdp: c.offer }); c.remoteSet = true; await flush();
          const a = await pc.createAnswer(); await pc.setLocalDescription(a); await acct.sendSig(c.uid, { c: c.c, t: "answer", sdp: a.sdp }); emit("connecting");
          c.timer = setTimeout(() => end(true, "connect timeout"), 30000);
        } catch (e) { end(true, e.message); } },
      decline() { if (cur && cur.dir === "in") end(true, "declined"); },
      hangup() { end(true, "hangup"); },
      mute(m) { if (cur && cur.stream) cur.stream.getAudioTracks().forEach((t) => (t.enabled = !m)); },
      async onSig(uid, name, o) {
        if (!o || !o.c || typeof o.c !== "string") return;
        if (o.t === "offer") {
          if (cur) { acct.sendSig(uid, { c: o.c, t: "end", busy: 1 }).catch(() => {}); return; }
          cur = { c: o.c, uid, name, dir: "in", pend: [], remoteSet: false, offer: String(o.sdp || "") };
          cur.timer = setTimeout(() => end(true, "missed"), 45000); emit("ringing"); return; }
        if (!cur || cur.c !== o.c || cur.uid !== uid) return;
        if (o.t === "answer" && cur.dir === "out" && !cur.remoteSet) { await cur.pc.setRemoteDescription({ type: "answer", sdp: String(o.sdp || "") }); cur.remoteSet = true; await flush(); emit("connecting"); }
        else if (o.t === "ice" && o.ic) { cur.pend.push(o.ic); await flush(); }
        else if (o.t === "end") end(false, o.busy ? "busy" : "ended by peer"); },
    };
  }
  const api = { create, DEFAULT_ICE };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.SirrnaCalls = api;
})(typeof self !== "undefined" ? self : globalThis);
