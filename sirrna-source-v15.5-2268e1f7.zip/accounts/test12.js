const A = require("./accounts.js"); const assert = require("assert");
const rw = (url, o) => fetch(url.replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/, "http://localhost:8098").replace("https://fake-db", "http://localhost:8098"), o);
const wait = (f, ms = 8000) => new Promise((ok, no) => { const s = Date.now(); (function p() { if (f()) return ok(); if (Date.now() - s > ms) return no(new Error("timeout " + f)); setTimeout(p, 40); })(); });
function mk() { const ev = []; let data = null; const med = {}; const store = { get: () => data, set: (d) => { data = JSON.parse(JSON.stringify(d)); }, dump: () => data, putMedia: async (k, v) => { med[k] = v; }, getMedia: async (k) => med[k], delMedia: async (k) => { delete med[k]; } };
  const a = A.create((e) => ev.push(e), { databaseURL: "https://fake-db", apiKey: "k" }, store, rw); return { a, ev, store }; }
const ok = (m) => console.log("PASS", m);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  const a = mk(), b = mk(), c = mk(), d = mk();
  for (const [x, n] of [[a, "Alice"], [b, "Bob"], [c, "Carol"], [d, "Dave"]]) await x.a.start(n);
  const bef = async (x, y) => { await x.a.addFriend(y.a.id); await wait(() => y.ev.some((e) => e.t === "request" && e.id === x.a.id)); await y.a.accept(y.ev.find((e) => e.t === "request" && e.id === x.a.id).uid); await wait(() => x.a.friends().find((f) => f.id === y.a.id).state === "friend"); };
  await bef(a, b); await bef(a, c); await bef(a, d);
  const u = (x, y) => x.a.friends().find((f) => f.id === y.a.id).uid; const ab = u(a, b), ba = u(b, a), ac = u(a, c), ad = u(a, d), ca = u(c, a);
  // extras
  await a.a.sendExtra(ab, { k: "loc", la: 31.2, lo: 29.9 }); await a.a.sendExtra(ab, { k: "ct", cid: c.a.id, cn: "Carol" }); await a.a.sendExtra(ab, { k: "stk", s: "happy" });
  await wait(() => b.a.messages(ba).length === 3); const bm = b.a.messages(ba); assert(bm[0].k === "loc" && bm[0].la === 31.2 && bm[1].cid === c.a.id && bm[2].s === "happy"); ok("location, contact and sticker messages delivered");
  await assert.rejects(() => a.a.sendExtra(ab, { k: "loc", la: 999, lo: 0 })); ok("invalid location rejected");
  await b.a.forward(ba, "forwarded text"); await wait(() => a.a.messages(ab).some((m) => m.fw)); ok("forwarded flag delivered");
  const sr = b.a.searchMessages("forwarded"); assert(sr.length === 1 && sr[0].chat === ba); assert(!b.a.searchMessages("x").length); ok("in-message search");
  // block
  b.a.block(ba); await a.a.send(ab, "after block"); await sleep(600); assert(!b.a.messages(ba).some((m) => m.t === "after block")); ok("blocked sender's message dropped");
  b.a.unblock(ba); await a.a.send(ab, "after unblock"); await wait(() => b.a.messages(ba).some((m) => m.t === "after unblock")); ok("unblock restores delivery");
  // report removes stranger requester
  const e = mk(); await e.a.start("Eve"); await e.a.addFriend(d.a.id); await wait(() => d.ev.some((x) => x.t === "request" && x.id === e.a.id)); const eu = d.ev.find((x) => x.t === "request" && x.id === e.a.id).uid;
  d.a.report(eu); assert(!d.a.friends().find((f) => f.uid === eu)); await e.a.addFriend(d.a.id).catch(() => {}); await sleep(500); assert(!d.a.friends().find((f) => f.uid === eu)); ok("report = block + remove, repeat requests dropped"); e.a.stop();
  // full groups
  a.ev.length = 0; b.a.setOptions({ typing: true }); a.a.setOptions({ typing: true });
  const g = await a.a.createGroup("شلة", [ab, ac]); await wait(() => b.a.groups().length && c.a.groups().length); ok("group created");
  await a.a.addMember(g, ad); await wait(() => d.a.groups().length === 1 && b.a.groups()[0].members.length === 4); ok("admin added member; all members updated");
  await assert.rejects(() => b.a.addMember(g, u(b, a))); ok("non-admin cannot add");
  const bc = b.a.groups()[0].members.find((m) => m.name === "Carol").uid, bd = b.a.groups()[0].members.find((m) => m.name === "Dave").uid;
  const fakeGm = b.a.groups()[0]; // B (not admin) tries to remove via _gm forged
  await b.a._gm({ name: "x", admin: ba, ad: {}, members: { [ba]: {} } }, g.slice(2)).catch(() => {}); await sleep(500); assert(c.a.groups().length === 1 && c.a.groups()[0].name === "شلة"); ok("forged group update by non-admin ignored");
  await a.a.makeAdmin(g, ab, true); await wait(() => b.a.groups()[0].admin); ok("promoted B to admin");
  await b.a.removeMember(g, bd); await wait(() => !d.a.groups().length && d.ev.some((x) => x.t === "removed")); await wait(() => a.a.groups()[0].members.length === 3); ok("admin B removed Dave; Dave's copy deleted; A updated");
  // receipts + typing in group
  const m = await a.a.send(g, "group hello"); await wait(() => b.a.messages(g).length && c.a.messages(g).length); await wait(() => a.a.messages(g)[0].st === 1); ok("group delivered tick after all members received");
  await b.a.markRead(g); await c.a.setOptions({ read: true }); await c.a.markRead(g); await sleep(500); ok("group markRead ok (read tick needs read receipts on every member)");
  a.ev.length = 0; await b.a.groupTyping(g); await wait(() => a.ev.some((x) => x.t === "typing" && x.uid === g)); ok("typing in group");
  // channel
  const ch = await a.a.createChannel ? null : await a.a.createGroup("أخبار", [ab, ac], true); await wait(() => c.a.groups().find((x) => x.ch)); const cch = c.a.groups().find((x) => x.ch).chat;
  await c.a.send(cch, "subscriber post").catch(() => {}); await sleep(600); assert(!a.a.messages(ch).some((x) => x.t === "subscriber post")); await a.a.send(ch, "news"); await wait(() => c.a.messages(cch).some((x) => x.t === "news")); ok("channel: only admins post");
  // status
  await a.a.postStatus("حالتي", "#aa3366"); await wait(() => b.a.statuses().friends.length === 1); assert(b.a.statuses().friends[0].items[0].t === "حالتي" && a.a.statuses().mine.length === 1); ok("status delivered to friends");
  const dump = JSON.stringify(await (await rw("https://fake-db/.json?auth=t")).json()); assert(!dump.includes("حالتي") && !dump.includes("group hello")); ok("server dump has no status or group text");
  for (const x of [a, b, c, d]) x.a.stop(); process.exit(0);
})().catch((e) => { console.error("FAIL", e); process.exit(1); });
