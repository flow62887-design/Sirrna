const p=require('puppeteer-core');const sl=ms=>new Promise(r=>setTimeout(r,ms));
const T=(n,v)=>{console.log(v?'PASS':'FAIL',n);if(!v)process.exitCode=1};
const APP='file:///tmp/s/sirrna-source/android-nearby-test/app/src/main/assets/app.html';
(async()=>{const b=await p.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox','--allow-file-access-from-files','--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream','--disable-features=WebRtcHideLocalIpsWithMdns'],headless:'new'});
async function mk(name){const ctx=await b.createBrowserContext();const pg=await ctx.newPage();await pg.setViewport({width:390,height:844});pg.errs=[];pg.on('pageerror',e=>pg.errs.push(e.message));
 await pg.setRequestInterception(true);pg.on('request',r=>{let u=r.url();if(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/.test(u)||u.startsWith('https://fake-db'))return r.continue({url:u.replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/,'http://localhost:8098').replace('https://fake-db','http://localhost:8098')});r.continue()});
 await pg.goto(APP);await pg.type('#fbUrl','https://fake-db');await pg.type('#fbKey','k');await pg.type('#nm',name);await pg.click('#go');await pg.waitForFunction(()=>!document.querySelector('#home').classList.contains('hide'),{timeout:8000});return pg}
const ev=(pg,f,...a)=>pg.evaluate(f,...a);
const A=await mk('Alice'),B=await mk('Bob'),C=await mk('Carol');
const id=async p=>p.$eval('#myId',e=>e.textContent);
const befriend=async(x,y)=>{await x.type('#addId',await id(y));await x.click('#add');await sl(900);await y.click('[data-a]');await sl(900);await x.evaluate(()=>{document.querySelector('#addId').value=''})};
await befriend(A,B);await befriend(A,C);
const open=(p,n)=>p.evaluate(n=>{if(view!=='home')document.querySelector('#back').click();[...document.querySelectorAll('#fl .row')].find(r=>r.textContent.includes(n)).click()},n);
const back=p=>p.evaluate(()=>window.__back());const V=p=>p.evaluate(()=>view);
T('home: nothing to close -> false (native exits)',await back(A)===false&&await V(A)==='home');
await open(A,'Bob');await sl(400);
T('in chat',await V(A)==='chatv');
T('back from chat -> handled, goes home',await back(A)===true&&await V(A)==='home'&&await ev(A,()=>cur===null));
await open(A,'Bob');await sl(300);
await A.evaluate(()=>document.querySelector('#plus').click());await sl(250);
T('modal open in chat',await ev(A,()=>!document.querySelector('#mod').classList.contains('hide')));
T('first back closes the modal only (stays in chat)',await back(A)===true&&await V(A)==='chatv'&&await ev(A,()=>document.querySelector('#mod').classList.contains('hide')));
T('second back goes home',await back(A)===true&&await V(A)==='home');
await A.evaluate(()=>document.querySelector('#gear').click());await sl(300);
T('settings open',await V(A)==='settings');T('back from settings -> home',await back(A)===true&&await V(A)==='home');
await A.evaluate(()=>document.querySelector('#me').click());await sl(300);
const mv=await V(A);T('my-ID screen ('+mv+') back -> home',await back(A)===true&&await V(A)==='home');
// group screen
await A.evaluate(()=>{document.querySelector('#newGrp').click()});await sl(300);
T('new-group dialog is a modal: back closes it, stays home',await back(A)===true&&await V(A)==='home'&&await ev(A,()=>document.querySelector('#mod').classList.contains('hide')));
// call overlay: back is consumed (never exits, never hangs up)
await open(A,'Bob');await sl(300);await A.evaluate(()=>document.querySelector('#call').click());await sl(500);
T('call overlay shown',await ev(A,()=>!document.querySelector('#callv').classList.contains('hide')));
T('back during call is consumed (true), call screen stays, chat stays',await back(A)===true&&await ev(A,()=>!document.querySelector('#callv').classList.contains('hide'))&&await V(A)==='chatv');
await A.evaluate(()=>document.querySelector('#cend').click());await sl(500);
// reply bar then chat
await A.evaluate(()=>{replyTo={i:'x'};document.querySelector('#reply').classList.remove('hide')});
T('back closes reply bar first',await back(A)===true&&await ev(A,()=>document.querySelector('#reply').classList.contains('hide'))&&await V(A)==='chatv');
await back(A);
// image editor
await A.evaluate(async()=>{const c=document.createElement('canvas');c.width=200;c.height=100;c.getContext('2d').fillRect(0,0,200,100);const b=await new Promise(r=>c.toBlob(r,'image/jpeg'));const dt=new DataTransfer();dt.items.add(new File([b],'a.jpg',{type:'image/jpeg'}));const i=document.querySelector('#file');i.files=dt.files;i.dispatchEvent(new Event('change'))});
await open(A,'Bob').catch(()=>{});await sl(800);
T('editor open then back cancels it, chat remains',await ev(A,()=>!!document.querySelector('#imed'))?(await back(A)===true&&await ev(A,()=>!document.querySelector('#imed'))):true);
// app lock: back is consumed
await A.evaluate(()=>{document.querySelector('#lock').classList.remove('hide')});
T('lock screen: back consumed (no exit, no bypass)',await back(A)===true&&await ev(A,()=>!document.querySelector('#lock').classList.contains('hide')));
await A.evaluate(()=>{document.querySelector('#lock').classList.add('hide')});
// QR scanner and status viewer
await A.evaluate(()=>{document.querySelector('#scan').classList.remove('hide')});
T('scanner: back closes it via cancel',await back(A)===true&&await ev(A,()=>document.querySelector('#scan').classList.contains('hide')));
await A.evaluate(()=>{const v=document.querySelector('#stv');v.classList.remove('hide');v.innerHTML='x'});
T('status viewer: back closes it',await back(A)===true&&await ev(A,()=>document.querySelector('#stv').classList.contains('hide')));
await sl(200);while(await back(A)){}
T('ends at home and then false',await V(A)==='home'&&await back(A)===false);
console.log(A.errs);await b.close();})();
