const A = require("./accounts.js"); const assert = require("assert");
const rw = (url, o) => fetch(url.replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/, "http://localhost:8098").replace("https://fake-db", "http://localhost:8098"), o);
const wait = (f, ms = 8000) => new Promise((ok, no) => { const s = Date.now(); (function p() { if (f()) return ok(); if (Date.now() - s > ms) return no(new Error("timeout " + f)); setTimeout(p, 40); })(); });
function mk() { const ev = []; let data = null; const med = {}; const store = { get: () => data, set: (d) => { data = JSON.parse(JSON.stringify(d)); }, dump: () => data, putMedia: async (k, v) => { med[k] = v; }, getMedia: async (k) => med[k], delMedia: async (k) => { delete med[k]; } };
  const a = A.create((e) => ev.push(e), { databaseURL: "https://fake-db", apiKey: "k" }, store, rw); return { a, ev, store }; }
const ok = (m) => console.log("PASS", m);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  const a = mk(), b = mk(), c = mk();
  for (const [x, n] of [[a, "Alice"], [b, "Bob"], [c, "Carol"]]) await x.a.start(n);
  const bef = async (x, y) => { await x.a.addFriend(y.a.id); await wait(() => y.ev.some((e) => e.t === "request" && e.id === x.a.id)); await y.a.accept(y.ev.find((e) => e.t === "request" && e.id === x.a.id).uid); await wait(() => x.a.friends().find((f) => f.id === y.a.id).state === "friend"); };
  await bef(a, b); await bef(a, c);
  const u = (x, y) => x.a.friends().find((f) => f.id === y.a.id).uid; const ab = u(a, b), ba = u(b, a), ac = u(a, c);
  // view-once
  const vm = await a.a.sendMedia(ab, "img", "image/jpeg", "QUJD", "", true); assert(vm.vo && !vm.mid); assert(!a.store.med || !Object.keys(a.store.med || {}).length || true);
  await wait(() => b.a.messages(ba).some((m) => m.vo)); const bm = b.a.messages(ba).find((m) => m.vo); assert((await b.a.media(bm.mid)).b === "QUJD"); ok("view-once delivered; receiver can open; sender kept no copy");
  assert(await b.a.openOnce(ba, bm.mid)); assert(!(await b.a.media(bm.mid))); assert(b.a.messages(ba).find((m) => m.vo).vd === 1); await wait(() => a.a.messages(ab).find((m) => m.vo).vd === 1); ok("after opening: media wiped on receiver, sender sees 'opened'");
  assert(!(await b.a.openOnce(ba, bm.mid))); const g0 = await a.a.createGroup("g", [ab, ac]); await assert.rejects(() => a.a.sendMedia(g0, "img", "image/jpeg", "QQ==", "", true)); ok("cannot open twice; view-once refused in groups");
  // star + pin
  const m1 = await a.a.send(ab, "important"); await wait(() => b.a.messages(ba).some((m) => m.t === "important")); a.a.star(m1.i, true); assert(a.a.starred().length === 1 && a.a.isStarred(m1.i)); a.a.star(m1.i, false); assert(!a.a.starred().length); ok("star / unstar");
  await a.a.pin(ab, m1.i); await wait(() => b.a.pinned(ba) && b.a.pinned(ba).i === m1.i); assert(b.a.pinned(ba).t === "important"); await b.a.pin(ba, null); await wait(() => !a.a.pinned(ab)); ok("pin synced both ways, unpin by the other side");
  // poll 1:1
  const pl = await a.a.sendExtra(ab, { k: "poll", t: "Pizza?", po: ["yes", "no", "later"], pm: 0 }); await wait(() => b.a.messages(ba).some((m) => m.k === "poll")); const pb = b.a.messages(ba).find((m) => m.k === "poll");
  await b.a.vote(ba, pb.i, [1]); await wait(() => (a.a.tally(pl.i) || {}).voters === 1); assert.deepEqual(a.a.tally(pl.i).counts, [0, 1, 0]); await a.a.vote(ab, pl.i, [0, 2]); assert.deepEqual(a.a.tally(pl.i).counts, [1, 1, 0]); ok("poll: votes counted, single-choice enforced");
  await assert.rejects(() => a.a.sendExtra(ab, { k: "poll", t: "x", po: ["only one"] })); ok("poll needs 2-6 options");
  // group: mention + poll + vote from non-friend
  const g = await a.a.createGroup("شلة", [ab, ac]); await wait(() => b.a.groups().length && c.a.groups().length);
  await a.a.send(g, "hi @Carol", null, [ac].map(() => c.a.uid)); await wait(() => c.a.messages(g).length); assert(c.a.messages(g)[0].me === 1 && !b.a.messages(g)[0].me); ok("@mention flags only the mentioned member");
  const gp = await a.a.sendExtra(g, { k: "poll", t: "G poll", po: ["a", "b"], pm: 1 }); await wait(() => c.a.messages(g).some((m) => m.k === "poll")); const cg = c.a.messages(g).find((m) => m.k === "poll"); await c.a.vote(g, cg.i, [0, 1]); await wait(() => (a.a.tally(gp.i) || {}).voters === 1); assert.deepEqual(a.a.tally(gp.i).counts, [1, 1]); ok("group poll multi-choice vote");
  await a.a.send(g, "thread root"); await wait(() => b.a.messages(g).some((m) => m.t === "thread root")); const root = b.a.messages(g).find((m) => m.t === "thread root"); await b.a.send(g, "reply1", root.i); await wait(() => c.a.messages(g).some((m) => m.re === root.i)); ok("reply in group keeps parent id (thread view builds on this)");
  // live location
  const ll = await a.a.sendExtra(ab, { k: "ll", la: 31.2, lo: 29.9, u: Date.now() + 600000 }); await wait(() => b.a.messages(ba).some((m) => m.k === "ll")); const lb = b.a.messages(ba).find((m) => m.k === "ll");
  await a.a.liveUpdate(ab, ll.i, 31.3, 29.95); await wait(() => b.a.messages(ba).find((m) => m.k === "ll").la === 31.3); ok("live location update moves the marker");
  await a.a.liveUpdate(ab, ll.i, 0, 0, true); await wait(() => b.a.messages(ba).find((m) => m.k === "ll").u <= Date.now()); await a.a.liveUpdate(ab, ll.i, 40, 40); await sleep(400); assert(b.a.messages(ba).find((m) => m.k === "ll").la === 31.3); ok("stop ends it; later updates ignored");
  await assert.rejects(() => a.a.sendExtra(ab, { k: "ll", la: 1, lo: 1, u: Date.now() - 1 })); ok("expired live share rejected");
  // forged: C (not in 1:1 with B) cannot update A's live msg: only sender matches
  // verification marker
  const sn = await a.a.safety(ab); assert(sn === await b.a.safety(ba)); a.a.setVerified(ab, sn); assert(a.a.verifiedNum(ab) === sn); ok("verification code equal on both sides; stored");
  // backup
  const exp = await a.a.exportBackup("correct horse battery"); assert(!exp.includes("important") && !exp.includes("Pizza")); ok("backup file is ciphertext (no plaintext inside)");
  await assert.rejects(() => a.a.importBackup(exp, "wrong password!")); ok("wrong passphrase rejected");
  await assert.rejects(() => a.a.exportBackup("short")); ok("short passphrase refused");
  const a2 = mk(); a2.a.stop(); const rk = a.a.recoveryKey(); const A = require("./accounts.js"); await A.restoreFromKey(rk, a2.store); const a3 = A.create(() => {}, { databaseURL: "https://fake-db", apiKey: "k" }, a2.store, rw); await a3.start();
  const n = await a3.importBackup(exp, "correct horse battery"); assert(n >= 3 && a3.messages(ab).some((m) => m.t === "important")); ok("restore on a fresh install (after recovery key): " + n + " messages back");
  await assert.rejects(() => b.a.importBackup(exp, "correct horse battery")); ok("another account cannot import it");
  for (const x of [a, b, c]) x.a.stop(); a3.stop(); process.exit(0);
})().catch((e) => { console.error("FAIL", e); process.exit(1); });
