const p=require('puppeteer-core');const sl=ms=>new Promise(r=>setTimeout(r,ms));
const T=(n,v)=>{console.log(v?'PASS':'FAIL',n);if(!v)process.exitCode=1};
const APP='file:///tmp/s/sirrna-source/android-nearby-test/app/src/main/assets/app.html';
(async()=>{const b=await p.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox','--allow-file-access-from-files','--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream','--disable-features=WebRtcHideLocalIpsWithMdns'],headless:'new'});
async function mk(name){const ctx=await b.createBrowserContext();const pg=await ctx.newPage();await pg.setViewport({width:390,height:844});pg.errs=[];pg.on('pageerror',e=>pg.errs.push(e.message));
 await pg.setRequestInterception(true);pg.on('request',r=>{let u=r.url();if(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/.test(u)||u.startsWith('https://fake-db'))return r.continue({url:u.replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/,'http://localhost:8098').replace('https://fake-db','http://localhost:8098')});r.continue()});
 await pg.goto(APP);await pg.type('#fbUrl','https://fake-db');await pg.type('#fbKey','k');await pg.type('#nm',name);await pg.click('#go');await pg.waitForFunction(()=>!document.querySelector('#home').classList.contains('hide'),{timeout:8000});return pg}
const ev=(pg,f,...a)=>pg.evaluate(f,...a);
const A=await mk('Alice'),B=await mk('Bob'),C=await mk('Carol');
const id=async p=>p.$eval('#myId',e=>e.textContent);
const befriend=async(x,y)=>{await x.type('#addId',await id(y));await x.click('#add');await sl(900);await y.click('[data-a]');await sl(900);await x.evaluate(()=>{document.querySelector('#addId').value=''})};
await befriend(A,B);await befriend(A,C);
const open=(p,n)=>p.evaluate(n=>{if(view!=='home')document.querySelector('#back').click();[...document.querySelectorAll('#fl .row')].find(r=>r.textContent.includes(n)).click()},n);
// animated sticker
await open(A,'Bob');await sl(400);
await A.evaluate(()=>{window.stickerPicker()});await sl(300);
T('picker lists 10 animated stickers',await ev(A,()=>document.querySelectorAll('#modB [data-s^=a_]').length===10));
await A.evaluate(()=>document.querySelector('#modB [data-s=a_heart]').click());await sl(1200);
T('A sees animated sticker with live CSS animation',await ev(A,()=>{const e=document.querySelector('#chat .stk svg *');if(!e)return false;return [...document.querySelectorAll('#chat .stk svg *')].some(n=>{const a=getComputedStyle(n).animationName;return a&&a!=='none'})}));
await open(B,'Alice');await sl(800);
T('B receives animated sticker',await ev(B,()=>!!document.querySelector('#chat .stk svg')&&document.querySelector('#chat').innerHTML.includes('animation')));
await A.screenshot({path:'/tmp/qrl/v141sticker.png'});console.log(await ev(A,()=>[typeof cur,cur&&cur.uid,document.querySelector('#chat').innerHTML.slice(0,400)]));
// GIF
const gif='R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==';
await A.evaluate(async g=>{const r=await fetch('data:image/gif;base64,'+g);const b=await r.blob();const f=new File([b],'a.gif',{type:'image/gif'});const dt=new DataTransfer();dt.items.add(f);const i=document.querySelector('#file');i.files=dt.files;i.dispatchEvent(new Event('change'))},gif);await sl(1500);
T('A sent GIF as-is (image/gif, no editor)',await ev(A,()=>!document.querySelector('#imed')&&[...document.querySelectorAll('#chat img')].some(i=>i.src.startsWith('data:image/gif;base64,'))));
await sl(800);
T('B received GIF intact',await ev(B,()=>[...document.querySelectorAll('#chat img')].some(i=>i.src.startsWith('data:image/gif;base64,R0lGOD'))));
T('no page errors',A.errs.length+B.errs.length+C.errs.length===0);
if(A.errs.length)console.log(A.errs,B.errs);
await b.close();})();
