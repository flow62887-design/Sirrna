const p=require('puppeteer-core');const sl=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{const b=await p.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox'],headless:'new'});
const mk=async()=>{const pg=await b.newPage();await pg.setViewport({width:390,height:844,deviceScaleFactor:2,isMobile:true});pg.errs=[];pg.on('pageerror',e=>pg.errs.push(e.message));await pg.goto('file:///tmp/s/sirrna-source/android-nearby-test/app/src/main/assets/index.html');return pg};
const T=(n,v)=>console.log(v?'PASS':'FAIL',n);
async function run(pinA,pinB,tag){
 console.log("mk");const a=await mk(),c=await mk();console.log("mk2");
 for(const [pg,n,pn] of [[a,'أحمد',pinA],[c,'سعيد',pinB]]){await pg.evaluate((n,pn)=>{document.querySelector('#name').value=n;document.querySelector('#pin').value=pn;document.querySelector('#bStart').click()},n,pn)}
 console.log("started");await sl(8000);return [a,c]}
let [a,c]=await run('123456','123456');
const st=async pg=>pg.$eval('#status',e=>e.textContent);
console.log('A status:',await st(a));console.log('C status:',await st(c));
console.log('digits',await a.$eval('#digits',e=>e.textContent),await c.$eval('#digits',e=>e.textContent));
await (await b.newPage()).evaluate(()=>{window.__w=[];new BroadcastChannel('nearby-mock').onmessage=m=>window.__w.push(JSON.stringify(m.data))});await a.evaluate(()=>{msg.value='أهلا يا سعيد';bSend.click()});await sl(800);
await c.evaluate(()=>{msg.value='أهلا يا أحمد';bSend.click()});await sl(800);
await a.evaluate(()=>bPing.click());await sl(800);
const ca=await a.$eval('#chat',e=>e.textContent),cc=await c.$eval('#chat',e=>e.textContent);
T('msg A->C',cc.includes('أهلا يا سعيد'));T('msg C->A',ca.includes('أهلا يا أحمد'));T('ack',ca.includes('✓✓'));
console.log('rtt',await a.$eval('#rtt',e=>e.textContent));
console.log('LOG',(await a.$eval('#log',e=>e.textContent)).slice(-1500));
await a.bringToFront();await a.screenshot({path:'/downloads/chat/nt-ok-A.png'});await c.bringToFront();await c.screenshot({path:'/downloads/chat/nt-ok-B.png'});
console.log('errs',a.errs,c.errs);
await a.close();await c.close();
[a,c]=await run('123456','654321');
await sl(3000);console.log('WLOG',(await a.$eval('#log',e=>e.textContent)).slice(-600));console.log('WRONG A:',await st(a));console.log('WRONG C:',await st(c));
await a.evaluate(()=>{msg.value='سري';bSend.click()});await sl(500);
T('wrong pin no delivery',!(await c.$eval('#chat',e=>e.textContent)).includes('سري'));
await a.bringToFront();await a.screenshot({path:'/downloads/chat/nt-wrong-A.png'});
await b.close()})();
