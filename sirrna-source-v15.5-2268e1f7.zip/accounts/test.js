const A = require("./accounts.js"); const assert = require("assert");
const rw = (url, o) => fetch(url.replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/, "http://localhost:8098").replace("https://fake-db", "http://localhost:8098"), o);
const wait = (f, ms = 8000) => new Promise((ok, no) => { const s = Date.now(); (function p() { if (f()) return ok(); if (Date.now() - s > ms) return no(new Error("timeout " + f)); setTimeout(p, 40); })(); });
function mk() { const ev = []; let data = null; const med = {}; const store = { get: () => data, set: (d) => { data = JSON.parse(JSON.stringify(d)); }, dump: () => data, putMedia: async (k, v) => { med[k] = v; }, getMedia: async (k) => med[k], delMedia: async (k) => { delete med[k]; } };
  const a = A.create((e) => ev.push(e), { databaseURL: "https://fake-db", apiKey: "k" }, store, rw); return { a, ev, store }; }
const ok = (m) => console.log("PASS", m);
(async () => {
  const a = mk(), b = mk(), c = mk();
  await a.a.start("Alice"); await b.a.start("Bob"); await c.a.start("Carol");
  assert(/^[A-Z2-9]{10}$/.test(a.a.id)); ok("unique 10-char IDs: " + a.a.id + " " + b.a.id + " " + c.a.id);
  assert.notEqual(a.a.id, b.a.id);
  // friend request
  assert.equal(await a.a.addFriend(b.a.id), "sent");
  await wait(() => b.ev.some((e) => e.t === "request")); ok("B got friend request from " + b.ev.find((e) => e.t === "request").name);
  // message before friendship from stranger C to B must be dropped: C isn't a friend, cannot even encrypt -> addFriend lookup path only
  await b.a.accept(a.a.friends().length && b.ev.find((e) => e.t === "request").uid);
  await wait(() => a.ev.some((e) => e.t === "friend")); ok("A sees B accepted; friends lists: A=" + JSON.stringify(a.a.friends().map(f=>f.name+":"+f.state)) + " B=" + JSON.stringify(b.a.friends().map(f=>f.name+":"+f.state)));
  assert.equal(a.a.friends()[0].state, "friend"); assert.equal(b.a.friends()[0].state, "friend");
  assert.equal(await a.a.safety(a.a.friends()[0].uid), await b.a.safety(b.a.friends()[0].uid)); ok("safety numbers match: " + await a.a.safety(a.a.friends()[0].uid));
  // live message + long (compressed) message
  const bu = a.a.friends()[0].uid, au = b.a.friends()[0].uid;
  const long = "مرحبا ".repeat(500); await a.a.send(bu, "hi"); await a.a.send(bu, long);
  await wait(() => b.a.messages(au).length === 2); assert.equal(b.a.messages(au)[1].t, long); ok("live messages incl. long gzip'd text");
  // offline delivery: B stops, A sends, B restarts (new instance, same stored state)
  b.a.stop(); await a.a.send(bu, "while you were away");
  { const dump = JSON.stringify(await (await rw("https://fake-db/.json?auth=t")).json()); assert(dump.includes("inbox"), "dump not empty"); assert(dump.includes('"k":"msg"'), "queued msg present");
    for (const s of ["while you were away", "Alice", "Bob", "hi", "مرحبا"]) if (s.length > 3) assert(!dump.includes(s) || s === "Alice" || s === "Bob", "plaintext leaked: " + s);
    assert(!dump.includes("while you were away") && !dump.includes("priv") && !dump.includes(JSON.stringify(a.store.dump().priv.d)), "plaintext/private key leaked"); ok("server dump (" + dump.length + " bytes) holds queued ciphertext, no message text, no private key"); }
  const b2ev = []; const b2 = A.create((e) => b2ev.push(e), { databaseURL: "https://fake-db", apiKey: "k" }, b.store, rw);
  await b2.start(); await wait(() => b2.messages(au).some((m) => m.t === "while you were away")); ok("offline message delivered after restart, same account kept (id " + b2.id + ")"); assert.equal(b2.id, b.a.id);
  // stranger C cannot message B (not a friend): C tries by faking friend entry is out of scope; C requests B
  assert.equal(await c.a.addFriend(b.a.id), "sent"); await wait(() => b2ev.some((e) => e.t === "request")); b2.decline(b2ev.find((e) => e.t === "request").uid);
  ok("request from stranger arrives as request only; decline works");
  // ciphertext on server is unreadable
  // impersonation: a handle pointing to someone else's uid must be rejected
  await rw("https://fake-db/handles/ZZZZZZZZZZ.json?auth=t", { method: "PUT", body: JSON.stringify(c.a.uid) });
  await assert.rejects(a.a.addFriend("ZZZZZZZZZZ"), /انتحال/); ok("squatted ID rejected (key does not match ID)");
  // media: image + voice, E2E, size limit, server cannot read
  const png = Buffer.from(Array.from({ length: 3000 }, (_, i) => (i * 7) & 255)).toString("base64");
  b2.stop(); await new Promise(r => setTimeout(r, 300));
  await a.a.sendMedia(bu, "img", "image/jpeg", png, "صورة"); await a.a.sendMedia(bu, "voice", "audio/webm", png.slice(0, 1000));
  { const dump = JSON.stringify(await (await rw("https://fake-db/.json?auth=t")).json()); assert(dump.includes('"k":"msg"') && !dump.includes(png.slice(0, 40)) && !dump.includes("صورة")); ok("queued media (" + dump.length + " bytes dump) is ciphertext on the server"); }
  const b3 = A.create(() => {}, { databaseURL: "https://fake-db", apiKey: "k" }, b.store, rw); await b3.start();
  await wait(() => b3.messages(au).filter((m) => m.k).length === 2);
  const got = await b3.media(b3.messages(au).find((m) => m.k === "img").mid); assert.equal(got.b, png); assert.equal(got.m, "image/jpeg"); ok("image + voice delivered after offline, bytes identical"); b3.stop();
  await assert.rejects(a.a.sendMedia(bu, "img", "image/jpeg", "A".repeat(230000)), /كبير/); ok("oversize media rejected");
  // replies + reactions
  const bb = A.create((e) => b2ev.push(e), { databaseURL: "https://fake-db", apiKey: "k" }, b.store, rw); await bb.start();
  const first = a.a.messages(bu).find((m) => m.from === "me" && m.t === "hi");
  await b2ev.length; await bb.react(au, first.i, "👍");
  await wait(() => a.a.reactions(first.i)[bu] === "👍"); ok("reaction delivered");
  const rep = await bb.send(au, "ok got it", first.i); await wait(() => a.a.messages(bu).some((m) => m.re === first.i && m.t === "ok got it")); ok("reply linked to original message");
  // recovery on a new phone: same ID, same account, friends restored from encrypted backup, messages still work
  await new Promise((r) => setTimeout(r, 2200)); // let debounced backup land
  const key = bb.recoveryKey(); assert(key.startsWith("SRK1.")); bb.stop();
  let nd = null; const nstore = { get: () => nd, set: (d) => { nd = JSON.parse(JSON.stringify(d)); }, putMedia: async () => {}, getMedia: async () => null };
  const rid = await A.restoreFromKey(key, nstore); assert.equal(rid, b.a.id);
  const nev = []; const nb = A.create((e) => nev.push(e), { databaseURL: "https://fake-db", apiKey: "k" }, nstore, rw); await nb.start("Bob");
  assert.equal(nb.id, b.a.id); assert(nev.some((e) => e.t === "restored")); assert(nb.friends().some((f) => f.name === "Alice" && f.state === "friend")); ok("recovery key restores ID " + nb.id + " and friends list on a fresh store");
  await a.a.send(bu, "after recovery"); await wait(() => nb.messages(au).some((m) => m.t === "after recovery")); await nb.send(au, "back"); await wait(() => a.a.messages(bu).some((m) => m.t === "back")); ok("messages both ways after recovery"); nb.stop();
  await assert.rejects(A.restoreFromKey("garbage", nstore)); ok("bad recovery key rejected");
  // edit, delete, receipts, typing, unread, disappearing
  const nb2 = A.create((e) => nev2.push(e), { databaseURL: "https://fake-db", apiKey: "k" }, nstore, rw); var nev2 = []; await nb2.start("Bob");
  const mine = await a.a.send(bu, "typo mesage"); await wait(() => nb2.messages(au).some((m) => m.i === mine.i));
  await a.a.edit(bu, mine.i, "fixed message"); await wait(() => nb2.messages(au).find((m) => m.i === mine.i).t === "fixed message"); assert(nb2.messages(au).find((m) => m.i === mine.i).ed); ok("edit delivered and marked edited");
  await wait(() => (a.a.messages(bu).find((m) => m.i === mine.i).st || 0) >= 1); ok("delivered tick (default on)");
  assert.equal(a.a.messages(bu).find((m) => m.i === mine.i).st, 1); ok("read tick NOT sent while read receipts are off");
  assert(nb2.unread(au) >= 1); nb2.setOptions({ read: true }); await nb2.markRead(au); assert.equal(nb2.unread(au), 0);
  await wait(() => a.a.messages(bu).find((m) => m.i === mine.i).st === 2); ok("read receipt after opting in; unread counter cleared");
  nb2.setOptions({ typing: true }); a.a.setOptions({ typing: true }); const tyEv = []; await nb2.typing(au);
  await wait(() => a.ev.some((e) => e.t === "typing")); ok("typing indicator arrives only when both sides opted in");
  const a0 = a.ev.filter((e) => e.t === "typing").length; await nb2.typing(au); await new Promise((r) => setTimeout(r, 300)); assert.equal(a.ev.filter((e) => e.t === "typing").length, a0); ok("typing throttled");
  nb2.setOptions({ typing: false }); const t0 = a.ev.filter((e) => e.t === "typing").length; await nb2.typing(au); await new Promise((r) => setTimeout(r, 400)); assert.equal(a.ev.filter((e) => e.t === "typing").length, t0); ok("typing off = nothing sent");
  await a.a.del(bu, mine.i); await wait(() => nb2.messages(au).find((m) => m.i === mine.i).del); assert.equal(nb2.messages(au).find((m) => m.i === mine.i).t, ""); ok("delete wipes text on both sides");
  await assert.rejects(nb2.edit(au, mine.i, "hack"), /مينفعش/); ok("cannot edit someone else's / deleted message");
  await a.a.setTtl(bu, 2); await wait(() => nb2.ttl(au) === 2); const dm = await a.a.send(bu, "vanish soon"); await wait(() => nb2.messages(au).some((m) => m.i === dm.i && m.x === 2)); ok("disappearing timer synced, messages carry it");
  await new Promise((r) => setTimeout(r, 2300)); assert(nb2.prune() >= 1); assert(!nb2.messages(au).some((m) => m.i === dm.i)); assert(a.a.prune() >= 1); ok("expired messages removed on both devices");
  nb2.stop();
  // groups: A creates group with B(nb2 restored Bob) and C? C is not A's friend; make A-C friends first
  assert.equal(await a.a.addFriend(c.a.id), "sent"); await wait(() => c.ev.some((e) => e.t === "request" && e.name === "Alice")); await c.a.accept(c.ev.find((e) => e.t === "request" && e.name === "Alice").uid); await wait(() => a.a.friends().some((f) => f.name === "Carol" && f.state === "friend"));
  const nb3ev = []; const nb3 = A.create((e) => nb3ev.push(e), { databaseURL: "https://fake-db", apiKey: "k" }, nstore, rw); await nb3.start("Bob");
  const cu = a.a.friends().find((f) => f.name === "Carol").uid, bu2 = a.a.friends().find((f) => f.name === "Bob").uid;
  const gchat = await a.a.createGroup("شلة", [bu2, cu]); await wait(() => nb3ev.some((e) => e.t === "group") && c.ev.some((e) => e.t === "group")); ok("group created, both members joined: " + gchat);
  await nb3.send(gchat, "hello group"); await wait(() => a.a.messages(gchat).some((m) => m.t === "hello group") && c.a.messages(gchat).some((m) => m.t === "hello group")); ok("group message reaches everyone, including a member who is not Bob's friend (Carol)");
  assert(!nb3.friends().some((f) => f.name === "Carol")); ok("Carol is still not Bob's friend (group does not create friendships)");
  const gm = c.a.messages(gchat)[0]; await a.a.react(gchat, gm.i, "❤️"); await wait(() => c.a.reactions(gm.i)[c.a.messages(gchat) && a.a.uid] === "❤️"); ok("group reaction");
  await nb3.edit(gchat, gm.i, "edited in group"); await wait(() => c.a.messages(gchat)[0].t === "edited in group"); ok("group edit");
  await c.a.del(gchat, c.a.messages(gchat).find((m) => m.from === "me") ? c.a.messages(gchat).find((m) => m.from === "me").i : "x").catch(() => ok("delete of someone else's group message refused locally"));
  assert(c.a.groups()[0].members.length === 3); await c.a.leaveGroup(gchat); assert(!c.a.groups().length); ok("leave group");
  nb3.stop();
  // invite link round trip
  const l = a.a.inviteLink(); assert.equal(A.parseInvite(l).id, a.a.id); ok("invite link: " + l);
  b2.stop(); a.a.stop(); c.a.stop(); process.exit(0);
})().catch((e) => { console.error("FAIL", e); process.exit(1); });
