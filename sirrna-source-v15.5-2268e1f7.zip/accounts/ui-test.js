const p=require('puppeteer-core');const sl=ms=>new Promise(r=>setTimeout(r,ms));
const T=(n,v)=>{console.log(v?'PASS':'FAIL',n);if(!v)process.exitCode=1};
const APP='file:///tmp/s/sirrna-source/android-nearby-test/app/src/main/assets/app.html';
(async()=>{const b=await p.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox','--allow-file-access-from-files','--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream'],headless:'new'});
async function mk(name){const ctx=await b.createBrowserContext();const pg=await ctx.newPage();await pg.setViewport({width:390,height:844});pg.errs=[];pg.on('pageerror',e=>pg.errs.push(e.message));
 await pg.setRequestInterception(true);pg.on('request',r=>{let u=r.url();if(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/.test(u)||u.startsWith('https://fake-db'))return r.continue({url:u.replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/,'http://localhost:8098').replace('https://fake-db','http://localhost:8098')});r.continue()});
 await pg.goto(APP);await pg.type('#fbUrl','https://fake-db');await pg.type('#fbKey','k');await pg.type('#nm',name);await pg.click('#go');await pg.waitForFunction(()=>!document.querySelector('#home').classList.contains('hide'),{timeout:8000});return pg}
const A=await mk('Alice'),B=await mk('Bob');
const idA=await A.$eval('#myId',e=>e.textContent),idB=await B.$eval('#myId',e=>e.textContent);T('both have IDs '+idA+' '+idB,/^[A-Z2-9]{10}$/.test(idA)&&idA!==idB);
// QR: render Alice's QR, decode with jsQR
await A.click('#me');await sl(300);const dec=await A.evaluate(()=>{const img=document.querySelector('#qr img');const c=document.createElement('canvas');c.width=img.naturalWidth;c.height=img.naturalHeight;const x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.drawImage(img,0,0);const d=x.getImageData(0,0,c.width,c.height);const r=jsQR(d.data,d.width,d.height);return r&&r.data});
T('QR decodes to invite link: '+dec,dec&&SirrnaParse(dec)===idA);function SirrnaParse(s){const m=/id=([A-Z2-9]{10})/.exec(s);return m&&m[1]}
await A.screenshot({path:'/tmp/qrl/mine.png'});await A.click('#back');
// Bob adds Alice by pasting the invite link parsed from QR content
await B.type('#addId',SirrnaParse(dec));await B.click('#add');await sl(800);
T('Alice sees request',await A.evaluate(()=>!!document.querySelector('[data-a]')));
await A.click('[data-a]');await sl(800);
T('Bob sees Alice as friend',await B.evaluate(()=>document.querySelector('#fl').textContent.includes('Alice')&&!document.querySelector('#fl').textContent.includes('بانتظار')));
await B.click('[data-c]');await B.type('#msg','أهلا يا أليس');await B.click('#send');await sl(800);
T('Alice gets toast with message',await A.evaluate(()=>document.querySelector('#toast').textContent.includes('أهلا')));
await A.click('[data-c]');await sl(300);T('Alice chat shows message',await A.evaluate(()=>document.querySelector('#chat').textContent.includes('أهلا يا أليس')));
await A.type('#msg','وصلت');await A.click('#send');await sl(800);T('Bob sees reply live',await B.evaluate(()=>document.querySelector('#chat').textContent.includes('وصلت')));

// image: big noisy PNG made in node-side page, uploaded through the file input
const big=await B.evaluate(()=>{const c=document.createElement('canvas');c.width=2400;c.height=1800;const x=c.getContext('2d');const g=x.createLinearGradient(0,0,2400,1800);g.addColorStop(0,'#e33');g.addColorStop(1,'#33e');x.fillStyle=g;x.fillRect(0,0,2400,1800);for(let i=0;i<4000;i++){x.fillStyle='hsl('+(i*37%360)+',70%,50%)';x.fillRect(Math.random()*2400,Math.random()*1800,30,30)}return c.toDataURL('image/png').split(',')[1]});
require('fs').writeFileSync('/tmp/qrl/big.png',Buffer.from(big,'base64'));T('source image is large: '+Math.round(big.length*0.75/1024)+'KB',big.length>400000);
const fi=await B.$('#file');await fi.uploadFile('/tmp/qrl/big.png');await sl(800);await B.evaluate(()=>{const b=[...document.querySelectorAll('#imed button')].find(x=>x.textContent.includes('إرسال'));b&&b.click()});await sl(2500);
const imgInfo=await A.evaluate(async()=>{await new Promise(r=>setTimeout(r,500));const m=document.querySelector('#chat img');return m?{w:m.naturalWidth,h:m.naturalHeight,len:m.src.length}:null});
T('Alice received compressed image '+JSON.stringify(imgInfo),imgInfo&&imgInfo.len<=200100+30&&imgInfo.w<=1024);
// voice: record ~2s from fake mic, stop, send
await B.click('#mic');await sl(2000);await B.click('#mic');await sl(2500);
const au=await A.evaluate(()=>{const a=document.querySelector('#chat .vp canvas');return a?{ok:1}:null});
T('Alice received voice note '+JSON.stringify(au),!!au);
await A.screenshot({path:'/tmp/qrl/chat.png'});

// pinned grid
await B.click('#back');await sl(200);await B.click('[data-p]');await sl(300);
T('Bob pinned grid shows Alice',await B.evaluate(()=>!document.querySelector('#pinCard').classList.contains('hide')&&document.querySelector('#pins').textContent.includes('Alice')));
await B.screenshot({path:'/tmp/qrl/home.png'});
await B.click('#pins .tile');await sl(400);
// reply + reaction
await A.click('#back');await sl(200);await A.click('#fl [data-c]');await sl(500);
await A.evaluate(()=>{const b=[...document.querySelectorAll('#chat .b')].find(x=>x.textContent.includes('أهلا يا أليس'));b.querySelector('.mm').click()});await sl(200);
await A.click('#sheet .em span');await sl(1200);
T('Bob sees reaction',await B.evaluate(()=>document.querySelector('#chat').textContent.includes('👍')));
await A.evaluate(()=>{const b=[...document.querySelectorAll('#chat .b')].find(x=>x.textContent.includes('أهلا يا أليس'));b.querySelector('.mm').click()});await sl(200);
await A.click('#shReply');await A.type('#msg','ردي على كلامك');await A.click('#send');await sl(1200);
T('Bob sees reply with quote',await B.evaluate(()=>[...document.querySelectorAll('#chat .b')].some(x=>x.textContent.includes('ردي على كلامك')&&x.querySelector('.q')&&x.querySelector('.q').textContent.includes('أهلا'))));
await B.screenshot({path:'/tmp/qrl/reply.png'});
// theme + saver + hide notif
await B.click('#gear');await B.select('#thm','light');await B.select('#acc','#1f9d6b');await B.click('#saver');await B.click('#hidn');
T('light theme applied',await B.evaluate(()=>document.body.classList.contains('light')&&getComputedStyle(document.documentElement).getPropertyValue('--acc').trim()==='#1f9d6b'));
await B.screenshot({path:'/tmp/qrl/settings.png'});
// data saver: smaller image
await B.evaluate(()=>document.querySelector('#back').click());await sl(200);await B.click('#pins .tile');await sl(300);
await (await B.$('#file')).uploadFile('/tmp/qrl/big.png');await sl(800);await B.evaluate(()=>{const b=[...document.querySelectorAll('#imed button')].find(x=>x.textContent.includes('إرسال'));b&&b.click()});await sl(2500);
const sv=await A.evaluate(async()=>{await new Promise(r=>setTimeout(r,500));const ims=[...document.querySelectorAll('#chat img')];const m=ims[ims.length-1];return m?{w:m.naturalWidth,len:m.src.length}:null});
T('data saver image smaller '+JSON.stringify(sv),sv&&sv.w<=640&&sv.len<imgInfo.len);
// hide notification content
console.log('B view',await B.evaluate(()=>view+' back-hidden:'+document.querySelector('#back').classList.contains('hide')+' pins:'+document.querySelector('#pins').children.length));await B.click('#back');await sl(300);await B.screenshot({path:'/tmp/qrl/Bdbg.png'});console.log('B back dbg',await B.evaluate(()=>{const e=document.querySelector('#back');return e.className+'|'+getComputedStyle(e).display+'|'+document.querySelectorAll('#back').length+'|'+e.parentElement.tagName+'|'+e.isConnected}));console.log('Bv',await B.evaluate(()=>view), await B.evaluate(()=>{try{document.querySelector('#back').onclick();return view+' ok'}catch(e){return 'ERR '+e.message}}), 'elementAtPoint', await B.evaluate(()=>{const r=document.querySelector('#back').getBoundingClientRect();const e=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return e&&(e.id||e.tagName)+' rect '+JSON.stringify([r.x,r.y,r.width,r.height])}));await A.click('#back');await sl(200);await A.click('#fl [data-c]');await sl(300);
await A.type('#msg','سر خطير');await A.click('#send');await sl(1500);
console.log('A chat tail:',await A.evaluate(()=>[...document.querySelectorAll('#chat .b')].slice(-2).map(x=>x.textContent).join(' | ')),'A view',await A.evaluate(()=>view),'B view',await B.evaluate(()=>view));
const tb=await B.evaluate(()=>({txt:document.querySelector('#toast').textContent,hid:document.querySelector('#toast').classList.contains('hide')}));console.log('toast on Bob:',JSON.stringify(tb));
T('notification content hidden when setting is on',tb.txt.includes('رسالة جديدة')&&!tb.txt.includes('سر خطير'));
// recovery key shown + lock
await B.click('#gear');await B.click('#rkBtn');const rk=await B.$eval('#rk',e=>e.value);T('recovery key shown',/^SRK1\./.test(rk));
await B.evaluate(()=>{window.prompt=()=>'2468'});await B.click('#lockBtn');await sl(600);
await B.evaluate(()=>{document.querySelector('#lockS').value='0';document.querySelector('#lockS').dispatchEvent(new Event('change'))});
await B.evaluate(()=>lockNow());await sl(100);T('lock overlay visible',await B.evaluate(()=>!document.querySelector('#lock').classList.contains('hide')));
await B.type('#lockIn','1111');await B.keyboard.press('Enter');await sl(600);T('wrong PIN keeps lock',await B.evaluate(()=>!document.querySelector('#lock').classList.contains('hide')));
await B.type('#lockIn','2468');await sl(800);T('right PIN unlocks',await B.evaluate(()=>document.querySelector('#lock').classList.contains('hide')));
// recovery in a fresh browser context
const C=await b.createBrowserContext();const cp=await C.newPage();cp.errs=[];cp.on('pageerror',e=>cp.errs.push(e.message));await cp.setRequestInterception(true);cp.on('request',r=>{let u=r.url();if(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/.test(u)||u.startsWith('https://fake-db'))return r.continue({url:u.replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/,'http://localhost:8098').replace('https://fake-db','http://localhost:8098')});r.continue()});
await cp.goto(APP);await cp.type('#fbUrl','https://fake-db');await cp.type('#fbKey','k');await cp.type('#nm','Bob');await cp.type('#rkIn',rk);await cp.click('#go');
await cp.waitForFunction(()=>!document.querySelector('#home').classList.contains('hide'),{timeout:8000});await sl(800);
T('recovered account has same ID and Alice as friend',(await cp.$eval('#myId',e=>e.textContent))===idB&&await cp.evaluate(()=>document.querySelector('#fl').textContent.includes('Alice')));
if(process.env.LONG){await B.evaluate(()=>{document.querySelector('#lock').classList.add('hide')});await B.click('#back').catch(()=>{});await B.click('#pins .tile');await sl(300);await B.click('#mic');await B.waitForFunction(()=>document.querySelector('#mic').textContent==='⏹',{timeout:10000});const t0=Date.now();await B.waitForFunction(()=>document.querySelector('#mic').textContent==='🎤',{timeout:75000,polling:500});console.log('voice auto-stopped after',Math.round((Date.now()-t0)/1000),'s');await sl(3000);
 const lv=await A.evaluate(()=>{const a=[...document.querySelectorAll('#chat audio')];const x=a[a.length-1];return x?x.src.length:0});console.log('LONG voice b64 chars',lv);T('60s voice delivered under DB limit',lv>1000&&lv<=220000)}
T('no page errors',A.errs.length+B.errs.length+cp.errs.length===0);if(A.errs.length+B.errs.length)console.log(A.errs,B.errs);
await b.close();process.exit()})().catch(e=>{console.error('FAIL',e);process.exit(1)});
