const p=require('puppeteer-core');const sl=ms=>new Promise(r=>setTimeout(r,ms));
const T=(n,v)=>{console.log(v?'PASS':'FAIL',n);if(!v)process.exitCode=1};
(async()=>{const b=await p.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox','--allow-file-access-from-files','--autoplay-policy=no-user-gesture-required']});
const pg=await b.newPage();await pg.setViewport({width:390,height:844});const errs=[];pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(/demo seed|grp/.test(m.text()))errs.push(m.text())});
const reqs=[];pg.on('request',r=>{const u=r.url();if(/^https?:/.test(u))reqs.push(u)});
await pg.goto('file:///tmp/da/app.html');
T('opens straight into home (no setup screen)',await pg.waitForFunction(()=>!document.querySelector('#home').classList.contains('hide'),{timeout:15000}).then(()=>true,()=>false));
T('demo badge visible',await pg.evaluate(()=>!!document.querySelector('#demoBadge')));
T('seeding finished',await pg.waitForFunction(()=>window.__demoReady===true,{timeout:90000}).then(()=>true,()=>false));
await sl(2500);
const info=await pg.evaluate(()=>({friends:acct.friends().filter(f=>f.state==='friend').length,groups:acct.groups().map(g=>g.name+(g.ch?'(قناة)':'')),unread:acct.friends().map(f=>f.name+':'+acct.messages(f.uid).length),st:acct.statuses().friends.length}));
console.log(JSON.stringify(info));
T('5 friends',info.friends===5);T('2 groups + channel',info.groups.length===3);T('statuses from friends',info.st>=2);
await pg.screenshot({path:'/tmp/qrl/demo-home.png'});
// open Mona chat (voice note, sticker)
await pg.evaluate(()=>{[...document.querySelectorAll('#fl .row')].find(r=>r.textContent.includes('منى')).click()});await sl(1200);
T('voice note rendered',await pg.evaluate(()=>!!document.querySelector('#chat .vp')));
T('animated sticker rendered',await pg.evaluate(()=>!!document.querySelector('#chat .stk svg')));
await pg.screenshot({path:'/tmp/qrl/demo-mona.png'});
// reply simulation
await pg.type('#msg','أهلًا يا منى');await pg.click('#send');await sl(1500);console.log('after send',await pg.evaluate(()=>[acct.messages(cur.uid).length,acct.messages(cur.uid).filter(m=>m.from==='me').length,document.querySelector('#toast').textContent,document.querySelector('#msg').value,cur&&cur.name]));
T('simulated reply arrives',await pg.waitForFunction(()=>acct.messages(cur.uid).filter(m=>m.from!=='me').length>=4&&[...document.querySelectorAll('#chat .b.them')].length>=4,{timeout:20000}).then(()=>true,()=>false));
await sl(1500);T('read/delivered ticks on my message',await pg.evaluate(()=>document.querySelectorAll('#chat .b.me .tk .ic-check').length>=1));
await pg.screenshot({path:'/tmp/qrl/demo-reply.png'});
// group with poll
await pg.evaluate(()=>{document.querySelector('#back').click()});await sl(300);
await pg.evaluate(()=>{[...document.querySelectorAll('#fl .row')].find(r=>r.textContent.includes('شلة الشغل')).click()});await sl(1200);
T('poll with votes in group',await pg.evaluate(()=>!!document.querySelector('#chat .poll')&&document.querySelector('#chat .poll').textContent.includes('كشري')));
await pg.screenshot({path:'/tmp/qrl/demo-group.png'});
// view once from Youssef
await pg.evaluate(()=>{document.querySelector('#back').click()});await sl(300);
await pg.evaluate(()=>{[...document.querySelectorAll('#fl .row')].find(r=>r.textContent.includes('يوسف')).click()});await sl(1200);
T('view-once present',await pg.evaluate(()=>!![...document.querySelectorAll('#chat button')].find(b=>b.dataset.vo)));
// call
await pg.evaluate(()=>{document.querySelector('#back').click()});await sl(300);
await pg.evaluate(()=>{[...document.querySelectorAll('#fl .row')].find(r=>r.textContent.includes('ماما')).click()});await sl(800);
await pg.evaluate(()=>document.querySelector('#call').click());await sl(500);
T('call ringing UI',await pg.evaluate(()=>!document.querySelector('#callv').classList.contains('hide')&&document.querySelector('#cst').textContent.includes('بيرن')));
await pg.screenshot({path:'/tmp/qrl/demo-call-ring.png'});await sl(3500);
T('call connects (simulated)',await pg.evaluate(()=>/\d\d:\d\d/.test(document.querySelector('#cst').textContent)));
await pg.evaluate(()=>document.querySelector('#cend').click());await sl(300);
T('call ended',await pg.evaluate(()=>document.querySelector('#callv').classList.contains('hide')));
const ext=reqs.filter(u=>!/^https:\/\/(demo\.local|identitytoolkit|securetoken)/.test(u));
T('no real network requests (only the fake backend hosts, which are intercepted in-page)',ext.length===0);console.log('http requests seen by browser:',reqs.length,'external:',ext);
console.log('errors:',errs);await b.close()})();
