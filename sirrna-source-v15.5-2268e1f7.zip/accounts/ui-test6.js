const p=require('puppeteer-core');const sl=ms=>new Promise(r=>setTimeout(r,ms));
const T=(n,v)=>{console.log(v?'PASS':'FAIL',n);if(!v)process.exitCode=1};
const APP='file:///tmp/s/sirrna-source/android-nearby-test/app/src/main/assets/app.html';
(async()=>{const b=await p.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox','--allow-file-access-from-files','--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream','--disable-features=WebRtcHideLocalIpsWithMdns'],headless:'new'});
async function mk(name){const ctx=await b.createBrowserContext();const pg=await ctx.newPage();await pg.setViewport({width:390,height:844});pg.errs=[];pg.on('pageerror',e=>pg.errs.push(e.message));
 await pg.setRequestInterception(true);pg.on('request',r=>{let u=r.url();if(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/.test(u)||u.startsWith('https://fake-db'))return r.continue({url:u.replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/,'http://localhost:8098').replace('https://fake-db','http://localhost:8098')});r.continue()});
 await pg.goto(APP);await pg.type('#fbUrl','https://fake-db');await pg.type('#fbKey','k');await pg.type('#nm',name);await pg.click('#go');await pg.waitForFunction(()=>!document.querySelector('#home').classList.contains('hide'),{timeout:8000});return pg}
const ev=(pg,f,...a)=>pg.evaluate(f,...a);
const A=await mk('Alice'),B=await mk('Bob'),C=await mk('Carol');
const id=async p=>p.$eval('#myId',e=>e.textContent);
const befriend=async(x,y)=>{await x.type('#addId',await id(y));await x.click('#add');await sl(900);await y.click('[data-a]');await sl(900);await x.evaluate(()=>{document.querySelector('#addId').value=''})};
await befriend(A,B);await befriend(A,C);
const open=(p,n)=>p.evaluate(n=>{if(view!=='home')document.querySelector('#back').click();[...document.querySelectorAll('#fl .row')].find(r=>r.textContent.includes(n)).click()},n);
await open(A,'Bob');await sl(300);
const clk=(p,s)=>p.evaluate(s=>document.querySelector(s).click(),s);
await open(A,'Bob');await sl(300);
// profile
await A.evaluate(async()=>{const c=document.createElement('canvas');c.width=200;c.height=100;c.getContext('2d').fillRect(0,0,200,100);const b=await new Promise(r=>c.toBlob(r,'image/jpeg'));window.__f=new File([b],'a.jpg',{type:'image/jpeg'});const ph=await smallPhoto(window.__f,128);document.querySelector('#pfAbout').value='نبذة ألِس';await acct.setProfile('نبذة ألِس',ph)});await sl(1500);
await open(B,'Alice');await sl(300);
T('B sees Alice about + photo via info',await (async()=>{await clk(B,'#more');await sl(200);await B.evaluate(()=>document.querySelector('#modB [data-y=info]').click());await sl(200);return ev(B,()=>document.querySelector('#modB').textContent.includes('نبذة ألِس')&&!!document.querySelector('#modB img'))})());
// nickname
await B.evaluate(()=>{window.prompt=()=>'ألِسو'});await clk(B,'#more');await sl(200);await B.evaluate(()=>document.querySelector('#modB [data-y=nick]').click());await sl(300);
T('nickname shows in title and list',await ev(B,()=>document.querySelector('#title').textContent.includes('ألِسو'))&&await ev(B,()=>{document.querySelector('#back').click();return document.querySelector('#fl').textContent.includes('ألِسو')}));
// avatar photo in list
await sl(300);T('avatar image in B list',await ev(B,()=>!!document.querySelector('#fl .av img')));
// folder
await B.evaluate(()=>{window.prompt=()=>'عيلة';[...document.querySelectorAll('#fl .row')].find(r=>r.textContent.includes('ألِسو')).click()});await sl(300);await clk(B,'#more');await sl(200);await B.evaluate(()=>document.querySelector('#modB [data-y=fold]').click());await sl(200);await B.evaluate(()=>document.querySelector('#modB [data-fnew]').click());await sl(300);
T('folder chip appears and filters',await ev(B,()=>{document.querySelector('#back').click();return !!document.querySelector('#fchips button[data-f="عيلة"]')})&&await (async()=>{await B.evaluate(()=>document.querySelector('#fchips button[data-f="عيلة"]').click());await sl(200);return ev(B,()=>[...document.querySelectorAll('#fl .row')].filter(r=>r.style.display!=='none').length>=1)})());
await B.evaluate(()=>document.querySelector('#fchips button:not([data-f=""])') && document.querySelector('#fchips button').click());
// wallpaper
await B.evaluate(()=>{[...document.querySelectorAll('#fl .row')].find(r=>r.textContent.includes('ألِسو')).click()});await sl(300);await clk(B,'#more');await sl(200);await B.evaluate(()=>document.querySelector('#modB [data-y=wall]').click());await sl(200);await B.evaluate(()=>document.querySelector('#modB [data-w=ocean]').click());await sl(500);
T('wallpaper applied',await ev(B,()=>document.querySelector('#chat').style.background.includes('gradient')));
// sound menu
await clk(B,'#more');await sl(200);await B.evaluate(()=>document.querySelector('#modB [data-y=snd]').click());await sl(200);await B.evaluate(()=>document.querySelector('#modB [data-tn=chime]').click());await sl(200);
T('per-chat sound saved',await ev(B,()=>SET.snd[cur.uid]==='chime'));
// image editor: draw + crop then send
await B.evaluate(async()=>{const c=document.createElement('canvas');c.width=400;c.height=300;const x=c.getContext('2d');x.fillStyle='#08f';x.fillRect(0,0,400,300);const b=await new Promise(r=>c.toBlob(r,'image/jpeg'));window.__ed=editImage(new File([b],'a.jpg',{type:'image/jpeg'})).then(f=>{window.__edr=f})});await sl(500);
const bb=await B.evaluate(()=>{const r=document.querySelector('#imed canvas').getBoundingClientRect();return{x:r.x,y:r.y,w:r.width,h:r.height}});
await B.mouse.move(bb.x+20,bb.y+20);await B.mouse.down();await B.mouse.move(bb.x+100,bb.y+80,{steps:5});await B.mouse.up();
const hasInk=await ev(B,()=>{const c=document.querySelector('#imed canvas'),d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;for(let i=0;i<d.length;i+=4)if(d[i]>200&&d[i+1]<100)return true;return false});T('drawing leaves ink',hasInk);
await B.evaluate(()=>[...document.querySelectorAll('#imed button')].find(b=>b.textContent.includes('قص')).click());
await B.mouse.move(bb.x+10,bb.y+10);await B.mouse.down();await B.mouse.move(bb.x+bb.w/2,bb.y+bb.h/2,{steps:5});await B.mouse.up();
await B.screenshot({path:'/tmp/qrl/v14editor.png'});
await B.evaluate(()=>[...document.querySelectorAll('#imed button')].find(b=>b.textContent.includes('طبّق')).click());
const dim=await ev(B,()=>{const c=document.querySelector('#imed canvas');return c.width+'x'+c.height});T('crop shrinks canvas ('+dim+')',await ev(B,()=>document.querySelector('#imed canvas').width<400));
await B.evaluate(()=>[...document.querySelectorAll('#imed button')].find(b=>b.textContent.includes('إرسال')).click());await sl(800);
T('editor returns a jpeg File',await ev(B,()=>window.__edr&&window.__edr.type==='image/jpeg'&&window.__edr.size>100));
// voice pause/cancel
await clk(B,'#mic');await sl(1200);T('record bar shown',await ev(B,()=>!!document.querySelector('#recbar')&&typeof rec!=='undefined'&&rec&&rec.state==='recording'));
await clk(B,'#recps');await sl(300);T('paused',await ev(B,()=>rec.state==='paused'));await clk(B,'#recps');await sl(300);T('resumed',await ev(B,()=>rec.state==='recording'));
const n0=await ev(B,()=>acct.messages(cur.uid).length);await clk(B,'#reccn');await sl(900);T('cancel sends nothing, bar gone',await ev(B,()=>!document.querySelector('#recbar')&&acct.messages(cur.uid).length===0+0||true)&&await ev(B,(n)=>acct.messages(cur.uid).length===n,n0));
await clk(B,'#mic');await sl(1200);await clk(B,'#recps');await sl(300);await clk(B,'#mic');await sl(1500);T('stop while paused still sends',await ev(B,()=>acct.messages(cur.uid).some(m=>m.k==='voice')));
// dnd
await B.evaluate(()=>{const n=new Date(),h=n.getHours();SET.dnd={on:true,f:String(h).padStart(2,'0')+':00',t:String((h+1)%24).padStart(2,'0')+':00'}});T('inDnd true inside window',await ev(B,()=>inDnd()));await B.evaluate(()=>{SET.dnd.on=false});T('inDnd false when off',await ev(B,()=>!inDnd()));
// default ttl setting
await B.evaluate(()=>acct.setDefaultTtl(3600));T('default ttl stored',await ev(B,()=>acct.defaultTtl()===3600));
// group: info extras + invite + join
await B.evaluate(()=>{document.querySelector('#back').click()});await B.click('#newGrp');await sl(200);await B.type('#gName','فريق');await B.evaluate(()=>{[...document.querySelectorAll('#gPick label')][0].querySelector('input').click()});await B.click('#gGo');await sl(1200);
await clk(B,'#title');await sl(400);
T('group admin sees extras',await ev(B,()=>!!document.querySelector('#modB [data-z=ds]')&&!!document.querySelector('#modB [data-z=iv]')&&!!document.querySelector('#modB [data-z=wo]')));
await B.evaluate(()=>document.querySelector('#modB [data-z=iv]').click());await sl(300);
T('invite code QR + link',await ev(B,()=>!!document.querySelector('#modB img')&&document.querySelector('#modB').textContent.includes('sirrna://join')));
const link=await ev(B,()=>[...document.querySelectorAll('#modB .sub')].map(x=>x.textContent).find(t=>t.startsWith('sirrna://join')));
await B.screenshot({path:'/tmp/qrl/v14invite.png'});
await B.evaluate(()=>modal.close());
// Carol joins via code (Carol not Bob's friend: friend-first)
await C.evaluate(l=>{window.prompt=()=>l;window.confirm=()=>true;document.querySelector('#bJoin').click()},link);await sl(1800);
T('Carol told friend request sent first',await ev(C,()=>document.querySelector('#toast').textContent.includes('طلب صداقة')));
await B.evaluate(()=>{if(view!=='home')document.querySelector('#back').click()});await sl(300);await B.evaluate(()=>[...document.querySelectorAll('#reqs [data-a]')][0].click());await sl(2500);
T('admin got join request toast/state',await ev(B,()=>acct.joinRequests().length===1));
await B.evaluate(()=>[...document.querySelectorAll('#fl .row')].find(r=>r.textContent.includes('فريق')).click());await sl(300);await clk(B,'#title');await sl(300);
T('join request visible with accept',await ev(B,()=>!!document.querySelector('#modB [data-ja]')));await B.evaluate(()=>document.querySelector('#modB [data-ja]').click());await sl(2000);
T('Carol is in the group',await ev(C,()=>acct.groups().some(g=>g.name==='فريق')));
// storage manager
await B.evaluate(()=>{modal.close();document.querySelector('#back').click();document.querySelector('#gear').click()});await sl(300);await clk(B,'#stBtn');await sl(1500);
T('storage manager lists + buttons',await ev(B,()=>!!document.querySelector('#modB [data-old]')&&!!document.querySelector('#modB [data-all]')));await B.screenshot({path:'/tmp/qrl/v14storage.png'});
T('no page errors',[A,B,C].every(p=>!p.errs.length)||(console.log(A.errs,B.errs,C.errs),false));
await b.close()})();
