/* Sirrna online transport: Firebase Realtime Database over REST + streaming (no SDK).
   Same interface as the native Nearby bridge: start/stop/send/disconnect + events via emit().
   cfg = {databaseURL, apiKey, secret}  (secret = shared code, use 10+ chars for online use) */
(function (root) {
  const enc = new TextEncoder(), dec = new TextDecoder();
  const b64 = (u) => btoa(String.fromCharCode(...u));
  const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
  const hex = (u) => [...u].map((x) => x.toString(16).padStart(2, "0")).join("");
  const sub = () => (root.crypto || globalThis.crypto).subtle;

  async function deriveKeys(secret) {
    const base = await sub().importKey("raw", enc.encode(secret), "PBKDF2", false, ["deriveBits"]);
    const bits = new Uint8Array(await sub().deriveBits(
      { name: "PBKDF2", hash: "SHA-256", salt: enc.encode("sirrna-online-v1"), iterations: 150000 }, base, 512));
    const key = await sub().importKey("raw", bits.slice(0, 32), "AES-GCM", false, ["encrypt", "decrypt"]);
    // room id is derived separately so the server never sees the AES key
    const room = hex(new Uint8Array(await sub().digest("SHA-256", bits.slice(32))));
    return { key, room: room.slice(0, 40) };
  }
  async function seal(key, text) {
    const iv = (root.crypto || globalThis.crypto).getRandomValues(new Uint8Array(12));
    const ct = new Uint8Array(await sub().encrypt({ name: "AES-GCM", iv }, key, enc.encode(text)));
    return b64(iv) + "." + b64(ct);
  }
  async function open(key, s) {
    const [iv, ct] = s.split(".");
    return dec.decode(await sub().decrypt({ name: "AES-GCM", iv: unb64(iv) }, key, unb64(ct)));
  }

  function create(emit, cfg, fetchFn) {
    const F = fetchFn || fetch.bind(root);
    const me = Math.random().toString(36).slice(2, 10);
    let st = null, token = "", refresh = "", tokTimer = null, ctl = null, run = false, gen = 0;
    let peer = null, name = "", keys = null, seen = new Set(), ready = false;
    const base = () => cfg.databaseURL.replace(/\/$/, "");
    const url = (p, q) => `${base()}/r/${keys.room}${p}.json?auth=${encodeURIComponent(token)}${q || ""}`;

    async function auth() {
      if (refresh) {
        const r = await F(`https://securetoken.googleapis.com/v1/token?key=${cfg.apiKey}`, { method: "POST",
          headers: { "content-type": "application/x-www-form-urlencoded" }, body: `grant_type=refresh_token&refresh_token=${refresh}` });
        const j = await r.json(); if (!j.id_token) throw new Error("auth refresh failed");
        token = j.id_token; refresh = j.refresh_token; return;
      }
      const r = await F(`https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${cfg.apiKey}`, { method: "POST",
        headers: { "content-type": "application/json" }, body: JSON.stringify({ returnSecureToken: true }) });
      const j = await r.json();
      if (!j.idToken) throw new Error("anonymous sign-in failed: " + ((j.error && j.error.message) || r.status));
      token = j.idToken; refresh = j.refreshToken;
    }
    async function post(obj) {
      const r = await F(url("/m"), { method: "POST", body: JSON.stringify(obj) });
      if (!r.ok) throw new Error("write " + r.status);
    }
    async function sendRaw(kind, payload) {
      await post({ f: me, k: kind, d: await seal(keys.key, payload), ts: Date.now() });
    }
    function peerUp(id, nm) {
      if (peer === id) return;
      peer = id;
      emit({ t: "initiated", id, name: "x|" + nm, digits: "" });
      emit({ t: "connected", id });
    }
    async function onEntry(key, v) {
      if (!v || seen.has(key) || v.f === me || !ready) return;
      seen.add(key);
      let txt; try { txt = await open(keys.key, v.d); } catch (e) { return; } // wrong secret or tampered: ignore
      if (peer && v.f !== peer && v.k !== "H") return;
      if (v.k === "H") {
        const first = peer !== v.f;
        peerUp(v.f, txt);
        if (first) sendRaw("H", name).catch(() => {});
      } else if (v.k === "D" && peer === v.f) emit({ t: "recv", data: txt });
      else if (v.k === "B" && peer === v.f) { peer = null; emit({ t: "disconnected", id: v.f }); }
    }
    async function listen(g) {
      while (run && g === gen) {
        try {
          ctl = new AbortController();
          const r = await F(url("/m"), { headers: { accept: "text/event-stream" }, signal: ctl.signal });
          if (!r.ok) throw new Error("listen " + r.status);
          const rd = r.body.getReader(); let buf = "", ev = "";
          for (;;) {
            const { value, done } = await rd.read(); if (done) break;
            buf += dec.decode(value, { stream: true });
            let i; while ((i = buf.indexOf("\n")) >= 0) {
              const line = buf.slice(0, i).replace(/\r$/, ""); buf = buf.slice(i + 1);
              if (line.startsWith("event:")) ev = line.slice(6).trim();
              else if (line.startsWith("data:") && (ev === "put" || ev === "patch")) {
                const m = JSON.parse(line.slice(5));
                if (m === null) continue;
                if (m.path === "/") {
                  if (!ready) { Object.keys(m.data || {}).forEach((k) => seen.add(k)); ready = true; helloNow(); }
                  else Object.entries(m.data || {}).forEach(([k, v]) => onEntry(k, v));
                } else onEntry(m.path.slice(1), m.data);
              } else if (line.startsWith("event:") === false && ev === "auth_revoked") throw new Error("auth revoked");
            }
          }
        } catch (e) { if (!(run && g === gen)) return; emit({ t: "log", msg: "online reconnect: " + e.message }); }
        if (run && g === gen) await new Promise((r) => setTimeout(r, 2000));
      }
    }
    function helloNow() { sendRaw("H", name).catch((e) => emit({ t: "error", msg: "hello: " + e.message })); emit({ t: "log", msg: "online: waiting for the other phone" }); }

    return {
      info: () => JSON.stringify({ sdk: 0, model: "online", gms: 0, bt: true, wifi: true, loc: true, locNeeded: false, missing: [], transport: "online" }),
      requestPerms() { emit({ t: "perms", missing: "[]" }); },
      setMode() {}, connectTo() {}, refreshPaired() {}, openBtSettings() {}, fixGms() {},
      async start(n) {
        name = n; run = true; peer = null; ready = false; seen = new Set(); const g = ++gen;
        try {
          if (!cfg.databaseURL || !cfg.apiKey) throw new Error("ادخل إعدادات Firebase الأول");
          if (!cfg.secret || cfg.secret.length < 6) throw new Error("الكود قصير");
          keys = await deriveKeys(cfg.secret);
          await auth();
          clearInterval(tokTimer); tokTimer = setInterval(() => auth().catch(() => {}), 45 * 60 * 1000);
          emit({ t: "log", msg: "online: signed in" });
          listen(g);
        } catch (e) { run = false; emit({ t: "error", msg: e.message }); }
      },
      send(d) { if (!peer) { emit({ t: "error", msg: "send: not connected" }); return; } sendRaw("D", d).catch((e) => emit({ t: "error", msg: "send: " + e.message })); },
      disconnect() { if (peer) sendRaw("B", "bye").catch(() => {}); const p = peer; peer = null; emit({ t: "disconnected", id: p || "" }); },
      stop() { if (peer) sendRaw("B", "bye").catch(() => {}); run = false; gen++; peer = null; clearInterval(tokTimer); try { ctl && ctl.abort(); } catch (e) {} emit({ t: "stopped" }); },
    };
  }
  const api = { create, deriveKeys, seal, open };
  if (typeof module !== "undefined") module.exports = api; else root.SirrnaOnline = api;
})(typeof window !== "undefined" ? window : globalThis);
