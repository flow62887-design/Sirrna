// local fake of Firebase auth + Realtime DB (GET/PUT/POST/DELETE + SSE on a path). Test only, enforces NO rules.
const http = require("http");
let tree = {}, n = 0; const subs = [];
const segs = (p) => p.replace(/\.json$/, "").split("/").filter(Boolean);
const get = (p) => segs(p).reduce((o, k) => (o == null ? null : o[k] ?? null), tree);
function set(p, v) { const s = segs(p); if (!s.length) { tree = v || {}; return; } let o = tree; for (const k of s.slice(0, -1)) o = o[k] = (o[k] && typeof o[k] === "object") ? o[k] : {};
  if (v === null) { delete o[s.at(-1)]; } else o[s.at(-1)] = v; prune(tree); }
function prune(o) { for (const k of Object.keys(o)) if (o[k] && typeof o[k] === "object") { prune(o[k]); if (!Object.keys(o[k]).length) delete o[k]; } }
function notify(p) { for (const s of subs) { const sp = s.path; if (p.startsWith(sp) || sp.startsWith(p)) { const d = get(sp); s.res.write(`event: put\ndata: ${JSON.stringify({ path: "/", data: d })}\n\n`); } } }
http.createServer((req, res) => {
  res.setHeader("Access-Control-Allow-Origin","*"); res.setHeader("Access-Control-Allow-Headers","*"); res.setHeader("Access-Control-Allow-Methods","*"); if (req.method==="OPTIONS"){res.statusCode=204;return res.end();}
  const u = new URL(req.url, "http://x");
  if (u.pathname.endsWith("accounts:signUp")) { const id = "uid" + ++n; res.end(JSON.stringify({ idToken: "t:" + id, refreshToken: "r:" + id, localId: id })); return; }
  if (u.pathname.startsWith("/v1/token")) { let b = ""; req.on("data", (d) => b += d); req.on("end", () => { const r = /refresh_token=([^&]+)/.exec(b)[1]; const id = r.slice(2); res.end(JSON.stringify({ id_token: "t:" + id, refresh_token: r, user_id: id })); }); return; }
  if (!u.searchParams.get("auth")) { res.statusCode = 401; res.end("{}"); return; }
  const p = u.pathname.replace(/\.json$/, "");
  if (req.method === "GET" && (req.headers.accept || "").includes("event-stream")) {
    res.writeHead(200, { "content-type": "text/event-stream" }); const s = { path: p, res }; subs.push(s);
    res.write(`event: put\ndata: ${JSON.stringify({ path: "/", data: get(p) })}\n\n`); req.on("close", () => subs.splice(subs.indexOf(s), 1)); return; }
  let b = ""; req.on("data", (d) => b += d); req.on("end", () => {
    if (req.method === "GET") return res.end(JSON.stringify(get(p)));
    if (req.method === "PUT") { set(p, JSON.parse(b)); notify(p); return res.end(b); }
    if (req.method === "DELETE") { set(p, null); notify(p); return res.end("null"); }
    if (req.method === "POST") { const k = "-k" + String(++n).padStart(6, "0"); set(p + "/" + k, JSON.parse(b)); notify(p); return res.end(JSON.stringify({ name: k })); }
    res.statusCode = 405; res.end();
  });
}).listen(8098, () => console.log("fake up"));
