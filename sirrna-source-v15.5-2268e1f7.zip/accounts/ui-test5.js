const p=require('puppeteer-core');const sl=ms=>new Promise(r=>setTimeout(r,ms));
const T=(n,v)=>{console.log(v?'PASS':'FAIL',n);if(!v)process.exitCode=1};
const APP='file:///tmp/s/sirrna-source/android-nearby-test/app/src/main/assets/app.html';
(async()=>{const b=await p.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox','--allow-file-access-from-files','--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream','--disable-features=WebRtcHideLocalIpsWithMdns'],headless:'new'});
async function mk(name){const ctx=await b.createBrowserContext();const pg=await ctx.newPage();await pg.setViewport({width:390,height:844});pg.errs=[];pg.on('pageerror',e=>pg.errs.push(e.message));
 await pg.setRequestInterception(true);pg.on('request',r=>{let u=r.url();if(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/.test(u)||u.startsWith('https://fake-db'))return r.continue({url:u.replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/,'http://localhost:8098').replace('https://fake-db','http://localhost:8098')});r.continue()});
 await pg.goto(APP);await pg.type('#fbUrl','https://fake-db');await pg.type('#fbKey','k');await pg.type('#nm',name);await pg.click('#go');await pg.waitForFunction(()=>!document.querySelector('#home').classList.contains('hide'),{timeout:8000});return pg}
const ev=(pg,f,...a)=>pg.evaluate(f,...a);
const A=await mk('Alice'),B=await mk('Bob'),C=await mk('Carol');
const id=async p=>p.$eval('#myId',e=>e.textContent);
const befriend=async(x,y)=>{await x.type('#addId',await id(y));await x.click('#add');await sl(900);await y.click('[data-a]');await sl(900);await x.evaluate(()=>{document.querySelector('#addId').value=''})};
await befriend(A,B);await befriend(A,C);
const open=(p,n)=>p.evaluate(n=>{if(view!=='home')document.querySelector('#back').click();[...document.querySelectorAll('#fl .row')].find(r=>r.textContent.includes(n)).click()},n);
await open(A,'Bob');await sl(300);
const clk=(p,s)=>p.evaluate(s=>document.querySelector(s).click(),s);
const sendTxt=async(p,t)=>{await p.evaluate(t=>{const m=document.querySelector('#msg');m.value=t;m.dispatchEvent(new Event('input'))},t);await clk(p,'#send');await sl(900)};
// formatting
await sendTxt(A,'hello *bold* _it_ `code` <b>x</b>');await open(B,'Alice');await sl(500);
console.log(await ev(B,()=>document.querySelector('#chat').innerHTML.slice(0,600)));T('format: b/i/code nodes, no html injection',await ev(B,()=>{const c=document.querySelector('#chat .fmt');return c.querySelectorAll('b').length===1&&c.querySelector('i')&&c.querySelector('code')&&c.textContent.includes('<b>x</b>')}));
// star + pin
await A.evaluate(()=>{document.querySelector('#chat .b .mm').click()});await sl(200);await clk(A,'#shStar');await sl(300);
T('star shows',await ev(A,()=>!!document.querySelector('#chat .stm')));
await A.evaluate(()=>{document.querySelector('#chat .b .mm').click()});await sl(200);await clk(A,'#shPin');await sl(1200);
console.log('ERRS',A.errs);console.log('typ',await ev(B,()=>typeof window.__v14ev+' '+view+' '+cur.uid));await ev(B,()=>{window.__v14ev({t:'pin',uid:cur.uid})});await sl(300);console.log('after manual',await ev(B,()=>document.querySelector('#pinb').className));console.log('Bpin',await ev(B,()=>JSON.stringify(acct.pinned(cur.uid))+JSON.stringify(Object.keys(acct.messages(cur.uid)).length)),await ev(A,()=>document.querySelector('#pinb').className+'|'+(acct.pinned(cur.uid)||{}).t),await ev(B,()=>document.querySelector('#pinb').className+'|'+view));T('pin bar on both sides',await ev(A,()=>!document.querySelector('#pinb').classList.contains('hide'))&&await ev(B,()=>!document.querySelector('#pinb').classList.contains('hide')));
// draft
await A.evaluate(()=>{const m=document.querySelector('#msg');m.value='مسودة';m.dispatchEvent(new Event('input'));document.querySelector('#back').click()});await sl(300);
T('draft shown in list',await ev(A,()=>!!document.querySelector('#fl .ic-pencil')));
await open(A,'Bob');await sl(200);T('draft restored',await ev(A,()=>document.querySelector('#msg').value==='مسودة'));await A.evaluate(()=>{const m=document.querySelector('#msg');m.value='';m.dispatchEvent(new Event('input'))});
// poll
await clk(A,'#plus');await sl(300);await clk(A,'#modB [data-x=poll]');await sl(200);await A.type('#pq','بيتزا؟');const ins=await A.$$('#pos input');await ins[0].type('آه');await ins[1].type('لا');await clk(A,'#pgo');await sl(1200);
await open(B,'Alice');await sl(300);await B.evaluate(()=>document.querySelector('.po').click());await sl(1200);console.log('toast',await ev(B,()=>document.querySelector('#toast').textContent),await ev(B,()=>JSON.stringify(acct.tally(acct.messages(cur.uid).find(m=>m.k==='poll').i))));
console.log(await ev(A,()=>document.querySelector('#chat .poll')&&document.querySelector('#chat .poll').outerHTML.slice(0,500)));T('poll vote counted at sender',await ev(A,()=>[...document.querySelectorAll('#chat .po em')].map(e=>e.textContent).join(',').startsWith('آه,1')||document.querySelector('#chat .poll small').textContent.startsWith('1')));
// view once
await clk(A,'#plus');await sl(300);await clk(A,'#modB [data-x=vo]');await sl(200);
await A.evaluate(async()=>{const r=await acct.sendMedia(cur.uid,'img','image/jpeg','/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/yQALCAABAAEBAREA/8wABgAQEAX/2gAIAQEAAD8A0s8g/9k=','',true);renderChat()});await sl(1200);
await open(B,'Alice');await sl(500);
T('receiver sees open-once button',await ev(B,()=>!!document.querySelector('[data-vo]')));
await B.evaluate(()=>document.querySelector('[data-vo]').click());await sl(500);T('overlay shows',await ev(B,()=>!!document.querySelector('#vov img')));await B.screenshot({path:'/tmp/qrl/v14vo.png'});await clk(B,'#vov button');await sl(1500);
T('after close: gone for B, "opened" for A',await ev(B,()=>!document.querySelector('[data-vo]')&&document.querySelector('#chat').textContent.includes('اتفتحت'))&&await ev(A,()=>document.querySelector('#chat').textContent.includes('اتفتحت')));
// verify
await clk(A,'#more');await sl(300);console.log(await ev(A,()=>document.querySelector('#modB').innerHTML.slice(-300)+view));await clk(A,'#modB [data-x=ver]');await sl(500);T('verify modal has QR',await ev(A,()=>!!document.querySelector('#modB img')));await clk(A,'#vok');await sl(600);
T('verified badge',await ev(A,()=>!!document.querySelector('#safe .ic-check')));
// archive + lock
await A.evaluate(()=>{SET.cl={s:'x',h:'x'}});
await clk(A,'#more');await sl(300);await clk(A,'#modB [data-x=arc]');await sl(400);
T('archived hidden from list',await ev(A,()=>!document.querySelector('#fl').textContent.includes('Bob')));
await clk(A,'#bArch');await sl(300);T('archive list shows chat',await ev(A,()=>document.querySelector('#modB').textContent.includes('Bob')));
// backup
await A.evaluate(()=>document.querySelector('#mod').classList.add('hide'));
const bk=await A.evaluate(async()=>{const t=await acct.exportBackup('password123');return t.length>100&&!t.includes('hello')});T('backup ciphertext',bk);
// star list
await clk(A,'#bStar');await sl(300);T('starred list',await ev(A,()=>document.querySelector('#modB').textContent.includes('Bob')));
await A.screenshot({path:'/tmp/qrl/v14all.png'});
T('no page errors',!A.errs.length&&!B.errs.length&&(console.log(A.errs,B.errs),true));
await b.close()})();
