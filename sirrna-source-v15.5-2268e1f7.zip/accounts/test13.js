const A = require("./accounts.js"); const assert = require("assert");
const pushed = []; const rw = (url, o) => url.startsWith("https://fake-push") ? (pushed.push({ auth: o.headers.authorization, body: JSON.parse(o.body) }), Promise.resolve(new Response("{}"))) : fetch(url.replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/, "http://localhost:8098").replace("https://fake-db", "http://localhost:8098"), o);
const wait = (f, ms = 8000) => new Promise((ok, no) => { const s = Date.now(); (function p() { if (f()) return ok(); if (Date.now() - s > ms) return no(new Error("timeout " + f)); setTimeout(p, 40); })(); });
function mk() { const ev = []; let data = null; const med = {}; const store = { get: () => data, set: (d) => { data = JSON.parse(JSON.stringify(d)); }, dump: () => data, putMedia: async (k, v) => { med[k] = v; }, getMedia: async (k) => med[k], delMedia: async (k) => { delete med[k]; } };
  const a = A.create((e) => ev.push(e), { databaseURL: "https://fake-db", apiKey: "k", pushUrl: "https://fake-push/notify" }, store, rw); return { a, ev, store }; }
const ok = (m) => console.log("PASS", m);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  const a = mk(), b = mk(); await a.a.start("Alice SECRETNAME"); await b.a.start("Bob");
  await a.a.addFriend(b.a.id); await wait(() => b.ev.some((e) => e.t === "request")); await sleep(300);
  assert(pushed.length === 1 && pushed[0].body.k === "msg" && pushed[0].body.to === a.a.friends()[0].uid); ok("friend request triggers a 'msg' push to the recipient uid");
  await b.a.accept(b.ev.find((e) => e.t === "request").uid); await wait(() => a.ev.some((e) => e.t === "friend")); pushed.length = 0;
  const bu = a.a.friends()[0].uid; await a.a.send(bu, "very secret text"); await sleep(300);
  assert(pushed.length === 1 && Object.keys(pushed[0].body).sort().join() === "k,to" && !JSON.stringify(pushed).includes("secret") && !JSON.stringify(pushed).includes("SECRETNAME") && !JSON.stringify(pushed).includes(a.a.id)); ok("message push body has only {to,k}: no text, name or ID");
  assert(/^Bearer .+/.test(pushed[0].auth)); ok("push request carries the sender's ID token");
  pushed.length = 0; await a.a.react(bu, "x1", "👍"); await a.a.setTtl(bu, 0); await b.a.markRead(b.a.friends()[0].uid); await a.a.typing(bu); await sleep(300); assert(pushed.length === 0); ok("reactions, timer, read receipts, typing: no push");
  await a.a.sendSig(bu, { c: "c1", t: "ice", ic: {} }); await sleep(200); assert(pushed.length === 0); await a.a.sendSig(bu, { c: "c1", t: "offer", sdp: "v=0" }); await sleep(300); assert(pushed.length === 1 && pushed[0].body.k === "call"); ok("only a call OFFER pushes 'call' (ICE/answer/end do not)");
  await b.a.setPushToken("TOKEN123"); const d = await (await rw("https://fake-db/push.json?auth=t")).json(); assert(JSON.stringify(d).includes("TOKEN123")); ok("device token stored under /push/<uid>");
  a.a.stop(); b.a.stop(); process.exit(0);
})().catch((e) => { console.error("FAIL", e); process.exit(1); });
