const p=require('puppeteer-core');const sl=ms=>new Promise(r=>setTimeout(r,ms));
const T=(n,v)=>{console.log(v?'PASS':'FAIL',n);if(!v)process.exitCode=1};
const APP='file:///tmp/s/sirrna-source/android-nearby-test/app/src/main/assets/app.html';
(async()=>{const b=await p.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox','--allow-file-access-from-files','--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream','--disable-features=WebRtcHideLocalIpsWithMdns'],headless:'new'});
async function mk(name){const ctx=await b.createBrowserContext();const pg=await ctx.newPage();await pg.setViewport({width:390,height:844});pg.errs=[];pg.on('pageerror',e=>pg.errs.push(e.message));
 await pg.setRequestInterception(true);pg.on('request',r=>{let u=r.url();if(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/.test(u)||u.startsWith('https://fake-db'))return r.continue({url:u.replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/,'http://localhost:8098').replace('https://fake-db','http://localhost:8098')});r.continue()});
 await pg.goto(APP);await pg.type('#fbUrl','https://fake-db');await pg.type('#fbKey','k');await pg.type('#nm',name);await pg.click('#go');await pg.waitForFunction(()=>!document.querySelector('#home').classList.contains('hide'),{timeout:8000});return pg}
const ev=(pg,f,...a)=>pg.evaluate(f,...a);
const A=await mk('Alice'),B=await mk('Bob'),C=await mk('Carol');
const id=async p=>p.$eval('#myId',e=>e.textContent);
const befriend=async(x,y)=>{await x.type('#addId',await id(y));await x.click('#add');await sl(900);await y.click('[data-a]');await sl(900);await x.evaluate(()=>{document.querySelector('#addId').value=''})};
await befriend(A,B);await befriend(A,C);
const open=(p,n)=>p.evaluate(n=>{if(view!=='home')document.querySelector('#back').click();[...document.querySelectorAll('#fl .row')].find(r=>r.textContent.includes(n)).click()},n);
T('glass default on, blur on',await ev(A,()=>document.body.classList.contains('glass')&&document.body.classList.contains('blur')));
T('panel has backdrop-filter',await ev(A,()=>/blur/.test(getComputedStyle(document.querySelector('header')).backdropFilter||getComputedStyle(document.querySelector('header')).webkitBackdropFilter||'')));
await A.evaluate(()=>{document.querySelector('#gear').click()});await sl(300);
await A.evaluate(()=>{const c=document.querySelector('#blurOn');c.checked=false;c.dispatchEvent(new Event('change'))});await sl(200);
T('toggle blur off -> no blur class, glass stays',await ev(A,()=>!document.body.classList.contains('blur')&&document.body.classList.contains('glass')&&(getComputedStyle(document.querySelector('header')).backdropFilter||'none')==='none'));
T('fallback panel is solid translucent',await ev(A,()=>getComputedStyle(document.querySelector('header')).backgroundColor!=='rgba(0, 0, 0, 0)'));
await A.evaluate(()=>{const c=document.querySelector('#blurOn');c.checked=true;c.dispatchEvent(new Event('change'))});await sl(200);
T('blur back on',await ev(A,()=>document.body.classList.contains('blur')));
T('About/licenses present with MIT notice',await ev(A,()=>document.body.innerText.includes('MIT')||document.body.textContent.includes('GANSGX')));
await A.evaluate(()=>document.querySelector('#back')&&0);
const left=await A.evaluate(()=>{const rx=/[\u{1F300}-\u{1FAFF}\u2600-\u27BF]/u;const out=new Set();const tw=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;while(n=tw.nextNode()){const p=n.parentElement;if(p.closest('script,style,.stk,.ut,#sheet .em'))continue;const m=n.nodeValue.match(rx);if(m)out.add(m[0])}return [...out]});
console.log('emoji left in visible UI chrome:',left);T('no stray emoji in current screens',left.length===0);
// force no-support path
const C2=await b.createBrowserContext();const pg=await C2.newPage();await pg.evaluateOnNewDocument(()=>{const o=CSS.supports.bind(CSS);CSS.supports=(a,b)=>/backdrop/.test(a)?false:o(a,b)});await pg.goto(APP);await sl(500);
T('old-WebView path: no blur class, panels still glass',await pg.evaluate(()=>!document.body.classList.contains('blur')&&document.body.classList.contains('glass')));
await b.close();})();
