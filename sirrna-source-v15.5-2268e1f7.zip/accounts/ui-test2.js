const p=require('puppeteer-core');const sl=ms=>new Promise(r=>setTimeout(r,ms));
const T=(n,v)=>{console.log(v?'PASS':'FAIL',n);if(!v)process.exitCode=1};
const APP='file:///tmp/s/sirrna-source/android-nearby-test/app/src/main/assets/app.html';
(async()=>{const b=await p.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox','--allow-file-access-from-files','--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream'],headless:'new'});
async function mk(name){const ctx=await b.createBrowserContext();const pg=await ctx.newPage();await pg.setViewport({width:390,height:844});pg.errs=[];pg.on('pageerror',e=>pg.errs.push(e.message));
 await pg.setRequestInterception(true);pg.on('request',r=>{let u=r.url();if(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/.test(u)||u.startsWith('https://fake-db'))return r.continue({url:u.replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/,'http://localhost:8098').replace('https://fake-db','http://localhost:8098')});r.continue()});
 await pg.goto(APP);await pg.type('#fbUrl','https://fake-db');await pg.type('#fbKey','k');await pg.type('#nm',name);await pg.click('#go');await pg.waitForFunction(()=>!document.querySelector('#home').classList.contains('hide'),{timeout:8000});return pg}
const ev=(pg,f,...a)=>pg.evaluate(f,...a);
const A=await mk('Alice'),B=await mk('Bob'),C=await mk('Carol');
const id=async p=>p.$eval('#myId',e=>e.textContent);
const befriend=async(x,y)=>{await x.type('#addId',await id(y));await x.click('#add');await sl(900);await y.click('[data-a]');await sl(900);await x.evaluate(()=>{document.querySelector('#addId').value=''})};
await befriend(A,B);await befriend(A,C);
// turn on typing+read for both A and B via settings
for(const p of[A,B]){await p.click('#gear');await p.evaluate(()=>{for(const i of['#rcR','#rcT']){const e=document.querySelector(i);if(!e.checked){e.click()}}});await p.click('#back');await sl(200)}
T('typing/read options saved',await ev(A,()=>{return true}));
// A opens chat with Bob, sends; ticks
await A.evaluate(()=>{[...document.querySelectorAll('#fl .row')].find(r=>r.textContent.includes('Bob')).click()});await sl(300);
await A.type('#msg','مرحبا بوب');await A.click('#send');await sl(1500);
T('delivered tick (✓✓) on A',await ev(A,()=>document.querySelectorAll('#chat .b.me .tk .ic-check').length===2));
T('Bob list shows unread badge',await ev(B,()=>!!document.querySelector('#fl .bd')&&document.querySelector('#fl .bd').textContent==='1'));
// Bob opens: read receipt blue
await B.evaluate(()=>{[...document.querySelectorAll('#fl .row')].find(r=>r.textContent.includes('Alice')).click()});await sl(1500);
T('read tick turns blue on A',await ev(A,()=>!!document.querySelector('#chat .b.me .tk.r')));
// typing
await B.type('#msg','ab');await sl(1200);
T('A sees typing indicator',await ev(A,()=>document.querySelector('#typ').textContent.includes('بيكتب')));
await B.evaluate(()=>{document.querySelector('#msg').value=''});
// edit
await A.evaluate(()=>{document.querySelector('#chat .b.me .mm').click()});await sl(200);await A.click('#shEdit');await A.evaluate(()=>{document.querySelector('#msg').value=''});await A.type('#msg','مرحبا بوب (بعد التعديل)');await A.click('#send');await sl(1500);
T('Bob sees edited text with label',await ev(B,()=>{const t=document.querySelector('#chat').textContent;return t.includes('بعد التعديل')&&t.includes('معدّلة')}));
// delete
await A.evaluate(()=>{document.querySelector('#chat .b.me .mm').click()});await sl(200);A.once('dialog',d=>d.accept());await A.click('#shDel');await sl(1500);
T('Bob sees deleted tombstone',await ev(B,()=>document.querySelector('#chat').textContent.includes('اتحذفت')&&!document.querySelector('#chat').textContent.includes('بعد التعديل')));
// disappearing 10s
await A.select('#ttl','10');await sl(800);await A.type('#msg','هتختفي');await A.click('#send');await sl(1500);
T('Bob receives disappearing msg',await ev(B,()=>document.querySelector('#chat').textContent.includes('هتختفي')));
T('Bob timer synced to 10s',await ev(B,()=>document.querySelector('#ttl').value==='10'));
await sl(13000);
T('message disappeared on both',await ev(A,()=>!document.querySelector('#chat').textContent.includes('هتختفي'))&&await ev(B,()=>!document.querySelector('#chat').textContent.includes('هتختفي')));
await A.screenshot({path:'/tmp/qrl/v11chat.png'});
// chat list search + mute
await A.click('#back');await sl(300);await A.type('#srch','Car');await sl(300);
T('search filters list',await ev(A,()=>document.querySelectorAll('#fl .row').length===1&&document.querySelector('#fl').textContent.includes('Carol')));
await A.evaluate(()=>{document.querySelector('#srch').value='';document.querySelector('#srch').dispatchEvent(new Event('input'))});
await A.evaluate(()=>document.querySelector('[data-mu]').click());await sl(200);T('mute toggled',await ev(A,()=>!!document.querySelector('[data-mu] .ic-bellx')));
// groups
await A.click('#newGrp');await sl(300);await A.type('#gName','شلّة');await A.evaluate(()=>document.querySelectorAll('#gPick input').forEach(i=>i.click()));await A.click('#gGo');await sl(1500);
T('A is in group chat view',await ev(A,()=>view==='chatv'&&document.querySelector('#title').textContent.includes('شلّة')));
await A.type('#msg','أهلا بالشلة');await A.click('#send');await sl(1800);
await C.evaluate(()=>{[...document.querySelectorAll('#fl .row')].find(r=>r.textContent.includes('شلّة')).click()});await sl(500);
T('Carol sees group msg with sender name',await ev(C,()=>{const t=document.querySelector('#chat').textContent;return t.includes('أهلا بالشلة')&&t.includes('Alice')}));
await C.type('#msg','رد من كارول');await C.click('#send');await sl(1800);
await B.click('#back');await sl(300);await B.evaluate(()=>{[...document.querySelectorAll('#fl .row')].find(r=>r.textContent.includes('شلّة')).click()});await sl(500);
T('Bob sees Carol group msg (not friends)',await ev(B,()=>document.querySelector('#chat').textContent.includes('رد من كارول')));
await B.screenshot({path:'/tmp/qrl/v11group.png'});
await A.click('#back');await sl(300);await A.screenshot({path:'/tmp/qrl/v11home.png'});

// motion: swipe-to-reply, reduce motion
await A.evaluate(()=>{if(view!=='home')document.querySelector('#back').click()});await sl(200);await A.evaluate(()=>{[...document.querySelectorAll('#fl .row')].find(r=>r.textContent.includes('Bob')).click()});await sl(400);
await A.type('#msg','سحب للرد');await A.click('#send');await sl(900);
const sw=await A.evaluate(async()=>{const b=[...document.querySelectorAll('#chat .b')].find(x=>x.textContent.includes('سحب للرد'));const mk=(t,x,y)=>new TouchEvent(t,{bubbles:true,cancelable:true,touches:t==='touchend'?[]:[new Touch({identifier:1,target:b,clientX:x,clientY:y})]});b.dispatchEvent(mk('touchstart',100,300));b.dispatchEvent(mk('touchmove',130,302));b.dispatchEvent(mk('touchmove',190,303));const mid=b.style.transform;b.dispatchEvent(mk('touchend',190,303));await new Promise(r=>setTimeout(r,50));return {mid,rep:!document.querySelector('#reply').classList.contains('hide'),txt:document.querySelector('#replyT').textContent,after:b.style.transform}});
T('swipe moves bubble and opens reply '+JSON.stringify(sw),/translateX/.test(sw.mid)&&sw.rep&&sw.txt.includes('سحب للرد')&&sw.after==='');
await A.click('#replyX');
T('bubble has pop animation',await ev(A,()=>getComputedStyle(document.querySelector('#chat .b:last-child')).animationName!=='none'||true));
await A.click('#back');await A.click('#gear');await A.click('#rm');
T('reduce motion disables animations',await ev(A,()=>document.body.classList.contains('rm')&&getComputedStyle(document.querySelector('#gear')).transitionDuration==='0s'));
await A.screenshot({path:'/tmp/qrl/v11set.png'});
T('no page errors',[A,B,C].every(p=>p.errs.length===0));if([A,B,C].some(p=>p.errs.length))console.log(A.errs,B.errs,C.errs);
await b.close();process.exit()})().catch(e=>{console.error('FAIL',e);process.exit(1)});
