const p=require('puppeteer-core');const sl=ms=>new Promise(r=>setTimeout(r,ms));
const T=(n,v)=>{console.log(v?'PASS':'FAIL',n);if(!v)process.exitCode=1};
const APP='file:///tmp/s/sirrna-source/android-nearby-test/app/src/main/assets/app.html';
(async()=>{const b=await p.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox','--allow-file-access-from-files','--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream','--disable-features=WebRtcHideLocalIpsWithMdns'],headless:'new'});
async function mk(name){const ctx=await b.createBrowserContext();const pg=await ctx.newPage();await pg.setViewport({width:390,height:844});pg.errs=[];pg.on('pageerror',e=>pg.errs.push(e.message));
 await pg.setRequestInterception(true);pg.on('request',r=>{let u=r.url();if(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/.test(u)||u.startsWith('https://fake-db'))return r.continue({url:u.replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/,'http://localhost:8098').replace('https://fake-db','http://localhost:8098')});r.continue()});
 await pg.goto(APP);await pg.type('#fbUrl','https://fake-db');await pg.type('#fbKey','k');await pg.type('#nm',name);await pg.click('#go');await pg.waitForFunction(()=>!document.querySelector('#home').classList.contains('hide'),{timeout:8000});return pg}
const ev=(pg,f,...a)=>pg.evaluate(f,...a);
const A=await mk('Alice'),B=await mk('Bob'),C=await mk('Carol');
const id=async p=>p.$eval('#myId',e=>e.textContent);
const befriend=async(x,y)=>{await x.type('#addId',await id(y));await x.click('#add');await sl(900);await y.click('[data-a]');await sl(900);await x.evaluate(()=>{document.querySelector('#addId').value=''})};
await befriend(A,B);await befriend(A,C);
const open=(p,n)=>p.evaluate(n=>{if(view!=='home')document.querySelector('#back').click();[...document.querySelectorAll('#fl .row')].find(r=>r.textContent.includes(n)).click()},n);
await open(A,'Bob');await sl(300);
// sticker
await A.click('#plus');await sl(300);await A.evaluate(()=>document.querySelector('#modB [data-a=stk]').click());await sl(300);await A.evaluate(()=>document.querySelector('#modB [data-s=party]').click());await sl(1200);
await open(B,'Alice');await sl(500);
T('Bob sees sticker svg',await ev(B,()=>!!document.querySelector('#chat .stk svg')));
// location
const ctx=A.browserContext();await ctx.overridePermissions('file://',['geolocation']).catch(()=>{});await A.setGeolocation({latitude:31.2001,longitude:29.9187});
await A.click('#plus');await sl(300);A.once('dialog',d=>d.accept());await A.evaluate(()=>document.querySelector('#modB [data-a=loc]').click());await sl(2500);
T('Bob sees location card',await ev(B,()=>{const a=document.querySelector('#chat .loc a');return a&&a.href.startsWith('geo:31.2001,29.9187')}));
// contact card: A shares Carol's card to Bob
await A.click('#plus');await sl(300);await A.evaluate(()=>document.querySelector('#modB [data-a=ct]').click());await sl(300);await A.evaluate(()=>document.querySelector('#modB [data-ct]').click());await sl(1200);
T('Bob sees contact card with add button',await ev(B,()=>!!document.querySelector('#chat .ctc button[data-addid]')));
await B.click('#chat .ctc button[data-addid]');await sl(1200);
T('Carol got friend request from Bob via card',await ev(C,()=>[...document.querySelectorAll('#reqs .row')].some(r=>r.textContent.includes('Bob'))));
// forward
await A.type('#msg','نص للتحويل');await A.click('#send');await sl(900);
await A.evaluate(()=>{const b=[...document.querySelectorAll('#chat .b')].find(x=>x.textContent.includes('نص للتحويل'));b.querySelector('.mm').click()});await sl(200);await A.click('#shFwd');await sl(300);
await A.evaluate(()=>[...document.querySelectorAll('#modB [data-pk]')].find(r=>r.textContent.includes('Carol')).click());await sl(1200);
await open(C,'Alice');await sl(500);
T('Carol received forwarded text',await ev(C,()=>{const t=document.querySelector('#chat').textContent;return t.includes('نص للتحويل')&&t.includes('محوّلة')}));
// group info: A creates group with B, adds Carol, removes Bob
await A.evaluate(()=>{if(view!=='home')document.querySelector('#back').click()});await A.click('#newGrp');await sl(200);await A.type('#gName','الشلة');await A.evaluate(()=>{[...document.querySelectorAll('#gPick label')].find(l=>l.textContent.includes('Bob')).querySelector('input').click()});await A.click('#gGo');await sl(1500);
await A.click('#title');await sl(300);await A.evaluate(()=>document.querySelector('#modB [data-add]').click());await sl(1500);
T('Carol sees group after admin added her',await ev(C,()=>{if(view!=='home')document.querySelector('#back').click();return document.querySelector('#fl').textContent.includes('الشلة')}));
await A.screenshot({path:'/tmp/qrl/v12info.png'});
await A.evaluate(()=>document.querySelector('#modB [data-rm]').click());await sl(1500);
T('removed member lost the group',await ev(B,()=>{if(view!=='home')document.querySelector('#back').click();return !document.querySelector('#fl').textContent.includes('الشلة')}));
await A.evaluate(()=>document.querySelector('#mod').click());
// block
await open(A,'Bob');await sl(300);await A.click('#more');await sl(300);A.once('dialog',d=>d.accept());await A.evaluate(()=>document.querySelector('#modB [data-a=blk]').click());await sl(300);
await open(B,'Alice');await B.type('#msg','محظور؟');await B.click('#send');await sl(1200);
T('blocked: Alice did not receive',await ev(A,()=>!document.querySelector('#chat').textContent.includes('محظور؟')));
await A.click('#gear');await sl(300);T('blocked list shows Bob',await ev(A,()=>document.querySelector('#blk').textContent.includes('Bob')));await A.click('#blk [data-ub]');await sl(200);await A.click('#back');
// status
await A.evaluate(()=>{if(view!=='home')document.querySelector('#back').click()});await A.click('#addSt');await sl(300);await A.type('#stT','حالة تجريبية');await A.click('#stGo');await sl(1500);
await C.evaluate(()=>{if(view!=='home')document.querySelector('#back').click()});await sl(300);
T('Carol sees Alice status ring',await ev(C,()=>document.querySelector('#stc').textContent.includes('Alice')));
await C.evaluate(()=>document.querySelector('#stc [data-st]').click());await sl(500);T('status viewer shows text',await ev(C,()=>document.querySelector('#stv').textContent.includes('حالة تجريبية')));await C.screenshot({path:'/tmp/qrl/v12status.png'});await C.evaluate(()=>document.querySelector('#stv').click());
// message search
await C.type('#srch','للتحويل');await sl(300);T('home message search finds text',await ev(C,()=>document.querySelector('#msr').textContent.includes('للتحويل')));
// voice call A -> C
await A.evaluate(()=>{if(view!=='home')document.querySelector('#back').click()});await open(A,'Carol');await sl(300);await A.click('#call');await sl(2500);
T('Carol sees incoming call',await ev(C,()=>!document.querySelector('#callv').classList.contains('hide')&&document.querySelector('#cst').textContent.includes('واردة')));
await C.screenshot({path:'/tmp/qrl/v12call.png'});await C.click('#cacc');await sl(5000);
const cs=async p=>p.evaluate(()=>document.querySelector('#cst').textContent);
const sa=await cs(A),sc=await cs(C);T('both sides connected, timer running '+sa+' '+sc,/^\d\d:\d\d$/.test(sa)&&/^\d\d:\d\d$/.test(sc));
await A.click('#cend');await sl(1500);T('call ended on both',await ev(C,()=>document.querySelector('#callv').classList.contains('hide'))&&await ev(A,()=>document.querySelector('#callv').classList.contains('hide')));
// decline path
await A.click('#call');await sl(2000);await C.click('#cend');await sl(1500);T('decline ends caller side',await ev(A,()=>document.querySelector('#callv').classList.contains('hide')));
T('no page errors',[A,B,C].every(p=>p.errs.length===0));if([A,B,C].some(p=>p.errs.length))console.log(A.errs,B.errs,C.errs);
await b.close();process.exit()})().catch(e=>{console.error('FAIL',e);process.exit(1)});
