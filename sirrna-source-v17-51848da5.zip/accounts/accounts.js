/* Sirrna accounts: Firebase Realtime Database (REST + streaming), anonymous auth, no SDK.
   - account = anonymous Firebase uid + a P-256 key pair made on the phone; public ID = 10 chars from the public key hash
   - friends: request -> accept; messages are end-to-end encrypted (ECDH P-256 -> HKDF -> AES-256-GCM), gzip first
   - offline delivery: messages wait in the receiver's inbox on the server until the receiver opens the app
   Server can see: who writes to whom, when, sizes, public keys, display names of users/{uid}. Not message text, friend-request names, or the private key. */
(function (root) {
  const enc = new TextEncoder(), dec = new TextDecoder();
  const C = () => (root.crypto || globalThis.crypto), S = () => C().subtle;
  const b64 = (u) => { let s = ""; u = new Uint8Array(u); for (let i = 0; i < u.length; i += 8192) s += String.fromCharCode(...u.subarray(i, i + 8192)); return btoa(s); };
  const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
  const A32 = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const toId = (u) => { let o = "", bits = 0, v = 0; for (const x of u) { v = (v << 8) | x; bits += 8; while (bits >= 5) { o += A32[(v >>> (bits - 5)) & 31]; bits -= 5; } } return o; };

  async function pubId(pubJwk) { // ID from the public key itself, so a stranger cannot claim someone else's ID without detection
    const h = new Uint8Array(await S().digest("SHA-256", enc.encode(pubJwk.x + "." + pubJwk.y)));
    return toId(h.subarray(0, 7)).slice(0, 10);
  }
  async function gz(u8, mode) {
    if (typeof CompressionStream === "undefined") return null;
    const s = new Blob([u8]).stream().pipeThrough(mode === "c" ? new CompressionStream("gzip") : new DecompressionStream("gzip"));
    return new Uint8Array(await new Response(s).arrayBuffer());
  }
  async function aesKey(priv, theirPubJwk) {
    const pub = await S().importKey("jwk", theirPubJwk, { name: "ECDH", namedCurve: "P-256" }, false, []);
    const bits = await S().deriveBits({ name: "ECDH", public: pub }, priv, 256);
    const hk = await S().importKey("raw", bits, "HKDF", false, ["deriveKey"]);
    return S().deriveKey({ name: "HKDF", hash: "SHA-256", salt: enc.encode("sirrna-e2e-v1"), info: enc.encode("msg") }, hk, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
  }
  async function seal(key, text) {
    let raw = enc.encode(text), flag = "p";
    if (raw.length > 64) { const z = await gz(raw, "c"); if (z && z.length < raw.length) { raw = z; flag = "z"; } }
    const iv = C().getRandomValues(new Uint8Array(12));
    const ct = new Uint8Array(await S().encrypt({ name: "AES-GCM", iv }, key, raw));
    return flag + b64(iv) + "." + b64(ct);
  }
  async function open(key, s) {
    const flag = s[0], [iv, ct] = s.slice(1).split(".");
    let raw = new Uint8Array(await S().decrypt({ name: "AES-GCM", iv: unb64(iv) }, key, unb64(ct)));
    if (flag === "z") raw = await gz(raw, "d");
    return dec.decode(raw);
  }
  async function passKey(pass, salt) { const k = await S().importKey("raw", enc.encode(pass), "PBKDF2", false, ["deriveKey"]);
    return S().deriveKey({ name: "PBKDF2", salt, iterations: 250000, hash: "SHA-256" }, k, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]); }
  async function safetyNumber(a, b) { // both friends see the same digits; compare out loud to rule out a swapped key
    const [x, y] = [a.x + a.y, b.x + b.y].sort();
    const h = new Uint8Array(await S().digest("SHA-256", enc.encode(x + "|" + y)));
    let o = ""; for (let i = 0; i < 6; i++) o += String(((h[i * 2] << 8) | h[i * 2 + 1]) % 100000).padStart(5, "0") + (i < 5 ? " " : ""); return o;
  }
  const MAX_B64 = 220000; // about 165 KB of raw media after base64
  const inviteLink = (id, name) => `sirrna://add?id=${id}` + (name ? `&n=${encodeURIComponent(name)}` : "");
  const parseJoin = (s) => { const m = /(?:sirrna:\/\/join\?|https:\/\/[^\s?#]+\/i\.html\?)g=([a-f0-9]{12})&a=([A-Z2-9]{10})(?:&n=([^&\s]*))?/.exec(s || ""); return m ? { gid: m[1], admin: m[2], name: m[3] ? decodeURIComponent(m[3]) : "" } : null; };
  const parseInvite = (s) => { const m = /(?:sirrna:\/\/add\?|#\/add\?|https:\/\/[^\s?#]+\/i\.html\?)id=([A-Z2-9]{10})(?:&n=([^&\s]*))?/.exec(s || ""); return m ? { id: m[1], name: m[2] ? decodeURIComponent(m[2]) : "" } : null; };

  function create(emit, cfg, store, fetchFn) {
    const F = fetchFn || fetch.bind(root);
    let token = "", refresh = "", uid = "", ctl = null, run = false, gen = 0, tokTimer = null;
    let st = store.get() || {}; // {priv, pub, id, name, friends:{uid:{id,name,pub,state}}, msgs:{uid:[...]}, refresh}
    st.outbox = st.outbox || []; st.friends = st.friends || {}; st.msgs = st.msgs || {}; st.reacts = st.reacts || {}; st.unread = st.unread || {}; st.groups = st.groups || {}; st.block = st.block || {}; st.star = st.star || {}; st.prof = st.prof || { a: "", ph: "" }; st.pj = st.pj || {}; st.jreq = st.jreq || []; st.defTtl = st.defTtl || 0; st.pin = st.pin || {}; st.votes = st.votes || {}; st.status = st.status || {}; st.myStatus = st.myStatus || []; st.ttl = st.ttl || {}; st.opt = Object.assign({ delivered: true, read: false, typing: false }, st.opt || {});
    const save = () => store.set(st);
    const base = () => cfg.databaseURL.replace(/\/$/, "");
    const url = (p, q) => `${base()}${p}.json?auth=${encodeURIComponent(token)}${q || ""}`;
    const db = async (m, p, body) => {
      const r = await F(url(p), { method: m, body: body === undefined ? undefined : JSON.stringify(body) });
      if (!r.ok) throw new Error(`${m} ${p} ${r.status}`);
      return r.json();
    };
    async function auth() {
      st.refresh = st.refresh || refresh;
      if (st.refresh) {
        const r = await F(`https://securetoken.googleapis.com/v1/token?key=${cfg.apiKey}`, { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: `grant_type=refresh_token&refresh_token=${st.refresh}` });
        const j = await r.json();
        if (j.id_token) { token = j.id_token; uid = j.user_id; st.refresh = j.refresh_token; st.uid = uid; save(); return; }
        if (st.uid) throw new Error("login expired: " + ((j.error && j.error.message) || r.status)); // never silently create a new identity over an old one
      }
      const r = await F(`https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${cfg.apiKey}`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ returnSecureToken: true }) });
      const j = await r.json();
      if (!j.idToken) throw new Error("anonymous sign-in failed: " + ((j.error && j.error.message) || r.status));
      token = j.idToken; uid = j.localId; st.refresh = j.refreshToken; st.uid = uid; save();
    }
    async function ensureKeys(name) {
      if (!st.priv) {
        const kp = await S().generateKey({ name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]);
        st.priv = await S().exportKey("jwk", kp.privateKey); st.pub = await S().exportKey("jwk", kp.publicKey);
        st.pub = { kty: st.pub.kty, crv: st.pub.crv, x: st.pub.x, y: st.pub.y }; st.id = await pubId(st.pub);
      }
      if (name) st.name = name;
      save();
    }
    const privKey = () => S().importKey("jwk", st.priv, { name: "ECDH", namedCurve: "P-256" }, false, ["deriveBits"]);
    async function keyFor(friendUid) { return aesKey(await privKey(), st.friends[friendUid].pub); }
    async function lookupById(id) { // resolve ID -> uid + verified public key
      const u = await db("GET", `/handles/${id}`);
      if (!u) throw new Error("ID مش موجود");
      const rec = await db("GET", `/users/${u}`);
      if (!rec || !rec.pub) throw new Error("ID مش موجود");
      const pub = JSON.parse(rec.pub);
      if ((await pubId(pub)) !== id) throw new Error("ID مش مطابق للمفتاح (محاولة انتحال)");
      return { uid: u, pub, name: rec.name || "" };
    }
    async function push(toUid, kind, plain, pubOverride) {
      const pub = pubOverride || (st.friends[toUid] && st.friends[toUid].pub);
      const key = await aesKey(await privKey(), pub);
      const env = { f: uid, k: kind, d: await seal(key, plain), ts: Date.now() };
      if (localRoute && localRoute.on()) { // manual route: Nearby / Bluetooth. Same sealed envelope, no server, no push.
        if (kind === "sig") throw new Error("المكالمات مش متاحة على المسار ده");
        const j = JSON.stringify(env); if (j.length > 24000) throw new Error("الرسالة كبيرة على Nearby/Bluetooth (نص بس)");
        await localRoute.send(j); return;
      }
      await db("POST", `/inbox/${toUid}/q`, env);
      if (cfg.pushUrl) { // closed-app wake-up: only "msg" or "call" and the recipient uid go to the push sender. Never any text, name or ID.
        let k = null;
        if (kind === "req" || kind === "acc") k = "msg";
        else { try { const o = JSON.parse(plain); if (kind === "msg" && o.i && !o.rc && !o.rx && !o.ed && !o.dl && !o.dt) k = "msg"; else if (kind === "sig" && o.t === "offer") k = "call"; } catch (e) {} }
        if (k) F(cfg.pushUrl, { method: "POST", headers: { "content-type": "application/json", authorization: "Bearer " + token }, body: JSON.stringify({ to: toUid, k }) }).catch(() => {});
      }
    }
    let bt = null, localRoute = null;
    function scheduleBackup() { clearTimeout(bt); bt = setTimeout(() => backupNow().catch(() => {}), 1500); }
    async function backupKey() { const hk = await S().importKey("raw", enc.encode(st.priv.d), "HKDF", false, ["deriveKey"]);
      return S().deriveKey({ name: "HKDF", hash: "SHA-256", salt: enc.encode("sirrna-backup-v1"), info: enc.encode("friends") }, hk, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]); }
    async function backupNow() { if (!token || !st.priv) return; const list = Object.entries(st.friends).map(([u, f]) => ({ u, id: f.id, n: f.name, p: f.pub, s: f.state }));
      await db("PUT", `/backup/${uid}`, { d: await seal(await backupKey(), JSON.stringify(list)), ts: Date.now() }); }
    async function restoreBackup() { const b = await db("GET", `/backup/${uid}`).catch(() => null); if (!b || !b.d) return 0;
      const list = JSON.parse(await open(await backupKey(), b.d)); let n = 0;
      for (const f of list) if (!st.friends[f.u]) { st.friends[f.u] = { id: f.id, name: f.n, pub: f.p, state: f.s }; n++; } save(); return n; }
    async function wipe(m) { // turn a message into a tombstone and drop its media
      if (m.mid && store.delMedia) await store.delMedia(m.mid).catch(() => {});
      delete st.reacts[m.i]; m.del = 1; m.t = ""; delete m.k; delete m.mid; delete m.m; delete m.re; save();
    }
    function prune() { // disappearing messages: remove expired ones from this device
      const now = Date.now(); let n = 0;
      for (const fu of Object.keys(st.msgs)) { const keep = [];
        for (const m of st.msgs[fu]) { if (m.x && m.ts + m.x * 1000 < now) { if (m.mid && store.delMedia) store.delMedia(m.mid); delete st.reacts[m.i]; n++; } else keep.push(m); }
        st.msgs[fu] = keep; }
      if (n) { save(); emit({ t: "expired", count: n }); } return n;
    }
    let tyAt = {};
    const rid = () => Array.from(C().getRandomValues(new Uint8Array(6)), (x) => x.toString(16).padStart(2, "0")).join("");
    function groupPubOf(u) { for (const g of Object.values(st.groups)) if (g.members[u]) return g.members[u].pub; return null; }
    function target(ck) { // a chat is either a friend uid or "g:<groupId>"
      if (ck.startsWith("g:")) { const gid = ck.slice(2), g = st.groups[gid]; if (!g || !g.members[uid]) throw new Error("مش في المجموعة");
        return { group: true, send: async (obj) => { if ((g.ch || g.wo) && !isAdmin(g, uid) && (obj.i || obj.ed || obj.dl)) throw new Error("الأدمن بس بينشر هنا"); const o = { ...obj, g: gid }; const errs = [];
          for (const [mu, m] of Object.entries(g.members)) if (mu !== uid) { const pub = (st.friends[mu] && st.friends[mu].pub) || m.pub; try { await push(mu, "msg", JSON.stringify(o), pub); } catch (e) { errs.push(e.message); } }
          if (errs.length === Object.keys(g.members).length - 1 && errs.length) throw new Error(errs[0]); } };
      }
      const f = st.friends[ck]; if (!f || f.state !== "friend") throw new Error("مش صديق");
      return { group: false, send: (obj) => push(ck, "msg", JSON.stringify(obj)) };
    }
    async function groupContent(from, o, v) { // messages sent to a group I am in (sender is a verified member)
      const ck = "g:" + o.g, g = st.groups[o.g], mem = g.members[from], list = st.msgs[ck] = st.msgs[ck] || [];
      if (o.rc) { const m = list.find((x) => x.from === "me" && (o.i || []).includes(x.i)); if (m) { const l = o.rc === "r" ? 2 : 1; m.rcv = m.rcv || {}; if ((m.rcv[from] || 0) < l) m.rcv[from] = l;
          const others = Object.keys(g.members).filter((u) => u !== uid); m.st = Math.min(...others.map((u) => m.rcv[u] || 0)); save(); emit({ t: "receipt", uid: ck, level: m.st }); } return; }
      if ((g.ch || g.wo) && !isAdmin(g, from) && (o.i || o.ed || o.dl)) return; // channel: only admins post
      if (ctrlExtra(ck, from, o, true)) return;
      if (o.rx) { const e = String(o.e || "").slice(0, 8), r = st.reacts[o.rx] = st.reacts[o.rx] || {}; if (e) r[from] = e; else delete r[from]; save(); emit({ t: "reaction", uid: ck, name: g.name, target: o.rx, emoji: e }); return; }
      if (o.ed) { const m = list.find((x) => x.i === o.ed && x.from === from && !x.k && !x.del); if (m) { m.t = String(o.t || "").slice(0, 4000); m.ed = 1; save(); emit({ t: "edited", uid: ck, id: m.i }); } return; }
      if (o.dl) { const m = list.find((x) => x.i === o.dl && x.from === from); if (m) { await wipe(m); emit({ t: "deleted", uid: ck, id: m.i }); } return; }
      if (!o.i) return;
      const m = { i: String(o.i), t: String(o.t || ""), ts: v.ts, from }; if (o.re) m.re = String(o.re).slice(0, 24);
      if (o.b) { if ((o.k !== "img" && o.k !== "voice") || typeof o.b !== "string" || o.b.length > MAX_B64 || !/^[a-z]+\/[\w.+-]+$/.test(o.m || "")) return;
        m.k = o.k; m.m = o.m; m.mid = m.i; if (store.putMedia) await store.putMedia(m.mid, { m: o.m, b: o.b }); }
      if (o.k === "loc" || o.k === "ct" || o.k === "stk" || o.k === "poll" || o.k === "ll" || o.mn || o.fw) { if (!kindExtra(o, m)) return; }
      if (o.x) m.x = Math.max(1, Math.min(+o.x || 0, 30 * 86400));
      addMsg(ck, m); st.unread[ck] = (st.unread[ck] || 0) + 1; save();
      if (st.opt.delivered && !g.ch) push(from, "msg", JSON.stringify({ g: o.g, rc: "d", i: [m.i] })).catch(() => {});
      emit({ t: "message", uid: ck, name: g.name + " · " + (mem.name || ""), text: m.t, kind: m.k || "text", id: m.i, ts: v.ts, group: true, mention: !!m.me });
    }
    const isAdmin = (g, u) => g.admin === u || !!(g.ad && g.ad[u]);
    const kindExtra = (o, m) => { // location / contact / sticker / forwarded flag. returns false if invalid
      if (o.fw) m.fw = 1;
      if (o.k === "loc") { const la = +o.la, lo = +o.lo; if (!(Math.abs(la) <= 90 && Math.abs(lo) <= 180) || o.la === undefined) return false; m.k = "loc"; m.la = la; m.lo = lo; }
      else if (o.k === "ct") { if (!/^[A-Z2-9]{10}$/.test(o.cid || "")) return false; m.k = "ct"; m.cid = o.cid; m.cn = String(o.cn || "").slice(0, 40); }
      else if (o.k === "stk") { if (!/^[a-z0-9_-]{1,20}$/.test(o.s || "")) return false; m.k = "stk"; m.s = o.s; }
      else if (o.k === "poll") { const po = Array.isArray(o.po) ? o.po.map((x) => String(x).slice(0, 60)).filter(Boolean) : []; if (po.length < 2 || po.length > 6 || !String(o.t || "").trim()) return false; m.k = "poll"; m.t = String(o.t).slice(0, 200); m.po = po; m.pm = o.pm ? 1 : 0; }
      else if (o.k === "ll") { const la = +o.la, lo = +o.lo, u = Math.min(+o.u || 0, Date.now() + 8 * 3600e3); if (!(Math.abs(la) <= 90 && Math.abs(lo) <= 180) || o.la === undefined || u <= Date.now()) return false; m.k = "ll"; m.la = la; m.lo = lo; m.u = u; m.lt = Date.now(); }
      if (Array.isArray(o.mn)) { m.mn = o.mn.filter((x) => typeof x === "string").slice(0, 10).map((x) => x.slice(0, 40)); if (m.mn.includes(uid)) m.me = 1; }
      return true; };
    const pushProfile = async (u) => { const p = st.prof; if (!p.a && !p.ph) return; await push(u, "msg", JSON.stringify({ pf: { a: p.a, ph: p.ph || "" } })).catch(() => {}); };
    const onFriended = async (u) => { try { await pushProfile(u); if (st.defTtl) await api2.setTtl(u, st.defTtl).catch(() => {}); const f = st.friends[u]; for (const [gid, aid] of Object.entries(st.pj)) if (f && f.id === aid) { await push(u, "msg", JSON.stringify({ jr: gid })).catch(() => {}); delete st.pj[gid]; save(); } } catch (e) {} };
    let api2 = null;
    const ctrlExtra = (ck, from, o, isGroup) => { // poll votes, pin, live-location updates, view-once opened. true = consumed
      const list = st.msgs[ck] || [];
      if (o.pv) { const p = list.find((x) => x.i === o.pv && x.k === "poll"); if (!p) return true; const ix = [...new Set((Array.isArray(o.ix) ? o.ix : []).map(Number).filter((k) => Number.isInteger(k) && k >= 0 && k < p.po.length))]; if (!p.pm && ix.length > 1) ix.length = 1;
        const v = st.votes[o.pv] = st.votes[o.pv] || {}; if (ix.length) v[from] = ix; else delete v[from]; save(); emit({ t: "vote", uid: ck, id: o.pv }); return true; }
      if (o.pn !== undefined) { if (o.pn === null || o.pn === "") delete st.pin[ck]; else { const g = isGroup && st.groups[ck.slice(2)]; if (g && (g.ch || g.wo) && !isAdmin(g, from)) return true; const m = list.find((x) => x.i === o.pn); st.pin[ck] = { i: String(o.pn).slice(0, 24), t: String(o.pt || (m && m.t) || "").slice(0, 80) }; } save(); emit({ t: "pin", uid: ck }); return true; }
      if (o.lu) { const m = list.find((x) => x.i === o.lu && x.k === "ll" && x.from === from); if (m) { if (o.end) m.u = Date.now(); else if (m.u > Date.now()) { const la = +o.la, lo = +o.lo; if (Math.abs(la) <= 90 && Math.abs(lo) <= 180) { m.la = la; m.lo = lo; m.lt = Date.now(); } } save(); emit({ t: "live", uid: ck, id: m.i }); } return true; }
      if (o.vw) { const m = list.find((x) => x.i === o.vw && x.from === "me" && x.vo); if (m) { m.vd = 1; save(); emit({ t: "opened", uid: ck, id: m.i }); } return true; }
      return false; };
    // ---- offline send queue (text messages to a friend). A message that could not reach the server is kept with st=-1 and retried.
    const retryable = (e) => !!e && (e.name === "TypeError" || /Failed to fetch|NetworkError|network|load failed|timeout/i.test(e.message || "") || /^(POST|GET|PUT|DELETE) \S+ (5\d\d|429|401)$/.test(e.message || ""));
    let flushing = false, fq = null, onl = null;
    async function flush() {
      if (flushing || !st.outbox.length || !run) return; flushing = true;
      try {
        try { await auth(); } catch (e) { return; } // still offline
        while (st.outbox.length) {
          const o = st.outbox[0]; const m = (st.msgs[o.fu] || []).find((x) => x.i === o.i);
          if (!m) { st.outbox.shift(); save(); continue; }
          try { await target(o.fu).send(o.p); }
          catch (e) { if (retryable(e)) return; m.st = -2; st.outbox.shift(); save(); emit({ t: "receipt", uid: o.fu, level: -2 }); continue; }
          m.st = 0; st.outbox.shift(); save(); emit({ t: "receipt", uid: o.fu, level: 0 });
        }
      } finally { flushing = false; }
    }
    function addMsg(fu, m) { (st.msgs[fu] = st.msgs[fu] || []).push(m); save(); }
    async function handle(key, v) {
      const done = () => key ? db("DELETE", `/inbox/${uid}/q/${key}`).catch(() => {}) : Promise.resolve();
      let fr = st.friends[v.f];
      let pub = fr && fr.pub;
      const gpub = !pub && v.k === "msg" ? groupPubOf(v.f) : null;
      if (gpub) pub = gpub;
      else if (!pub) { // unknown sender: only friend requests are allowed, key comes from the sender's public record
        if (v.k !== "req") { await done(); return; }
        const rec = await db("GET", `/users/${v.f}`).catch(() => null);
        if (!rec || !rec.pub) { await done(); return; }
        pub = JSON.parse(rec.pub);
      } else {
        const rec = await db("GET", `/users/${v.f}`).catch(() => null);
        if (rec && rec.pub && (JSON.parse(rec.pub).x !== pub.x || JSON.parse(rec.pub).y !== pub.y)) { emit({ t: "keychange", uid: v.f, name: fr.name }); await done(); return; }
      }
      let txt; try { txt = await open(await aesKey(await privKey(), pub), v.d); } catch (e) { await done(); return; }
      let o; try { o = JSON.parse(txt); } catch (e) { await done(); return; }
      if (st.block[v.f]) { /* blocked: drop everything */
      } else if (v.k === "msg" && o.gm && (fr && fr.state === "friend" || (st.groups[o.gm.id] && st.groups[o.gm.id].members[v.f]))) { // group created / updated by an admin
        const gm = o.gm, ex = st.groups[gm && gm.id];
        const members = {}; if (gm && gm.members) for (const [mu, m] of Object.entries(gm.members)) members[mu] = { id: String(m.id || ""), name: String(m.name || "").slice(0, 40), pub: m.pub };
        const okShape = gm && /^[a-f0-9]{12}$/.test(gm.id || "") && gm.members && Object.keys(gm.members).length <= 50;
        if (okShape && ex && !isAdmin(ex, v.f)) { /* not an admin: ignore */ }
        else if (okShape && ex && !members[uid]) { delete st.groups[gm.id]; delete st.msgs["g:" + gm.id]; delete st.unread["g:" + gm.id]; save(); emit({ t: "removed", gid: gm.id, name: ex.name }); }
        else if (okShape && members[uid] && (ex || gm.admin === v.f)) {
          const ad = {}; for (const a of Object.keys(gm.ad || {})) if (members[a]) ad[a] = 1;
          st.groups[gm.id] = { name: String(gm.name || "مجموعة").slice(0, 40), admin: ex ? ex.admin : v.f, ad, ch: ex ? ex.ch : (gm.ch ? 1 : 0), wo: gm.wo ? 1 : 0, ds: String(gm.ds || "").slice(0, 200), ph: (typeof gm.ph === "string" && gm.ph.length <= 30000 && /^[A-Za-z0-9+/=]*$/.test(gm.ph)) ? gm.ph : "", members }; save(); emit({ t: "group", gid: gm.id, name: st.groups[gm.id].name, update: !!ex });
        }
      } else if (v.k === "msg" && o.g && st.groups[o.g] && st.groups[o.g].members[v.f]) {
        await groupContent(v.f, o, v);
      } else if (!fr && v.k === "msg") { /* unknown, not in any group: drop */
      } else if (v.k === "req") {
        const id = await pubId(pub);
        if (fr && fr.state === "out") { st.friends[v.f] = { ...fr, state: "friend" }; save(); scheduleBackup(); await push(v.f, "acc", JSON.stringify({ name: st.name })); emit({ t: "friend", uid: v.f, name: fr.name }); onFriended(v.f); }
        else if (!fr) { st.friends[v.f] = { id, name: String(o.name || "").slice(0, 40), pub, state: "in" }; save(); scheduleBackup(); emit({ t: "request", uid: v.f, id, name: st.friends[v.f].name }); }
      } else if (v.k === "acc" && fr && fr.state === "out") {
        st.friends[v.f] = { ...fr, state: "friend", name: String(o.name || fr.name).slice(0, 40) }; save(); scheduleBackup(); emit({ t: "friend", uid: v.f, name: st.friends[v.f].name }); onFriended(v.f);
      } else if (v.k === "ty" && o.g && st.groups[o.g] && st.groups[o.g].members[v.f]) {
        if (st.opt.typing && Date.now() - v.ts < 10000) emit({ t: "typing", uid: "g:" + o.g, name: st.groups[o.g].members[v.f].name });
      } else if (v.k === "sig" && fr && fr.state === "friend") { // call signalling
        if (Date.now() - v.ts < 90000) emit({ t: "sig", uid: v.f, name: fr.name, o });
      } else if (v.k === "msg" && fr && fr.state === "friend" && o.stt) { // status (24h story)
        const q = o.stt, a = st.status[v.f] = (st.status[v.f] || []).filter((x) => x.ts > Date.now() - 86400000);
        if (q && q.i && !a.find((x) => x.i === q.i)) { const e = { i: String(q.i), t: String(q.t || "").slice(0, 500), bg: /^#[0-9a-f]{6}$/i.test(q.bg || "") ? q.bg : "#2f6fed", ts: v.ts };
          if (q.b && q.b.length <= MAX_B64 && /^[a-z]+\/[\w.+-]+$/.test(q.m || "")) { e.mid = "st" + e.i; if (store.putMedia) await store.putMedia(e.mid, { m: q.m, b: q.b }); }
          a.push(e); save(); emit({ t: "status", uid: v.f, name: fr.name }); }
      } else if (v.k === "ty") {
        if (fr && fr.state === "friend" && st.opt.typing && Date.now() - v.ts < 10000) emit({ t: "typing", uid: v.f, name: fr.name });
      } else if (v.k === "msg" && fr && fr.state === "friend" && o.pf) { // contact profile: about + small photo
        const p = o.pf; fr.about = String(p.a || "").slice(0, 140); fr.ph = (typeof p.ph === "string" && p.ph.length <= 30000 && /^[A-Za-z0-9+/=]*$/.test(p.ph)) ? p.ph : ""; save(); emit({ t: "profile", uid: v.f });
      } else if (v.k === "msg" && fr && fr.state === "friend" && o.jr) { // someone asks to join a group through its invite link: the admin must approve
        const g = st.groups[String(o.jr)]; if (g && isAdmin(g, uid) && !g.members[v.f] && !st.jreq.some((q) => q.gid === o.jr && q.uid === v.f)) { st.jreq.push({ gid: String(o.jr), uid: v.f, name: fr.name, ts: Date.now() }); save(); emit({ t: "joinreq", gid: String(o.jr), uid: v.f, name: fr.name }); }
      } else if (v.k === "msg" && fr && fr.state === "friend" && (o.pv || o.pn !== undefined || o.lu || o.vw)) { ctrlExtra(v.f, v.f, o, false);
      } else if (v.k === "msg" && fr && fr.state === "friend" && o.rc) { // delivery / read receipt for my own messages
        const rank = { d: 1, r: 2 }, lvl = rank[o.rc] || 0; let n = 0;
        for (const m of st.msgs[v.f] || []) if (m.from === "me" && (o.i || []).includes(m.i) && (m.st || 0) < lvl) { m.st = lvl; n++; }
        if (n) { save(); emit({ t: "receipt", uid: v.f, level: lvl }); }
      } else if (v.k === "msg" && fr && fr.state === "friend" && o.ed) { // author edits own message
        const m = (st.msgs[v.f] || []).find((x) => x.i === o.ed && x.from === v.f && !x.k && !x.del);
        if (m) { m.t = String(o.t || "").slice(0, 4000); m.ed = 1; save(); emit({ t: "edited", uid: v.f, id: m.i }); }
      } else if (v.k === "msg" && fr && fr.state === "friend" && o.dl) { // author deletes own message for both sides
        const m = (st.msgs[v.f] || []).find((x) => x.i === o.dl && x.from === v.f);
        if (m) { await wipe(m); emit({ t: "deleted", uid: v.f, id: m.i }); }
      } else if (v.k === "msg" && fr && fr.state === "friend" && o.dt !== undefined) { // disappearing-messages timer for this chat
        const n = Math.max(0, Math.min(+o.dt || 0, 30 * 86400)); st.ttl[v.f] = n; save(); emit({ t: "ttl", uid: v.f, secs: n });
      } else if (v.k === "msg" && fr && fr.state === "friend" && o.rx) { // reaction to an earlier message
        const e = String(o.e || "").slice(0, 8), r = st.reacts[o.rx] = st.reacts[o.rx] || {};
        if (e) r[v.f] = e; else delete r[v.f]; save(); emit({ t: "reaction", uid: v.f, name: fr.name, target: o.rx, emoji: e });
      } else if (v.k === "msg" && fr && fr.state === "friend") {
        const m = { i: o.i, t: String(o.t || ""), ts: v.ts, from: v.f };
        if (o.re) m.re = String(o.re).slice(0, 24);
        if (o.b) { // media: image or voice note, kept outside the message list (store.putMedia)
          if ((o.k !== "img" && o.k !== "voice") || typeof o.b !== "string" || o.b.length > MAX_B64 || !/^[a-z]+\/[\w.+-]+$/.test(o.m || "")) { await done(); return; }
          m.k = o.k; m.m = o.m; m.mid = String(o.i); if (store.putMedia) await store.putMedia(m.mid, { m: o.m, b: o.b });
        }
        if (o.k === "loc" || o.k === "ct" || o.k === "stk" || o.k === "poll" || o.k === "ll" || o.fw) { if (!kindExtra(o, m)) { await done(); return; } }
        if (o.vo && m.k && m.mid) m.vo = 1;
        if (o.x) m.x = Math.max(1, Math.min(+o.x || 0, 30 * 86400));
        addMsg(v.f, m); st.unread[v.f] = (st.unread[v.f] || 0) + 1; save();
        emit({ t: "message", uid: v.f, name: fr.name, text: m.t, kind: m.k || "text", id: o.i, ts: v.ts });
        if (st.opt.delivered) push(v.f, "msg", JSON.stringify({ rc: "d", i: [o.i] })).catch(() => {});
      }
      await done();
    }
    async function listen(g) {
      while (run && g === gen) {
        try {
          ctl = new AbortController();
          const r = await F(url(`/inbox/${uid}/q`), { headers: { accept: "text/event-stream" }, signal: ctl.signal });
          if (!r.ok) throw new Error("listen " + r.status);
          const rd = r.body.getReader(); let buf = "", ev = "", cache = {}; const seen = new Set();
          for (;;) {
            const { value, done } = await rd.read(); if (done) break;
            buf += dec.decode(value, { stream: true });
            let i; while ((i = buf.indexOf("\n")) >= 0) {
              const line = buf.slice(0, i).replace(/\r$/, ""); buf = buf.slice(i + 1);
              if (line.startsWith("event:")) ev = line.slice(6).trim();
              else if (line.startsWith("data:") && (ev === "put" || ev === "patch")) {
                const m = JSON.parse(line.slice(5)); if (m === null) continue;
                const items = m.path === "/" ? Object.entries(m.data || {}) : [[m.path.slice(1).split("/")[0], m.path.split("/").length > 2 ? undefined : m.data]];
                for (const [k, v] of items) if (v && !seen.has(k)) { seen.add(k); await handle(k, v).catch((e) => emit({ t: "log", msg: "handle: " + e.message })); }
              }
            }
          }
        } catch (e) { if (!(run && g === gen)) return; emit({ t: "log", msg: "reconnect: " + e.message }); }
        if (run && g === gen) await new Promise((r) => setTimeout(r, 2000));
      }
    }
    return {
      get id() { return st.id; }, get uid() { return uid; },
      setRoute(r) { localRoute = r || null; }, // r = {on(), send(str)}
      async ingest(str) { let v; try { v = JSON.parse(str); } catch (e) { return; } if (!v || typeof v.f !== "string" || typeof v.d !== "string" || v.f === uid) return; await handle(null, v); }, // frame from Nearby/Bluetooth, opened with the friend key exactly like a server inbox item
      async start(name) {
        api2 = this; run = true; const g = ++gen;
        if (!cfg.databaseURL || !cfg.apiKey) throw new Error("ادخل إعدادات Firebase");
        await ensureKeys(name); await auth();
        await db("PUT", `/users/${uid}`, { pub: JSON.stringify(st.pub), name: st.name || "" });
        const cur = await db("GET", `/handles/${st.id}`);
        if (!cur) await db("PUT", `/handles/${st.id}`, uid); else if (cur !== uid) throw new Error("الـ ID ده متسجل لحساب تاني");
        clearInterval(tokTimer); tokTimer = setInterval(() => auth().catch(() => {}), 45 * 60 * 1000);
        const restored = await restoreBackup().catch(() => 0); if (restored) emit({ t: "restored", friends: restored });
        emit({ t: "ready", id: st.id, uid }); listen(g); clearInterval(fq); fq = setInterval(() => flush().catch(() => {}), 15000); flush().catch(() => {}); if (root.addEventListener) { if (onl) root.removeEventListener("online", onl); onl = () => { flush().catch(() => {}); }; root.addEventListener("online", onl); }
      },
      stop() { run = false; gen++; clearInterval(tokTimer); clearInterval(fq); if (onl && root.removeEventListener) root.removeEventListener("online", onl); try { ctl && ctl.abort(); } catch (e) {} },
      async addFriend(id) {
        id = String(id).trim().toUpperCase(); if (id === st.id) throw new Error("ده الـ ID بتاعك");
        const r = await lookupById(id);
        const ex = st.friends[r.uid];
        if (ex && ex.state === "friend") return "already";
        if (ex && ex.state === "in") return this.accept(r.uid);
        st.friends[r.uid] = { id, name: r.name, pub: r.pub, state: "out" }; save(); scheduleBackup();
        await push(r.uid, "req", JSON.stringify({ name: st.name }), r.pub); return "sent";
      },
      async accept(fu) {
        const f = st.friends[fu]; if (!f || f.state !== "in") throw new Error("مفيش طلب");
        f.state = "friend"; save(); scheduleBackup(); await push(fu, "req", JSON.stringify({ name: st.name })); // our "req" is also an implicit accept if they are waiting
        await push(fu, "acc", JSON.stringify({ name: st.name })); onFriended(fu); return "accepted";
      },
      decline(fu) { const f = st.friends[fu]; if (f && f.state === "in") { delete st.friends[fu]; save(); scheduleBackup(); } },
      async react(fu, mid, emoji) {
        const T = target(fu); await T.send({ rx: mid, e: emoji || "" });
        const r = st.reacts[mid] = st.reacts[mid] || {}; if (emoji) r.me = emoji; else delete r.me; save();
      },
      reactions: (mid) => ({ ...(st.reacts[mid] || {}) }),
      recoveryKey() { return "SRK1." + b64(enc.encode(JSON.stringify({ d: st.priv.d, x: st.pub.x, y: st.pub.y, u: st.uid, r: st.refresh }))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""); },
      pending: () => st.outbox.length, flushNow: () => flush(),
      async send(fu, text, replyTo, mn) {
        const T = target(fu);
        const m = { i: Array.from(C().getRandomValues(new Uint8Array(6)), (x) => x.toString(16).padStart(2, "0")).join(""), t: text, ts: Date.now(), from: "me" };
        if (replyTo) m.re = String(replyTo);
        const x = st.ttl[fu] || 0; if (x) m.x = x;
        if (Array.isArray(mn) && mn.length && T.group) { m.mn = mn.slice(0, 10); }
        const pl = { i: m.i, t: text, re: replyTo || undefined, x: x || undefined, mn: m.mn };
        try { await T.send(pl); } catch (e) {
          if (T.group || !retryable(e)) throw e;
          m.st = -1; addMsg(fu, m); st.outbox.push({ fu, i: m.i, p: JSON.parse(JSON.stringify(pl)) }); save(); return m; // kept, sent when the internet is back
        }
        addMsg(fu, m); m.st = m.st || 0; return m;
      },
      async sendMedia(fu, kind, mime, b64data, caption, vo) {
        const T = target(fu); if (vo && T.group) throw new Error("مرة واحدة في المحادثات الفردية بس");
        if (kind !== "img" && kind !== "voice") throw new Error("نوع مش مدعوم");
        if (b64data.length > MAX_B64) throw new Error("الملف كبير (الحد حوالي ١٦٥ كيلوبايت بعد الضغط)");
        const i = Array.from(C().getRandomValues(new Uint8Array(6)), (x) => x.toString(16).padStart(2, "0")).join("");
        const x = st.ttl[fu] || 0;
        await T.send({ i, t: caption || "", k: kind, m: mime, b: b64data, x: x || undefined, vo: vo ? 1 : undefined });
        if (!vo && store.putMedia) await store.putMedia(i, { m: mime, b: b64data });
        const m = { i, t: caption || "", k: kind, m: mime, ts: Date.now(), from: "me" }; if (!vo) m.mid = i; else m.vo = 1; if (x) m.x = x; addMsg(fu, m); return m;
      },
      media: (mid) => (store.getMedia ? store.getMedia(mid) : null),
      async edit(fu, mid, text) {
        const m = (st.msgs[fu] || []).find((x) => x.i === mid && x.from === "me" && !x.k && !x.del); if (!m) throw new Error("مينفعش تتعدل");
        text = String(text || "").trim(); if (!text) throw new Error("الرسالة فاضية");
        await target(fu).send({ ed: mid, t: text }); m.t = text; m.ed = 1; save();
      },
      async del(fu, mid) {
        const m = (st.msgs[fu] || []).find((x) => x.i === mid && x.from === "me"); if (!m) throw new Error("مش موجودة");
        await target(fu).send({ dl: mid }); await wipe(m);
      },
      async setTtl(fu, secs) { secs = Math.max(0, Math.min(+secs || 0, 30 * 86400)); const T = target(fu); if (!T.group) await T.send({ dt: secs }); st.ttl[fu] = secs; save(); }, // in groups the timer applies to what you send
      ttl: (fu) => st.ttl[fu] || 0,
      prune,
      options: () => ({ ...st.opt }),
      setOptions(o) { st.opt = { ...st.opt, ...o }; save(); },
      async typing(fu) { // optional: only sent if you turned it on; at most once every 4 seconds
        if (!st.opt.typing || !st.friends[fu] || st.friends[fu].state !== "friend") return;
        if (Date.now() - (tyAt[fu] || 0) < 4000) return; tyAt[fu] = Date.now(); await push(fu, "ty", JSON.stringify({ y: 1 }));
      },
      unread: (fu) => st.unread[fu] || 0,
      async markRead(fu) {
        if (fu.startsWith("g:")) { st.unread[fu] = 0; save(); return; }
        const ids = (st.msgs[fu] || []).filter((m) => m.from === fu && !m.del).map((m) => m.i).slice(-50);
        const had = st.unread[fu] || 0; if (had) { st.unread[fu] = 0; save(); }
        if (had && st.opt.read && ids.length) await push(fu, "msg", JSON.stringify({ rc: "r", i: ids }));
      },
      async createGroup(name, uids, channel) {
        name = String(name || "").trim().slice(0, 40); if (!name) throw new Error("اكتب اسم المجموعة");
        const list = [...new Set(uids)].filter((u) => st.friends[u] && st.friends[u].state === "friend"); if (!list.length) throw new Error("اختار صديق على الأقل"); if (list.length > 49) throw new Error("أقصى عدد ٥٠");
        const gid = rid() + rid().slice(0, 0), members = { [uid]: { id: st.id, name: st.name || "", pub: st.pub } };
        for (const u of list) members[u] = { id: st.friends[u].id, name: st.friends[u].name, pub: st.friends[u].pub };
        st.groups[gid] = { name, admin: uid, ad: {}, ch: channel ? 1 : 0, members }; if (st.defTtl) st.ttl["g:" + gid] = st.defTtl; save();
        for (const u of list) await push(u, "msg", JSON.stringify({ gm: { id: gid, name, admin: uid, ad: {}, ch: channel ? 1 : 0, members } })).catch(() => {});
        return "g:" + gid;
      },
      groups: () => Object.entries(st.groups).map(([id, g]) => ({ chat: "g:" + id, name: g.name, admin: isAdmin(g, uid), owner: g.admin === uid, ch: !!g.ch, wo: !!g.wo, ds: g.ds || "", ph: g.ph || "", ad: g.ad || {}, members: Object.entries(g.members).map(([u, m]) => ({ uid: u, id: m.id, name: m.name })) })),
      async sendExtra(fu, obj) { // kind: loc {la,lo} | ct {cid,cn} | stk {s}; optional fw:1
        const T = target(fu), m = { i: rid(), ts: Date.now(), from: "me", t: "" }; if (!kindExtra({ ...obj }, m) || !m.k) throw new Error("بيانات غلط");
        const x = st.ttl[fu] || 0; if (x) m.x = x;
        await T.send({ ...obj, i: m.i, x: x || undefined }); addMsg(fu, m); return m; },
      async forward(fu, text) { const T = target(fu), m = { i: rid(), t: String(text).slice(0, 4000), ts: Date.now(), from: "me", fw: 1 }; await T.send({ i: m.i, t: m.t, fw: 1, x: st.ttl[fu] || undefined }); addMsg(fu, m); return m; },
      block(fu) { st.block[fu] = 1; save(); }, unblock(fu) { delete st.block[fu]; save(); }, isBlocked: (fu) => !!st.block[fu],
      blockedList: () => Object.keys(st.block).map((u) => ({ uid: u, id: (st.friends[u] || {}).id || u, name: (st.friends[u] || {}).name || "" })),
      report(fu) { st.block[fu] = 1; const f = st.friends[fu]; if (f && f.state !== "friend") delete st.friends[fu]; save(); scheduleBackup(); return "blocked-local"; }, // no moderation server exists: report = block + remove, kept on this phone
      searchMessages(q) { q = String(q || "").trim().toLowerCase(); if (q.length < 2) return []; const out = [];
        for (const [ck, l] of Object.entries(st.msgs)) for (const m of l) if (!m.del && m.t && m.t.toLowerCase().includes(q)) out.push({ chat: ck, i: m.i, t: m.t, ts: m.ts, from: m.from });
        return out.sort((a, b) => b.ts - a.ts).slice(0, 50); },
      async addMember(chat, fu) { const gid = chat.slice(2), g = st.groups[gid]; if (!g || !isAdmin(g, uid)) throw new Error("الأدمن بس");
        const f = st.friends[fu]; if (!f || f.state !== "friend") throw new Error("لازم يكون صديقك"); if (g.members[fu]) return; if (Object.keys(g.members).length >= 50) throw new Error("المجموعة اتملت");
        g.members[fu] = { id: f.id, name: f.name, pub: f.pub }; save(); await this._gm(g, gid); },
      async removeMember(chat, mu) { const gid = chat.slice(2), g = st.groups[gid]; if (!g || !isAdmin(g, uid)) throw new Error("الأدمن بس"); if (mu === g.admin || mu === uid) throw new Error("مينفعش");
        const old = { ...g.members }; delete g.members[mu]; if (g.ad) delete g.ad[mu]; save(); await this._gm(g, gid, old); },
      async makeAdmin(chat, mu, on) { const gid = chat.slice(2), g = st.groups[gid]; if (!g || g.admin !== uid) throw new Error("منشئ المجموعة بس"); if (!g.members[mu]) return; g.ad = g.ad || {}; if (on) g.ad[mu] = 1; else delete g.ad[mu]; save(); await this._gm(g, gid); },
      async _gm(g, gid, extra) { const meta = { id: gid, name: g.name, admin: g.admin, ad: g.ad || {}, ch: g.ch ? 1 : 0, wo: g.wo ? 1 : 0, ds: g.ds || "", ph: g.ph || "", members: g.members }; const tgt = { ...(extra || {}), ...g.members };
        for (const u of Object.keys(tgt)) if (u !== uid) await push(u, "msg", JSON.stringify({ gm: meta }), (st.friends[u] && st.friends[u].pub) || tgt[u].pub).catch(() => {}); },
      async groupTyping(chat) { if (!st.opt.typing) return; const gid = chat.slice(2), g = st.groups[gid]; if (!g || Date.now() - (tyAt[chat] || 0) < 4000) return; tyAt[chat] = Date.now();
        for (const u of Object.keys(g.members)) if (u !== uid) push(u, "ty", JSON.stringify({ g: gid }), (st.friends[u] && st.friends[u].pub) || g.members[u].pub).catch(() => {}); },
      async openOnce(fu, mid) { const m = (st.msgs[fu] || []).find((x) => x.mid === mid && x.vo && !x.vd); if (!m) return false; m.vd = 1; if (store.delMedia) await store.delMedia(mid).catch(() => {}); delete m.mid; save(); await target(fu).send({ vw: m.i }).catch(() => {}); return true; },
      star(mid, on) { if (on) st.star[mid] = 1; else delete st.star[mid]; save(); }, isStarred: (mid) => !!st.star[mid],
      starred() { const out = []; for (const [ck, l] of Object.entries(st.msgs)) for (const m of l) if (st.star[m.i] && !m.del) out.push({ chat: ck, i: m.i, t: m.t, k: m.k, ts: m.ts, from: m.from }); return out.sort((a, b) => b.ts - a.ts); },
      async pin(fu, mid) { const T = target(fu); const m = mid && (st.msgs[fu] || []).find((x) => x.i === mid); const pt = m ? String(m.t || (m.k ? "[" + m.k + "]" : "")).slice(0, 80) : "";
        await T.send({ pn: mid || null, pt }); if (mid) st.pin[fu] = { i: mid, t: pt }; else delete st.pin[fu]; save(); },
      pinned: (fu) => st.pin[fu] || null,
      async vote(fu, pid, ix) { const T = target(fu); const p = (st.msgs[fu] || []).find((x) => x.i === pid && x.k === "poll"); if (!p) throw new Error("مفيش استطلاع"); ix = [...new Set(ix.map(Number).filter((k) => k >= 0 && k < p.po.length))]; if (!p.pm && ix.length > 1) ix.length = 1;
        await T.send({ pv: pid, ix }); const v = st.votes[pid] = st.votes[pid] || {}; if (ix.length) v.me = ix; else delete v.me; save(); },
      tally(pid) { let p = null; for (const l of Object.values(st.msgs)) { p = l.find((x) => x.i === pid && x.k === "poll"); if (p) break; } if (!p) return null; const v = st.votes[pid] || {}, counts = p.po.map(() => 0); let voters = 0; for (const ix of Object.values(v)) { voters++; for (const k of ix) counts[k]++; } return { counts, voters, mine: v.me || [] }; },
      async liveUpdate(fu, id, la, lo, end) { const m = (st.msgs[fu] || []).find((x) => x.i === id && x.k === "ll" && x.from === "me"); if (!m) return false; if (end) m.u = Date.now(); else { m.la = la; m.lo = lo; m.lt = Date.now(); } save(); await target(fu).send({ lu: id, la, lo, end: end ? 1 : undefined }); return Date.now() < m.u; },
      profile: () => ({ about: st.prof.a || "", ph: st.prof.ph || "" }),
      async setProfile(about, photoB64) { about = String(about || "").slice(0, 140); if (photoB64 && (photoB64.length > 30000 || !/^[A-Za-z0-9+/=]*$/.test(photoB64))) throw new Error("الصورة كبيرة"); st.prof = { a: about, ph: photoB64 || "" }; save();
        for (const [u, f] of Object.entries(st.friends)) if (f.state === "friend" && !st.block[u]) await push(u, "msg", JSON.stringify({ pf: { a: st.prof.a, ph: st.prof.ph } })).catch(() => {}); },
      setNick(fu, nick) { const f = st.friends[fu]; if (!f) return; nick = String(nick || "").trim().slice(0, 40); if (nick) f.nick = nick; else delete f.nick; save(); },
      async setGroupInfo(chat, o) { const gid = chat.slice(2), g = st.groups[gid]; if (!g || !isAdmin(g, uid)) throw new Error("الأدمن بس");
        if (o.name !== undefined) { const n = String(o.name).trim().slice(0, 40); if (n) g.name = n; } if (o.ds !== undefined) g.ds = String(o.ds).slice(0, 200);
        if (o.ph !== undefined) { if (o.ph && (o.ph.length > 30000 || !/^[A-Za-z0-9+/=]*$/.test(o.ph))) throw new Error("الصورة كبيرة"); g.ph = o.ph || ""; }
        if (o.wo !== undefined && !g.ch) g.wo = o.wo ? 1 : 0; save(); await this._gm(g, gid); },
      groupInviteLink(chat) { const gid = chat.slice(2), g = st.groups[gid]; if (!g || !isAdmin(g, uid)) throw new Error("الأدمن بس"); return `sirrna://join?g=${gid}&a=${st.id}&n=${encodeURIComponent(g.name)}`; },
      async requestJoin(link) { const p = parseJoin(link); if (!p) throw new Error("كود الدعوة مش صح"); if (st.groups[p.gid]) return "already"; if (p.admin === st.id) throw new Error("ده كودك");
        const fe = Object.entries(st.friends).find(([, f]) => f.id === p.admin);
        if (fe && fe[1].state === "friend") { await push(fe[0], "msg", JSON.stringify({ jr: p.gid })); return "requested"; }
        st.pj[p.gid] = p.admin; save(); const r = await this.addFriend(p.admin); return r === "already" ? "requested" : "friend-first"; },
      joinRequests: () => st.jreq.slice(),
      async approveJoin(gid, mu) { st.jreq = st.jreq.filter((q) => !(q.gid === gid && q.uid === mu)); save(); await this.addMember("g:" + gid, mu); },
      declineJoin(gid, mu) { st.jreq = st.jreq.filter((q) => !(q.gid === gid && q.uid === mu)); save(); },
      setDefaultTtl(secs) { st.defTtl = Math.max(0, Math.min(+secs || 0, 30 * 86400)); save(); }, defaultTtl: () => st.defTtl || 0,
      verifiedNum: (fu) => (st.friends[fu] || {}).ver || null,
      setVerified(fu, num) { if (st.friends[fu]) { st.friends[fu].ver = num; save(); } },
      async exportBackup(pass) { if (!pass || pass.length < 8) throw new Error("الباسورد لازم ٨ حروف على الأقل"); const media = {};
        for (const l of Object.values(st.msgs)) for (const m of l) if (m.mid && store.getMedia) { const md = await store.getMedia(m.mid); if (md) media[m.mid] = md; }
        const salt = C().getRandomValues(new Uint8Array(16)), key = await passKey(pass, salt);
        const data = { v: 1, id: st.id, msgs: st.msgs, reacts: st.reacts, star: st.star, pin: st.pin, votes: st.votes, ttl: st.ttl, groups: st.groups, media };
        return JSON.stringify({ sirrnaBackup: 1, s: b64(salt), d: await seal(key, JSON.stringify(data)) }); },
      async importBackup(text, pass) { let o; try { o = JSON.parse(text); } catch (e) { throw new Error("الملف مش نسخة سرّنا"); } if (!o || o.sirrnaBackup !== 1) throw new Error("الملف مش نسخة سرّنا");
        let data; try { data = JSON.parse(await open(await passKey(pass, unb64(o.s)), o.d)); } catch (e) { throw new Error("الباسورد غلط أو الملف باظ"); }
        if (data.id !== st.id) throw new Error("النسخة دي لحساب تاني (ID " + data.id + "). استرجع حسابك بمفتاح الاسترجاع الأول");
        let n = 0; for (const [ck, l] of Object.entries(data.msgs || {})) { const cur = st.msgs[ck] = st.msgs[ck] || []; const have = new Set(cur.map((m) => m.i)); for (const m of l) if (!have.has(m.i)) { cur.push(m); n++; } cur.sort((a, b) => a.ts - b.ts); }
        for (const k of ["reacts", "star", "pin", "votes", "ttl"]) st[k] = { ...(data[k] || {}), ...st[k] }; for (const [g, v] of Object.entries(data.groups || {})) if (!st.groups[g]) st.groups[g] = v;
        if (store.putMedia) for (const [k, v] of Object.entries(data.media || {})) await store.putMedia(k, v); save(); return n; },
      async setPushToken(t) { if (t && t !== st.pushTok) { await db("PUT", `/push/${uid}`, { t: String(t).slice(0, 400) }); st.pushTok = t; save(); } },
      async sendSig(fu, obj) { const f = st.friends[fu]; if (!f || f.state !== "friend" || st.block[fu]) throw new Error("مش صديق"); await push(fu, "sig", JSON.stringify(obj)); },
      async postStatus(text, bg, img) { const q = { i: rid(), t: String(text || "").slice(0, 500), bg: bg || "#2f6fed" }; if (img) { if (img.b.length > MAX_B64) throw new Error("الصورة كبيرة"); q.b = img.b; q.m = img.m; }
        const e = { i: q.i, t: q.t, bg: q.bg, ts: Date.now() }; if (img && store.putMedia) { e.mid = "st" + q.i; await store.putMedia(e.mid, img); } st.myStatus = st.myStatus.filter((x) => x.ts > Date.now() - 86400000).concat(e); save();
        for (const [u, f] of Object.entries(st.friends)) if (f.state === "friend" && !st.block[u]) await push(u, "msg", JSON.stringify({ stt: q })).catch(() => {}); return e; },
      statuses: () => { const lim = Date.now() - 86400000; return { mine: st.myStatus.filter((x) => x.ts > lim), friends: Object.entries(st.status).map(([u, a]) => ({ uid: u, name: (st.friends[u] || {}).name || "", items: a.filter((x) => x.ts > lim) })).filter((x) => x.items.length && !st.block[x.uid]) }; },
      async leaveGroup(chat) { const gid = chat.slice(2), g = st.groups[gid]; if (!g) return; delete st.groups[gid]; delete st.msgs[chat]; delete st.unread[chat]; save(); },
      lastActivity: (fu) => { const l = (st.msgs[fu] || []).slice(-1)[0]; return l ? l.ts : 0; },
      friends: () => Object.entries(st.friends).map(([u, f]) => ({ uid: u, id: f.id, name: f.nick || f.name, real: f.name, nick: f.nick || "", about: f.about || "", ph: f.ph || "", state: f.state })),
      messages: (fu) => (st.msgs[fu] || []).slice(),
      safety: (fu) => safetyNumber(st.pub, st.friends[fu].pub),
      inviteLink: () => inviteLink(st.id, st.name),
    };
  }
  async function restoreFromKey(key, store) { // new phone: put the saved key pair + login into the store, then create()/start() as usual
    const m = /^SRK1\.([A-Za-z0-9_-]+)$/.exec((key || "").trim()); if (!m) throw new Error("مفتاح الاسترجاع مش صحيح");
    let o; try { o = JSON.parse(dec.decode(unb64(m[1].replace(/-/g, "+").replace(/_/g, "/")))); } catch (e) { throw new Error("مفتاح الاسترجاع مش صحيح"); }
    if (!o.d || !o.x || !o.y || !o.u || !o.r) throw new Error("مفتاح الاسترجاع ناقص");
    const pub = { kty: "EC", crv: "P-256", x: o.x, y: o.y };
    const id = await pubId(pub);
    store.set({ priv: { ...pub, d: o.d, ext: true, key_ops: ["deriveBits"] }, pub, id, uid: o.u, refresh: o.r, friends: {}, msgs: {}, reacts: {} });
    return id;
  }
  const api = { restoreFromKey, create, pubId, seal, open, aesKey, inviteLink, parseInvite, parseJoin, safetyNumber };
  if (typeof module !== "undefined") module.exports = api; else root.SirrnaAccounts = api;
})(typeof window !== "undefined" ? window : globalThis);
