# Fixes applied to v17 → v18 (2026-11-27)

Based on the audit of `sirrna_1` (real build, not demo) vs `sirrna-DEMO`.

## Fixed in source

1. **Dangling demo scripts in the real build** — `app.html` (both
   `android-nearby-test/app/src/main/assets/app.html` and `accounts/app.html`)
   loaded `demo.js` unconditionally, but that file only exists in the demo
   build (`src/demo/assets`). Now `demo.js` is loaded only when
   `window.SIRRNA_DEMO` is set by `demo-flag.js`, via a synchronous
   `document.write` so it still overrides `fetch` before the app starts.
   The demo build (`gradle assembleDebug -Pdemo`) is unaffected.
2. **Release build** — `app/build.gradle`: `versionCode 1 → 2`,
   `versionName '0.1-test' → '0.2'`, app label `'سرّنا (تجربة)' → 'سرّنا'`.
   The `release` build type now uses the same CI keystore signing as debug
   (when `SIRRNA_KEYSTORE` is set). New workflow
   `.github/workflows/build-release.yml` runs `assembleRelease`
   (debuggable=false by default) and verifies the signature.
3. **WebView debugging in release** — `MainActivity.java`:
   `setWebContentsDebuggingEnabled(true)` is now `BuildConfig.DEBUG`,
   so it is off in release builds.
4. **Push Worker config** — `push-worker/wrangler.toml`: filled in the real
   Firebase project values verified from the built `sirrna_1` APK
   (`FB_PROJECT_ID = "sirrna"`,
   `DB_URL = "https://sirrna-default-rtdb.europe-west1.firebasedatabase.app"`).
   `SA_JSON` stays a Cloudflare secret, never in the file.

## Still needs the user (not in the source)

- **TURN**: no free TURN is bundled. Calls still fail when both phones are
  behind strict/carrier NAT. Put your TURN host/username/credential in the
  app's Settings → voice calls (stored on the phone only).
- **Push Worker deploy**: deploy `push-worker/worker.js` to Cloudflare
  (free), set `FB_PROJECT_ID` / `DB_URL` (already filled in `wrangler.toml`)
  and the `SA_JSON` secret (Firebase service-account JSON), then paste the
  Worker URL (ending in `/notify`) in the app's Settings. Steps are in
  `accounts/SETUP-ar.md`.
- **GitHub secrets** for the release workflow: `KEYSTORE_B64`,
  `KEYSTORE_PASS`, `GOOGLE_SERVICES_JSON` (same as the debug workflow).
- **targetSdk 34 kept on purpose**: bumping to 35 was not done blind — it
  needs a CI build + device test first. After the release workflow passes,
  verify the built APK with `apksigner verify -v` (check v2/v3) before
  publishing.

## Not built here

No Java/Gradle on this machine, so the APK was **not** built locally. Run
the `Build Sirrna RELEASE APK` workflow on GitHub to get the signed
release APK.
