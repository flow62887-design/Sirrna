// Fails if web assets use syntax/APIs missing from old Android WebView (Chrome ~74, Android 10 without WebView updates).
// Usage: NODE_PATH=<dir with acorn> node tools/compat-check.js [assetsDir...]
const fs = require("fs"), path = require("path");
let acorn; try { acorn = require("acorn"); } catch (e) { console.log("acorn not installed: run `npm i acorn@8`"); process.exit(2); }
const dirs = process.argv.slice(2).length ? process.argv.slice(2) : ["android-nearby-test/app/src/main/assets", "android-nearby-test/app/src/demo/assets"];
const API = [[/\.replaceAll\(/, "String.replaceAll (Chrome 85)"], [/\.at\(-?\d/, "Array/String.at (Chrome 92)"], [/Promise\.allSettled|Promise\.any\(/, "Promise.allSettled/any (76/85)"], [/Object\.hasOwn\(/, "Object.hasOwn (93)"], [/structuredClone\(/, "structuredClone (98)"], [/crypto\.randomUUID/, "crypto.randomUUID (92)"], [/\.replaceChildren\(/, "replaceChildren (86)"], [/\.findLast(Index)?\(/, "findLast (97)"], [/AbortSignal\.timeout/, "AbortSignal.timeout (103)"], [/\.(toSorted|toReversed|with)\(/, "ES2023 array methods"], [/new Intl\.Segmenter|\.matchAll\(/, "Intl.Segmenter/matchAll (73+)"], [/\bglobalThis\b/, "globalThis (71)"], [/\bstructuredClone\b/, "structuredClone"]];
const CSS = [[/:is\(|:where\(|:has\(/, "CSS :is/:where/:has"], [/aspect-ratio\s*:/, "aspect-ratio (88)"], [/\binset\s*:/, "inset shorthand (87)"], [/\b\d*d?vh\b/.source && /\b\d+(dvh|svh|lvh)\b/, "dvh/svh units (108)"], [/color-mix\(/, "color-mix"], [/@layer\b/, "@layer"], [/\bgap\s*:/, "gap (flex gap Chrome 84, grid gap ok): needs a fallback check by hand"]];
let bad = 0, warn = 0;
const fail = (f, m) => { console.log("FAIL", f, m); bad++; }, note = (f, m) => { console.log("WARN", f, m); warn++; };
function checkJs(file, code, off) { try { acorn.parse(code, { ecmaVersion: 2019, sourceType: "script", allowHashBang: true }); } catch (e) { fail(file, `syntax not ES2019 (line ${e.loc ? e.loc.line + off : "?"}): ${e.message}`); return; } for (const [re, name] of API) if (re.test(code)) note(file, "uses " + name); }
for (const d of dirs) { if (!fs.existsSync(d)) continue; for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory() || /\.(ttf|woff2?|png)$/.test(f)) continue; const t = fs.readFileSync(p, "utf8");
  if (f.endsWith(".js")) checkJs(p, t, 0);
  else if (f.endsWith(".html")) { const re = /<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/g; let m; while ((m = re.exec(t))) checkJs(p + "(inline)", m[1], t.slice(0, m.index).split("\n").length - 1);
    const css = [...t.matchAll(/<style[^>]*>([\s\S]*?)<\/style>/g)].map((x) => x[1]).join("\n"); for (const [re2, name] of CSS) if (re2 && re2.test(css)) note(p, "CSS " + name); } } }
console.log(`compat-check: ${bad} failing, ${warn} warnings`); process.exit(bad ? 1 : 0);
