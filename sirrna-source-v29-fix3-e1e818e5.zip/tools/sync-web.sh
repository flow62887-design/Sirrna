#!/bin/sh
# Sync the web UI from its single source of truth (accounts/) into the
# Android assets checked in for the APK build.
#
# accounts/ owns app.html + app.css + app.js. The copies under
# android-nearby-test/app/src/main/assets/ stay checked in so the APK
# builds with no extra step, but they must never be edited by hand:
# edit accounts/ and run this script (or it is caught by tests/web-sync.test.js).
set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT/accounts"
DST="$ROOT/android-nearby-test/app/src/main/assets"
for f in app.html app.css app.js; do
  cp "$SRC/$f" "$DST/$f"
  cmp -s "$SRC/$f" "$DST/$f" || { echo "sync-web: $f mismatch after copy" >&2; exit 1; }
done
echo "sync-web: app.html app.css app.js synced accounts/ -> assets/"
