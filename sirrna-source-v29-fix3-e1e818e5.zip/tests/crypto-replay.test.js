// Sirrna crypto + anti-replay + recovery-key tests. No dependencies: node:test + node:assert only.
// Covers accounts/accounts.js (seal/open/aesKey/inviteLink/parseInvite, recoveryKey/
// restoreFromKey incl. the v27 #9 token-less-key fallback) against accounts/fake-rtdb.js,
// the local fake Firebase (REST + SSE) on port 8098.
// Run from the repo root:  node --test tests/
const { test, after } = require("node:test");
const assert = require("node:assert");
const A = require("../accounts/accounts.js");
const fake = require("../accounts/fake-rtdb.js");

// The fake server starts listening on require (port 8098); close it when done so
// the test process can exit.
after(() => { fake.server.closeAllConnections?.(); fake.server.close(); });

// Same fetch shim as the old manual accounts/test.js: point the Firebase URLs
// used by accounts.js at the local fake.
const rw = (url, o) => fetch(url
  .replace(/^https:\/\/(identitytoolkit|securetoken)\.googleapis\.com/, "http://localhost:8098")
  .replace("https://fake-db", "http://localhost:8098"), o);

const wait = (f, ms = 8000) => new Promise((ok, no) => {
  const s = Date.now();
  (function p() { if (f()) return ok(); if (Date.now() - s > ms) return no(new Error("timeout waiting for " + f)); setTimeout(p, 40); })();
});

// Same in-memory store shape as the old manual accounts/test.js.
function freshStore() {
  let data = null; const med = {};
  return {
    get: () => data,
    set: (d) => { data = JSON.parse(JSON.stringify(d)); },
    dump: () => data,
    putMedia: async (k, v) => { med[k] = v; },
    getMedia: async (k) => med[k],
    delMedia: async (k) => { delete med[k]; },
  };
}
function mk(store) {
  const ev = []; const st = store || freshStore();
  const a = A.create((e) => ev.push(e), { databaseURL: "https://fake-db", apiKey: "k" }, st, rw);
  return { a, ev, store: st };
}
const stopAll = (...xs) => { for (const x of xs) try { x.a.stop(); } catch {} };
// v27 #9 helpers: a friended pair whose friends backup has landed on the server.
const b64url = (s) => Buffer.from(s).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const keyPayload = (key) => JSON.parse(Buffer.from(key.slice(5).replace(/-/g, "+").replace(/_/g, "/"), "base64").toString());
async function waitBackup(uid) { // the friends backup is written on a 1500ms debounce; poll until it lands
  const s = Date.now();
  for (;;) {
    const b = await (await rw(`https://fake-db/backup/${uid}.json?auth=t`)).json();
    if (b && b.d) return;
    if (Date.now() - s > 8000) throw new Error("friends backup never landed for " + uid);
    await new Promise((r) => setTimeout(r, 100));
  }
}
async function friendedPair() {
  fake.reset();
  const a = mk(), b = mk();
  await a.a.start("Alice");
  await b.a.start("Bob");
  await a.a.addFriend(b.a.id);
  await wait(() => b.ev.some((e) => e.t === "request"));
  await b.a.accept(b.ev.find((e) => e.t === "request").uid);
  await wait(() => a.ev.some((e) => e.t === "friend"));
  await waitBackup(a.a.uid);
  return { a, b };
}

async function genKeyPair() {
  const kp = await globalThis.crypto.subtle.generateKey(
    { name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]);
  return { priv: kp.privateKey, pub: await globalThis.crypto.subtle.exportKey("jwk", kp.publicKey) };
}

test("(a) ECDH seal/open round-trip with long Arabic text", async () => {
  const alice = await genKeyPair(), bob = await genKeyPair();
  const keyAB = await A.aesKey(alice.priv, bob.pub);
  const keyBA = await A.aesKey(bob.priv, alice.pub);
  // Long text (>64 chars) exercises the gzip path inside seal(); short text the plain path.
  const long = "مرحبا بالعالم! هذه رسالة اختبار للتشفير من الطرف إلى الطرف في سرّنا. ".repeat(20);
  const sealed = await A.seal(keyAB, long);
  assert.equal(typeof sealed, "string");
  assert.equal(await A.open(keyBA, sealed), long);
  const short = "أهلا";
  assert.equal(await A.open(keyBA, await A.seal(keyAB, short)), short);
});

test("(b) tampered ciphertext or wrong key must be rejected", async () => {
  const alice = await genKeyPair(), bob = await genKeyPair(), eve = await genKeyPair();
  const keyAB = await A.aesKey(alice.priv, bob.pub);
  const keyBA = await A.aesKey(bob.priv, alice.pub);
  const keyEB = await A.aesKey(eve.priv, bob.pub);
  const sealed = await A.seal(keyAB, "رسالة سرية لا يجب أن يقرأها أحد غير بوب");
  // Wrong key: Eve's derived key must not open Alice->Bob ciphertext (AES-GCM auth fails).
  await assert.rejects(A.open(keyEB, sealed));
  // Tampered ciphertext: flip one base64 char inside the ciphertext part (after the ".").
  const dot = sealed.indexOf(".");
  const bad = sealed.slice(0, dot + 2) + (sealed[dot + 2] === "A" ? "B" : "A") + sealed.slice(dot + 3);
  assert.notEqual(bad, sealed);
  await assert.rejects(A.open(keyBA, bad));
  // Tampered IV part must also fail.
  const badIv = (sealed[1] === "A" ? "B" : "A") + sealed.slice(2);
  await assert.rejects(A.open(keyBA, badIv));
});

test("(c) anti-replay: a re-sent inbox payload is delivered only once", async () => {
  fake.reset();
  const a = mk(), b = mk();
  let b2 = null;
  try {
    await a.a.start("Alice");
    await b.a.start("Bob");
    assert.equal(await a.a.addFriend(b.a.id), "sent");
    await wait(() => b.ev.some((e) => e.t === "request"));
    await b.a.accept(b.ev.find((e) => e.t === "request").uid);
    await wait(() => a.ev.some((e) => e.t === "friend"));
    const bu = a.a.friends()[0].uid, au = b.a.friends()[0].uid;
    // B goes offline; A sends while B is away so the payload stays queued in the inbox.
    b.a.stop();
    await a.a.send(bu, "رسالة سرية للاختبار");
    // Capture the exact queued inbox payload from the fake DB, before B consumes it.
    const inbox = await (await rw(`https://fake-db/inbox/${b.a.uid}/q.json?auth=t`)).json();
    const entries = Object.entries(inbox || {}).filter(([, v]) => v && v.k === "msg");
    assert.equal(entries.length, 1, "exactly one queued message, got " + JSON.stringify(inbox));
    const payload = entries[0][1];
    // B restarts on the same store and receives the message once.
    const b2ev = [];
    b2 = A.create((e) => b2ev.push(e), { databaseURL: "https://fake-db", apiKey: "k" }, b.store, rw);
    await b2.start();
    await wait(() => b2.messages(au).length === 1);
    assert.equal(b2.messages(au)[0].t, "رسالة سرية للاختبار");
    // Replay: PUT the same payload under a new inbox key, as an attacker would.
    await rw(`https://fake-db/inbox/${b.a.uid}/q/-kreplay1.json?auth=t`,
      { method: "PUT", body: JSON.stringify(payload) });
    await new Promise((r) => setTimeout(r, 2000));
    assert.equal(b2.messages(au).length, 1, "replayed copy must be dropped, still 1 message");
    assert.equal(b2.messages(au)[0].t, "رسالة سرية للاختبار");
  } finally {
    try { if (b2) b2.stop(); } catch {}
    try { b.a.stop(); } catch {}
    try { a.a.stop(); } catch {}
  }
});

test("(d) inviteLink/parseInvite round-trip (sirrna:// and https://)", async () => {
  const id = "K7M2QX9P4R"; // valid 10-char public ID format
  const link = A.inviteLink(id, "Lulu");
  assert.equal(link, "sirrna://add?id=K7M2QX9P4R&n=Lulu");
  assert.deepEqual(A.parseInvite(link), { id, name: "Lulu" });
  assert.deepEqual(A.parseInvite(A.inviteLink(id)), { id, name: "" });
  // Web form of the invite link (same id, served as i.html).
  assert.deepEqual(
    A.parseInvite(`https://example.com/i.html?id=${id}&n=${encodeURIComponent("Lulu")}`),
    { id, name: "Lulu" });
  assert.deepEqual(A.parseInvite(`https://example.com/i.html?id=${id}`), { id, name: "" });
  // In-app hash form.
  assert.deepEqual(A.parseInvite(`#/add?id=${id}`), { id, name: "" });
  // Garbage is not an invite.
  assert.equal(A.parseInvite("hello"), null);
  assert.equal(A.parseInvite(""), null);
  assert.equal(A.parseInvite(null), null);
});

// ---- v27 #9: full account recovery via the Firebase refresh token in the key.
// NOTE: there is no 12-word mnemonic anywhere in this codebase; the recovery key
// is SRK1. + base64url(JSON), so "wrong words" here means a corrupted/tampered key.

test("(e) recovery key with a refresh token restores the SAME uid and friends", async () => {
  const { a, b } = await friendedPair();
  let c = null;
  try {
    const key = a.a.recoveryKey();
    // The exported key carries the Firebase refresh token for this account.
    const payload = keyPayload(key);
    assert.equal(payload.u, a.a.uid);
    assert.equal(payload.r, a.store.dump().refresh);
    assert.ok(typeof payload.r === "string" && payload.r.length > 0, "key must carry a refresh token");
    // App order (app.html setup screen): restore first, then create, then start.
    const storeC = freshStore();
    assert.equal(await A.restoreFromKey(key, storeC), a.a.id);
    c = mk(storeC);
    await c.a.start("Alice2");
    assert.equal(c.a.uid, a.a.uid, "same uid after restore, not a new account");
    assert.equal(c.a.id, a.a.id);
    assert.equal(c.a.friends().length, 1);
    assert.equal(c.a.friends()[0].id, b.a.id);
    assert.equal(c.a.friends()[0].state, "friend");
  } finally { stopAll(a, b); if (c) try { c.a.stop(); } catch {} }
});

test("(f) restore done AFTER create() is still picked up by start()", async () => {
  const { a, b } = await friendedPair();
  let c = null;
  try {
    const key = a.a.recoveryKey();
    const storeC = freshStore();
    c = mk(storeC); // created BEFORE the restore (wrong order: used to silently mint a new identity)
    await A.restoreFromKey(key, storeC);
    await c.a.start("Alice2");
    assert.equal(c.a.uid, a.a.uid, "same uid even when restore ran after create()");
    assert.equal(c.a.friends().length, 1);
    assert.equal(c.a.friends()[0].id, b.a.id);
  } finally { stopAll(a, b); if (c) try { c.a.stop(); } catch {} }
});

test("(g) old-format key WITHOUT a refresh token is refused, never a new identity", async () => {
  const { a, b } = await friendedPair();
  let c = null;
  try {
    const payload = keyPayload(a.a.recoveryKey());
    delete payload.r; // simulate a key exported before the token was included
    const oldKey = "SRK1." + b64url(JSON.stringify(payload));
    const storeC = freshStore();
    await assert.rejects(A.restoreFromKey(oldKey, storeC), /\u062a\u0648\u0643\u0646|refresh/i);
    // Refused means nothing was written: no half-restored store, no new identity.
    const dump = storeC.dump() || {};
    assert.equal(dump.id, undefined, "no ID minted");
    assert.equal(dump.priv, undefined, "no key pair minted");
    // Only an explicit new account afterwards, which is what the error tells the user.
    c = mk(storeC);
    await c.a.start("Alice2");
    assert.notEqual(c.a.uid, a.a.uid, "still a separate account, never a silent restore");
  } finally { stopAll(a, b); if (c) try { c.a.stop(); } catch {} }
});

test("(h) corrupted recovery keys are rejected", async () => {
  const { a, b } = await friendedPair();
  try {
    const key = a.a.recoveryKey();
    const store = freshStore();
    await assert.rejects(A.restoreFromKey("", store));
    await assert.rejects(A.restoreFromKey("hello", store));
    await assert.rejects(A.restoreFromKey("SRK2." + key.slice(5), store)); // wrong prefix
    await assert.rejects(A.restoreFromKey(key.slice(0, 30), store)); // truncated
    await assert.rejects(A.restoreFromKey("SRK1." + b64url("not json at all"), store)); // unreadable payload
    const noD = keyPayload(key); delete noD.d; // missing private key part
    await assert.rejects(A.restoreFromKey("SRK1." + b64url(JSON.stringify(noD)), store));
    const noU = keyPayload(key); delete noU.u; // missing uid
    await assert.rejects(A.restoreFromKey("SRK1." + b64url(JSON.stringify(noU)), store));
  } finally { stopAll(a, b); }
});
