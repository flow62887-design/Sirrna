// Single source of truth for the web UI: accounts/ owns app.html, app.css
// and app.js. The copies under android-nearby-test/app/src/main/assets/
// stay checked in so the APK builds with no extra step, but they must be
// byte-identical to accounts/ — edit accounts/ and run tools/sync-web.sh.
// See: tools/sync-web.sh
"use strict";
const { test } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const ROOT = path.resolve(__dirname, "..");
const SRC = path.join(ROOT, "accounts");
const DST = path.join(ROOT, "android-nearby-test", "app", "src", "main", "assets");
const FILES = ["app.html", "app.css", "app.js"];

for (const f of FILES) {
  test(`web sync: ${f} is byte-identical in accounts/ and assets/`, () => {
    const a = fs.readFileSync(path.join(SRC, f));
    const b = fs.readFileSync(path.join(DST, f));
    assert.ok(a.equals(b), `${f} differs between accounts/ and assets/ — run tools/sync-web.sh`);
  });
}

test("web split: app.html is a thin shell (no <style>, no large inline script)", () => {
  const html = fs.readFileSync(path.join(SRC, "app.html"), "utf8");
  assert.ok(!html.includes("<style"), "app.html still contains a <style> block");
  assert.ok(html.includes('<link rel="stylesheet" href="app.css">'), "app.html must link app.css");
  assert.ok(html.includes('<script src="app.js"></script>'), "app.html must load app.js");
  // The only inline <script> left is the synchronous demo loader, which must
  // stay inline: document.write keeps demo.js synchronous so it still
  // overrides fetch before app.js starts.
  const inlineScripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)];
  assert.equal(inlineScripts.length, 1, "exactly one inline <script> (the demo loader) is allowed");
  assert.ok(inlineScripts[0][1].includes("document.write"), "the inline script must be the demo loader");
  assert.ok(inlineScripts[0][1].includes("SIRRNA_DEMO"), "the inline script must be the demo loader");
  // Load order: external scripts first, demo loader, then app.js last.
  const order = ["qrcode.js", "jsQR.js", "accounts.js", "calls.js", "demo-flag.js", "demo.js", "app.js"];
  let prev = -1;
  for (const name of order) {
    const i = html.indexOf(name);
    assert.ok(i > prev, `app.html: ${name} is missing or out of order`);
    prev = i;
  }
});

test("web split: app.js parses (node --check equivalent)", () => {
  // Syntax is verified by node --check in CI/dev; here just confirm the file
  // is non-trivial and matches the extracted inline script size sanity.
  const js = fs.readFileSync(path.join(SRC, "app.js"), "utf8");
  assert.ok(js.length > 100000, "app.js looks truncated");
  assert.ok(!js.includes("</script"), "app.js must not contain a closing script tag");
});
