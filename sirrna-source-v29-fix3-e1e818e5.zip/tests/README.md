# Tests

Automated tests for Sirrna. No dependencies — plain `node:test` + `node:assert`.

## Run

From the repo root:

```sh
node --test tests/
```

`tests/index.js` is a thin entry point that loads every suite in this folder:
on Node 22+ a bare directory argument is treated as a module to run, not a
directory to scan, so without it `node --test tests/` fails with
`Cannot find module '.../tests'`. Alternatives that also work:

```sh
node --test tests/crypto-replay.test.js
node --test "tests/**/*.test.js"
```

## What is covered

`tests/crypto-replay.test.js` exercises `accounts/accounts.js` against the local
fake Firebase server in `accounts/fake-rtdb.js` (REST + SSE on port 8098):

- **(a)** ECDH P-256 seal/open round-trip with long Arabic text (gzip path) and short text.
- **(b)** Tampered ciphertext / IV or a wrong key must be rejected by `open()`.
- **(c)** Anti-replay end-to-end: A sends B a message while B is offline, B receives
  it once after restart, then the same inbox payload re-PUT under a new key must
  be dropped (B still has exactly 1 message).
- **(d)** `inviteLink`/`parseInvite` round-trip for `sirrna://`, `https://…/i.html?id=…`
  and `#/add?` links.

`tests/web-sync.test.js` checks the split web UI (v27): `accounts/` is the
single source of truth for `app.html`, `app.css` and `app.js`, and the
checked-in copies under `android-nearby-test/app/src/main/assets/` must be
byte-identical (edit `accounts/` and run `tools/sync-web.sh`). It also checks
`app.html` is a thin shell — no `<style>`, exactly one inline `<script>` (the
synchronous demo loader) — and that the scripts load in order with `app.js`
last.

The fake server starts listening when required and is closed by the test file's
`after()` hook (via the exported `server` handle) so the test process exits.
