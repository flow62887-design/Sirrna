// Entry point so `node --test tests/` works on Node 22+, where a bare directory
// argument is treated as a module to run instead of a directory to scan
// (otherwise: Error: Cannot find module '.../tests').
// It loads every suite in this folder. Running a suite directly
// (node --test tests/crypto-replay.test.js) or via glob
// (node --test "tests/**/*.test.js") skips this file.
require("./crypto-replay.test.js");
require("./web-sync.test.js");
