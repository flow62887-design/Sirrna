// Smoke test for the DEMO app, driven over the WebView DevTools protocol, with REAL Android Back key presses via adb.
// Modes: default = Android emulator (adb). SMOKE_MODE=chrome = dry run against a desktop Chrome page (Back is simulated by window.__back()).
const WebSocket = require("ws");
const { execSync, spawnSync } = require("child_process");
const fs = require("fs"), http = require("http");
const OUT = process.env.OUT || "shots"; fs.mkdirSync(OUT, { recursive: true });
const PKG = "app.sirrna.demo", ACT = "app.sirrna.nearby.MainActivity";
const MODE = process.env.SMOKE_MODE || "adb";
const sh = (c) => execSync(c, { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] });
const sl = (ms) => new Promise((r) => setTimeout(r, ms));
const results = []; let n = 0, ws, id = 0; const pend = {};
const rec = (name, ok, extra) => { results.push({ name, ok: !!ok, extra: extra || "" }); console.log(ok ? "PASS" : "FAIL", name, extra || ""); };
function getJson(url) { return new Promise((res, rej) => http.get(url, (r) => { let b = ""; r.on("data", (d) => b += d); r.on("end", () => { try { res(JSON.parse(b)); } catch (e) { rej(e); } }); }).on("error", rej)); }
function send(method, params) { return new Promise((res, rej) => { const i = ++id; pend[i] = { res, rej }; ws.send(JSON.stringify({ id: i, method, params })); setTimeout(() => { if (pend[i]) { delete pend[i]; rej(new Error("cdp timeout " + method)); } }, 12000); }); }
async function ev(expr) { const r = await send("Runtime.evaluate", { expression: expr, awaitPromise: true, returnByValue: true }); if (r.exceptionDetails) throw new Error("js: " + JSON.stringify(r.exceptionDetails).slice(0, 200)); return r.result.value; }
async function shot(label) {
  const f = `${OUT}/${String(++n).padStart(2, "0")}-${label}.png`;
  try {
    if (MODE === "chrome") { const r = await send("Page.captureScreenshot", { format: "png" }); fs.writeFileSync(f, Buffer.from(r.data, "base64")); }
    else { const r = spawnSync("adb", ["exec-out", "screencap", "-p"], { maxBuffer: 50e6 }); fs.writeFileSync(f, r.stdout); }
  } catch (e) { console.log("screenshot failed", label, e.message); }
}
async function connect() {
  let url;
  if (MODE === "chrome") { const l = await getJson(`http://localhost:${process.env.PORT || 9222}/json`); url = l.find((t) => t.type === "page").webSocketDebuggerUrl; }
  else {
    for (let i = 0; i < 40 && !url; i++) {
      try {
        const pid = sh(`adb shell pidof ${PKG}`).trim().split(/\s+/)[0]; const m = pid ? [null, "webview_devtools_remote_" + pid] : null;
        if (m) { sh(`adb forward tcp:9222 localabstract:${m[1]}`); const l = await getJson("http://localhost:9222/json"); const pg = l.find((t) => t.type === "page" && /android_asset/.test(t.url)) || l.find((t) => t.type === "page"); if (pg) url = pg.webSocketDebuggerUrl; }
      } catch (e) { }
      if (!url) await sl(1500);
    }
  }
  if (!url) throw new Error("no WebView devtools socket (is the app running and debuggable?)");
  ws = new WebSocket(url, { perMessageDeflate: false }); await new Promise((r, j) => { ws.on("open", r); ws.on("error", j); });
  ws.on("message", (m) => { const d = JSON.parse(m); if (d.id && pend[d.id]) { const p = pend[d.id]; delete pend[d.id]; d.error ? p.rej(new Error(d.error.message)) : p.res(d.result); } });
  await send("Runtime.enable");
}
const view = () => ev("view");
function diag(tag) { if (MODE === "chrome") return; try { console.log("DIAG " + tag + ": " + sh("adb shell dumpsys window | grep -E 'mCurrentFocus|isKeyguardShowing|mDreamingLockscreen|mScreenOn|screenState' | head -8")); console.log(sh("adb shell dumpsys activity activities | grep -E 'ResumedActivity|topResumed' | head -3")); anrDump(); } catch (e) { console.log("diag failed", e.message); } }
function anrDump() { if (MODE === "chrome") return; try { const w = sh("adb shell dumpsys window | grep -c 'Application Not Responding' || true").trim(); if (w !== "0") { console.log("ANR DIALOG PRESENT. pid=" + sh("adb shell pidof " + PKG).trim()); try { sh("adb root"); } catch (e) { } try { console.log(sh("adb shell 'ls -la /data/anr; head -c 6000 /data/anr/anr_* 2>/dev/null | head -120'")); } catch (e) { console.log("no /data/anr access") } try { console.log(sh("adb shell 'logcat -d -b events | grep -i am_anr | tail -3; logcat -d | grep -iE \"ANR in|Reason:\" | tail -6'")); } catch (e) { } } } catch (e) { } }
let anrSeen = 0;
function dismissAnr() { if (MODE === "chrome") return false; try {
  if (sh("adb shell dumpsys window | grep -c 'Application Not Responding' || true").trim() === "0") return false;
  anrSeen++; console.log("WARN ANR dialog present (#" + anrSeen + ") t+" + Math.round((Date.now() - T0) / 1000) + "s since start");
  sh("adb shell uiautomator dump /sdcard/u.xml"); const x = sh("adb shell cat /sdcard/u.xml"); const m = x.match(/text="Wait"[^>]*bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"/) || x.match(/resource-id="android:id\/aerr_wait"[^>]*bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"/);
  if (m) { sh(`adb shell input tap ${(+m[1] + +m[3]) >> 1} ${(+m[2] + +m[4]) >> 1}`); console.log("tapped Wait"); } else console.log("could not find Wait button");
  return true; } catch (e) { return false; } }
const T0 = Date.now();
function wake() { if (MODE === "chrome") return; dismissAnr(); for (const c of ["input keyevent KEYCODE_WAKEUP", "wm dismiss-keyguard", "svc power stayon true", "settings put global window_animation_scale 0", "settings put global transition_animation_scale 0", "settings put global animator_duration_scale 0", "input keyevent KEYCODE_MENU"]) { try { sh("adb shell " + c); } catch (e) { } } }
async function reconnect() { try { ws.close(); } catch (e) { } try { await connect(); await send("Page.bringToFront").catch(() => { }); return true; } catch (e) { return false; } }
async function waitFor(expr, ms = 20000) { const t = Date.now(); let bad = 0; while (Date.now() - t < ms) { try { if (await ev(expr)) return true; bad = 0; } catch (e) { if (++bad >= 2) { wake(); await reconnect(); bad = 0; } } await sl(500); } diag("waitFor failed: " + expr.slice(0, 50)); return false; }
async function idle() { try { const ok = await ev("new Promise(r=>{const s=performance.now();let l=s,n=0;const f=t=>{const d=t-l;l=t;if(d<250){if(++n>=4)return r(true)}else n=0;if(performance.now()-s>9000)return r(false);requestAnimationFrame(f)};requestAnimationFrame(f)})"); if (!ok) console.log("WARN page never became frame-idle (slow software GPU?) before key press"); return ok; } catch (e) { console.log("WARN idle check failed: " + e.message); return false; } }
async function backKey() {
  await idle();
  if (MODE === "chrome") { await ev("window.__back()"); return; }
  dismissAnr(); sh("adb shell input keyevent KEYCODE_BACK");
}
const openRow = (name) => ev(`(()=>{if(view!=='home')document.querySelector('#back').click();const r=[...document.querySelectorAll('#fl .row')].find(r=>r.textContent.includes(${JSON.stringify(name)}));if(!r)return false;r.click();return true})()`);
async function appIsForeground() { if (MODE === "chrome") return true; try { return sh("adb shell dumpsys window").includes(PKG + "/") && /mCurrentFocus=.*app\.sirrna\.demo/.test(sh("adb shell dumpsys window")); } catch (e) { return false; } }
(async () => {
  try {
    if (MODE !== "chrome") {
      try { sh(`adb shell pm grant ${PKG} android.permission.POST_NOTIFICATIONS`); } catch (e) { }
      wake(); await sl(1000);
      sh(`adb shell am start -n ${PKG}/${ACT}`); await sl(8000); wake(); diag("after launch");
    }
    await connect(); await send("Page.bringToFront").catch(() => { });
    rec("app launched and WebView is debuggable", true);
    if (process.env.SMOKE_BLUR === "off") { try { await ev("SET.blur=false;saveSet();applyTheme();true"); console.log("blur forced OFF (SMOKE_BLUR=off)"); } catch (e) { } }
    try { await waitFor("window.__perf&&(window.__perf.avg!==undefined||window.__perf.lite)", 6000); console.log("PERF " + JSON.stringify(await ev("window.__perf")) + " blur-class=" + await ev("document.body.classList.contains('blur')") + " lite-class=" + await ev("document.body.classList.contains('lite')")); } catch (e) { }
    const tHome = Date.now(); rec("opens straight to home (no setup screen)", await waitFor("view==='home'", 40000), "t=" + Math.round((tHome - T0) / 1000) + "s since script start");
    rec("demo data seeded (5 friends)", await waitFor("window.__demoReady===true&&acct.friends().filter(f=>f.state==='friend').length>=5", 120000));
    await sl(2000); await shot("home");
    rec("demo badge visible", await ev("!!document.querySelector('#demoBadge')"));
    rec("open chat", (await openRow("ماما")) && await waitFor("view==='chatv'", 8000)); await sl(800); await shot("chat");
    await backKey(); await sl(1500);
    const homeOk = await waitFor("view==='home'", 25000); const alive = await appIsForeground(); anrDump();
    rec("BACK in chat returns to home (app still open)", alive && homeOk); await shot("after-back-from-chat");
    rec("open chat again + type + send", (await openRow("ماما")) && await ev("(()=>{const i=document.querySelector('#msg');i.value='رسالة من اختبار الإيموليتر';document.querySelector('#send').click();return true})()"));
    rec("my message appears", await waitFor("[...document.querySelectorAll('#chat .b.me')].some(b=>b.textContent.includes('اختبار الإيموليتر'))", 10000));
    const inBefore = await ev("document.querySelectorAll('#chat .b:not(.me)').length");
    rec("simulated reply arrives", await waitFor(`document.querySelectorAll('#chat .b:not(.me)').length>${inBefore}`, 25000), "bubbles before=" + inBefore); await sl(800); await shot("sent-and-reply");
    await ev("document.querySelector('#plus').click()"); await sl(600); await shot("plus-sheet");
    await backKey(); await sl(2500);
    rec("BACK closes the sheet first, stays in chat", await ev("view==='chatv'&&document.querySelector('#mod').classList.contains('hide')")); 
    await backKey(); await sl(800);
    rec("BACK again returns to home", await waitFor("view==='home'", 20000));
    rec("open group chat with poll", (await openRow("شلة الشغل")) && await waitFor("view==='chatv'", 8000)); await sl(800); await shot("group-poll");
    await backKey(); await sl(800);
    await ev("document.querySelector('#gear').click()"); await sl(800); await shot("settings");
    rec("settings open", await waitFor("view==='settings'", 5000));
    rec("route selector renders 3 buttons", await ev("document.querySelectorAll('#rseg button').length===3"));
    await ev("document.querySelector('#rNet').click()"); await sl(300);
    rec("route choice saved (internet)", await ev("JSON.parse(localStorage.sirrna_set||'{}').route==='net'&&document.querySelector('#rNet').classList.contains('on')"));
    rec("route chip visible", await ev("document.querySelector('#rchip').textContent.length>3"), String(await ev("document.querySelector('#rchip').textContent")));
    await backKey(); await sl(800);
    rec("BACK from settings returns to home", await waitFor("view==='home'", 20000)); await shot("home-again");
    rec("compact status strip with + tile", await ev("!!document.querySelector('#stc #addSt')&&!document.querySelector('#stCard b')"));
    await ev("show('voice');renderVoice()"); await sl(400);
    rec("voice tab renders friends", await ev("document.querySelectorAll('#vl .vrow').length>0")); await ev("show('home')");
    rec("glass UI active", await ev("document.body.classList.contains('glass')"));
    rec("blur state reported (true on WebView with backdrop-filter)", true, String(await ev("document.body.classList.contains('blur')")));
    rec("emulated WebView version", true, String(await ev("navigator.userAgent")).slice(0, 120));
    // BACK at home must leave the app (normal Android behaviour)
    if (MODE !== "chrome") { await backKey(); await sl(2500); await shot("after-back-at-home"); rec("BACK at home leaves the app", !(await appIsForeground())); }
  } catch (e) { rec("smoke run completed without exception", false, e.message); await shot("error"); }
  if (anrSeen) console.log(`WARN: an ANR dialog appeared ${anrSeen} time(s): the app main thread stalled (slow emulator GPU or app work). Not counted as logic failure.`);
  fs.writeFileSync(`${OUT}/results.json`, JSON.stringify(results, null, 1));
  const failed = results.filter((r) => !r.ok); console.log(`\n${results.length - failed.length}/${results.length} passed`);
  try { ws && ws.close(); } catch (e) { }
  process.exit(failed.length ? 1 : 0);
})();
