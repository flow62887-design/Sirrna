package app.sirrna.nearby;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/** v19 #9: foreground service that keeps live-location sharing alive while the app is in the
    background. The WebView's geolocation pauses when the activity is stopped, so the service
    requests locations itself (GPS + network, every 12 s) and forwards them to the web app via
    window.__liveLoc(lat, lon), which fans out to all active shares. A partial wake lock keeps
    the CPU awake while the screen is off. The service stops itself when the share time ends
    (or when JS calls Hub.stopLiveService). Needs a CI build to verify on a real device:
    background location delivery and Doze behaviour differ per phone (Xiaomi/HyperOS may still
    delay fixes despite the foreground service). */
public class LocationService extends Service {
    private static final String CH = "sirrna_live";
    private static final int NOTIF_ID = 41;
    private LocationManager lm;
    private PowerManager.WakeLock wl;
    private long stopAt = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable stopper = new Runnable() { @Override public void run() { stopSelf(); } };
    private final LocationListener listener = new LocationListener() {
        @Override public void onLocationChanged(Location l) {
            if (l != null) Hub.liveLoc(l.getLatitude(), l.getLongitude());
        }
        @Override public void onStatusChanged(String p, int s, Bundle e) {}
        @Override public void onProviderEnabled(String p) {}
        @Override public void onProviderDisabled(String p) {}
    };

    @Override
    public void onCreate() {
        super.onCreate();
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH, "مشاركة الموقع لايف", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("بتظهر طول ما مشاركة الموقع شغالة");
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sirrna:live");
            wl.acquire();
        } catch (Throwable t) { wl = null; }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        int minutes = intent != null ? intent.getIntExtra("minutes", 15) : 15;
        if (minutes < 1) minutes = 1;
        if (minutes > 480) minutes = 480;
        stopAt = Math.max(stopAt, System.currentTimeMillis() + minutes * 60000L);
        handler.removeCallbacks(stopper);
        handler.postDelayed(stopper, stopAt - System.currentTimeMillis());
        Notification n;
        if (Build.VERSION.SDK_INT >= 26) {
            n = new Notification.Builder(this, CH)
                    .setContentTitle("سرّنا — مشاركة الموقع لايف")
                    .setContentText("المشاركة شغالة في الخلفية. وقفها من المحادثة.")
                    .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                    .setOngoing(true).build();
        } else {
            n = new Notification.Builder(this)
                    .setContentTitle("سرّنا — مشاركة الموقع لايف")
                    .setContentText("المشاركة شغالة في الخلفية. وقفها من المحادثة.")
                    .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                    .setOngoing(true).build();
        }
        startForeground(NOTIF_ID, n);
        if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 12000, 0, listener, Looper.getMainLooper());
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 12000, 0, listener, Looper.getMainLooper());
        } catch (Throwable t) { /* provider unavailable */ }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(stopper);
        try { if (lm != null) lm.removeUpdates(listener); } catch (Throwable t) { }
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Throwable t) { }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
