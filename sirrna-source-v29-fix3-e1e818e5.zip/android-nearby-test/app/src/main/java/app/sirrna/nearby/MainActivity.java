package app.sirrna.nearby;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView wv;
    private Hub bridge;
    private PermissionRequest pendingReq;
    private android.webkit.GeolocationPermissions.Callback pendingGeo;
    private String pendingGeoOrigin;
    private android.webkit.ValueCallback<Uri[]> fileCb;
    private AlertDialog loadErrorDialog;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        // v19 #10: the screen used to stay on for the whole app session. Now it is kept on
        // only while a call is live (Hub.setKeepScreen, called from the web app).
        if (android.os.Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true); }
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        wv = new WebView(this);
        wv.setBackgroundColor(Color.BLACK);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG); // debug builds only; never in release
        wv.setWebViewClient(new WebViewClient() {
            // Main-frame errors only: subresource failures (e.g. the demo-only
            // demo-flag.js, absent from the real build) must not pop up an error.
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request != null && !request.isForMainFrame()) return;
                String desc = error == null ? "خطأ غير معروف"
                        : (error.getDescription() == null ? "خطأ " + error.getErrorCode() : error.getDescription().toString());
                showLoadError(desc);
            }

            @SuppressWarnings("deprecation")
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                // Pre-M fallback (minSdk is 24, so this is only a safety net); the old
                // callback fires for the main frame only.
                showLoadError(description == null ? "خطأ " + errorCode : description);
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                if (request != null && !request.isForMainFrame()) return;
                int code = errorResponse == null ? 0 : errorResponse.getStatusCode();
                showLoadError("خطأ HTTP " + code);
            }
        });
        wv.getSettings().setMediaPlaybackRequiresUserGesture(false);
        s.setGeolocationEnabled(true);
        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(final String origin, final android.webkit.GeolocationPermissions.Callback cb) {
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) cb.invoke(origin, true, false);
                    else { pendingGeo = cb; pendingGeoOrigin = origin; requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 9); }
                });
            }
            @Override
            public boolean onShowFileChooser(WebView w, android.webkit.ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try { startActivityForResult(p.createIntent(), 77); }
                catch (Exception e) { fileCb = null; return false; }
                return true;
            }
            @Override
            public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> {
                    java.util.List<String> need = new java.util.ArrayList<>();
                    for (String r : req.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.CAMERA);
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO);
                    }
                    if (need.isEmpty()) req.grant(req.getResources());
                    else { pendingReq = req; requestPermissions(need.toArray(new String[0]), 8); }
                });
            }
        });
        bridge = new Hub(this, wv);
        wv.addJavascriptInterface(bridge, "Nearby");
        setContentView(wv);
        handleIntent(getIntent(), true);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == 77) {
            if (fileCb != null) fileCb.onReceiveValue(android.webkit.WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    protected void onResume() { super.onResume(); Notif.fg = true; Notif.clearCall(this); }

    @Override
    protected void onPause() { super.onPause(); Notif.fg = false; }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 10) return;
        if (code == 9) {
            if (pendingGeo != null) { pendingGeo.invoke(pendingGeoOrigin, res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED, false); pendingGeo = null; }
            return;
        }
        if (code == 8) {
            if (pendingReq != null) {
                boolean allOk = res.length > 0;
                for (int g : res) if (g != PackageManager.PERMISSION_GRANTED) allOk = false;
                if (allOk) pendingReq.grant(pendingReq.getResources()); else pendingReq.deny();
                pendingReq = null;
            }
            return;
        }
        bridge.permissionsResult();
    }

    /** sirrna://add?id=XXXX opens the chat app and adds the friend; otherwise the chat app loads normally (app.html). The old test page (index.html) was removed in v25. */
    private void handleIntent(Intent in, boolean first) {
        Uri u = in == null ? null : in.getData();
        if (u != null && "sirrna".equals(u.getScheme())) {
            if ("join".equals(u.getHost())) {
                String g = u.getQueryParameter("g"), ad = u.getQueryParameter("a");
                if (g != null && ad != null && g.matches("[a-f0-9]{12}") && ad.matches("[A-Za-z2-9]{10}")) {
                    String link = "sirrna://join?g=" + g + "&a=" + ad.toUpperCase();
                    if (first) wv.loadUrl("file:///android_asset/app.html#/join?g=" + g + "&a=" + ad.toUpperCase());
                    else wv.evaluateJavascript("window.onSirrnaLink&&window.onSirrnaLink('" + link + "')", null);
                } else if (first) wv.loadUrl("file:///android_asset/app.html");
                return;
            }
            String id = u.getQueryParameter("id");
            if (id == null || !id.matches("[A-Za-z2-9]{10}")) { if (first) wv.loadUrl("file:///android_asset/app.html"); return; }
            if (first) wv.loadUrl("file:///android_asset/app.html#/add?id=" + id.toUpperCase());
            else wv.evaluateJavascript("window.onSirrnaLink&&window.onSirrnaLink('sirrna://add?id=" + id.toUpperCase() + "')", null);
        } else if (first) wv.loadUrl("file:///android_asset/app.html");
    }

    @Override
    protected void onNewIntent(Intent in) {
        super.onNewIntent(in);
        handleIntent(in, false);
    }

    @Override
    protected void onDestroy() {
        bridge.stop();
        Hub.inst = null;
        super.onDestroy();
    }

    /** Shows the load-failure dialog (main frame only, see the WebViewClient above). */
    private void showLoadError(String desc) {
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            if (loadErrorDialog != null && loadErrorDialog.isShowing()) return;
            loadErrorDialog = new AlertDialog.Builder(this)
                    .setTitle("تعذّر تحميل التطبيق")
                    .setMessage("حدث خطأ أثناء تحميل التطبيق: " + desc + "\nتحقق من التطبيق وحاول مرة أخرى.")
                    .setPositiveButton("إعادة المحاولة", (d, w) -> wv.loadUrl("file:///android_asset/app.html"))
                    // v27 #5: closing here used to leave the app on a blank page;
                    // finish the activity instead.
                    .setNegativeButton("إغلاق", (d, w) -> finish())
                    .setCancelable(false)
                    .create();
            loadErrorDialog.show();
        });
    }

    /** Asks the web app first (closes sheet/modal/call overlay, chat -> home). */
    private void askWebAppBack(Runnable onNotHandled) {
        wv.evaluateJavascript("(function(){try{return window.__back?window.__back():false}catch(e){return false}})()", value -> {
            if (!"true".equals(value)) {
                onNotHandled.run();
            }
        });
    }

    private void setEnabledBackFallback() {
        // home screen: normal system behaviour (leave the app)
        super.onBackPressed();
    }

    /**
     * Fallback for devices below API 33, where android.app.Activity has no
     * getOnBackPressedDispatcher(). On API 33+ the dispatcher callback
     * registered in onCreate handles the back press instead: this override
     * just forwards to it via super.onBackPressed().
     */
    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        askWebAppBack(() -> setEnabledBackFallback());
    }
}
