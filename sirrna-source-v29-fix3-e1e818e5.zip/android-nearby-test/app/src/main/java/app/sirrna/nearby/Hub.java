package app.sirrna.nearby;

import android.app.Activity;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.CancellationSignal;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.google.android.gms.common.GoogleApiAvailability;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Picks the transport: Nearby when Google Play services are valid, Bluetooth RFCOMM otherwise (or when forced). */
public class Hub {
    private final Activity act;
    private final WebView wv;
    private final SharedPreferences sp;
    private NearbyBridge nearby;
    private BtBridge bt;
    private String active = "";
    static volatile Hub inst;

    Hub(Activity a, WebView w) {
        act = a;
        wv = w;
        inst = this;
        sp = a.getSharedPreferences("hub", 0);
        bt = new BtBridge(a, w);
    }

    private int gms() {
        try {
            return GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(act);
        } catch (Throwable t) {
            return 1;
        }
    }

    private String mode() {
        return sp.getString("mode", "auto");
    }

    private boolean useNearby() {
        return !"bt".equals(mode()) && gms() == 0;
    }

    private NearbyBridge nb() {
        if (nearby == null) nearby = new NearbyBridge(act, wv);
        return nearby;
    }

    @JavascriptInterface
    public void setMode(String m) {
        sp.edit().putString("mode", "bt".equals(m) ? "bt" : "auto").apply();
    }

    @JavascriptInterface
    public String info() {
        try {
            JSONObject o = useNearby() ? new JSONObject(nb().info()) : new JSONObject();
            int g = gms();
            o.put("gms", g);
            o.put("mode", mode());
            o.put("transport", useNearby() ? "nearby" : "bt");
            if (!useNearby()) {
                o.put("sdk", Build.VERSION.SDK_INT);
                o.put("model", Build.MANUFACTURER + " " + Build.MODEL);
                o.put("bt", bt.btOn());
                o.put("hasBt", bt.hasBt());
                o.put("missing", new JSONArray(bt.missing()));
                o.put("locNeeded", false);
                o.put("wifi", true);
            }
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    @JavascriptInterface
    public void requestPerms() {
        if (useNearby()) { nb().requestPerms(); return; }
        List<String> m = new ArrayList<>();
        for (String p : bt.neededPerms()) if (act.checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) m.add(p);
        if (m.isEmpty()) { permissionsResult(); return; }
        act.runOnUiThread(() -> act.requestPermissions(m.toArray(new String[0]), 7));
    }

    void permissionsResult() {
        if (useNearby()) nb().permissionsResult();
        else {
            try {
                JSONObject o = new JSONObject();
                o.put("t", "perms");
                o.put("missing", bt.missing().toString());
                wv.post(() -> wv.evaluateJavascript("window.onNearby&&window.onNearby(" + o + ")", null));
            } catch (Exception ignored) {}
        }
    }

    @JavascriptInterface
    public void start(String name) {
        active = useNearby() ? "nearby" : "bt";
        if (active.equals("nearby")) nb().start(name); else bt.start(name);
    }

    /** Do-not-disturb window for push notifications (HH:MM). */
    @JavascriptInterface
    public void setDnd(boolean on, String from, String to) {
        sp.edit().putBoolean("dnd_on", on).putString("dnd_f", from == null ? "23:00" : from).putString("dnd_t", to == null ? "07:00" : to).apply();
    }

    @JavascriptInterface
    public void clearCache() {
        act.runOnUiThread(() -> { wv.clearCache(true); });
    }

    /** Local notification for a message that arrived while the app is in the background but still alive. canReply adds an inline reply box. */
    @JavascriptInterface
    public void notifyChat(String uid, String title, String text, boolean canReply) {
        Notif.showChat(act, uid, title, text, canReply);
    }

    /** In-app message tone on the notification stream (follows notification volume, respects silent/vibrate mode). */
    @JavascriptInterface
    public void playTone(String kind) {
        Sounds.playTone(act, kind);
    }

    /** Called by the notification reply box. False if the app screen is gone (the user must open the app). */
    static boolean deliverReply(String uid, String text) {
        final Hub h = inst;
        if (h == null) return false;
        final String js = "window.onQuickReply&&window.onQuickReply(" + JSONObject.quote(uid) + "," + JSONObject.quote(text) + ")";
        h.wv.post(() -> h.wv.evaluateJavascript(js, null));
        return true;
    }

    /** Saves a file (base64) into Downloads. Returns "ok" or an error text. */
    @JavascriptInterface
    public String saveFile(String name, String b64) {
        try {
            byte[] data = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
            if (Build.VERSION.SDK_INT >= 29) {
                android.content.ContentValues cv = new android.content.ContentValues();
                cv.put(android.provider.MediaStore.Downloads.DISPLAY_NAME, name);
                cv.put(android.provider.MediaStore.Downloads.MIME_TYPE, "application/octet-stream");
                cv.put(android.provider.MediaStore.Downloads.RELATIVE_PATH, "Download/Sirrna");
                android.net.Uri u = act.getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (u == null) return "fail";
                try (java.io.OutputStream o = act.getContentResolver().openOutputStream(u)) { o.write(data); }
                return "ok";
            }
            return "needs Android 10+";
        } catch (Exception e) { return "error: " + e.getMessage(); }
    }

    @JavascriptInterface
    public void connectTo(String addr) {
        bt.connectTo(addr);
    }

    @JavascriptInterface
    public void refreshPaired() {
        bt.paired();
    }

    @JavascriptInterface
    public void send(String d) {
        if ("nearby".equals(active)) nb().send(d); else bt.send(d);
    }

    @JavascriptInterface
    public void disconnect() {
        if ("nearby".equals(active)) nb().disconnect(); else bt.disconnect();
    }

    @JavascriptInterface
    public void stop() {
        if ("nearby".equals(active)) nb().stop(); else bt.stop();
    }

    @JavascriptInterface
    public void openBtSettings() {
        act.runOnUiThread(() -> act.startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)));
    }

    @JavascriptInterface
    public void enableBt() {
        act.runOnUiThread(() -> {
            try { act.startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); } catch (Exception ignored) {}
        });
    }

    /** Only meaningful for codes 2 (update), 3 (disabled), 18; shows Google's own dialog. */
    @JavascriptInterface
    public void fixGms() {
        act.runOnUiThread(() -> {
            try {
                int g = gms();
                Dialog d = GoogleApiAvailability.getInstance().getErrorDialog(act, g, 9000);
                if (d != null) d.show();
            } catch (Throwable ignored) {}
        });
    }

    // ---- closed-app notifications / ringing (all optional; safe when Firebase is not set up) ----
    @JavascriptInterface
    public void pushInit() {
        try {
            Notif.channels(act);
            Class.forName("app.sirrna.nearby.FcmHelper").getMethod("init", android.content.Context.class).invoke(null, act);
        } catch (Throwable t) { /* FCM not compiled in (no google-services.json) */ }
    }

    @JavascriptInterface
    public String pushToken() { return Notif.token(act); }

    @JavascriptInterface
    public String pushState() {
        boolean compiled = false;
        try { Class.forName("app.sirrna.nearby.FcmHelper"); compiled = true; } catch (Throwable t) { }
        android.app.NotificationManager nm = (android.app.NotificationManager) act.getSystemService(android.content.Context.NOTIFICATION_SERVICE);
        boolean notif = nm != null && nm.areNotificationsEnabled();
        boolean fsi = true;
        if (android.os.Build.VERSION.SDK_INT >= 34 && nm != null) fsi = nm.canUseFullScreenIntent();
        boolean bat = false;
        try { bat = ((android.os.PowerManager) act.getSystemService(android.content.Context.POWER_SERVICE)).isIgnoringBatteryOptimizations(act.getPackageName()); } catch (Throwable t) { }
        return "{\"fcm\":" + compiled + ",\"notif\":" + notif + ",\"fsi\":" + fsi + ",\"bat\":" + bat + ",\"tokerr\":" + JSONObject.quote(Notif.tokenErr(act)) + ",\"xiaomi\":" + "xiaomi".equalsIgnoreCase(android.os.Build.MANUFACTURER) + "}";
    }

    @JavascriptInterface
    public void pushSettings(String what) {
        act.runOnUiThread(() -> {
            try {
                android.content.Intent i;
                if ("notif".equals(what) && android.os.Build.VERSION.SDK_INT >= 33 && act.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    act.requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 10);
                    return;
                }
                if ("notif".equals(what)) {
                    i = new android.content.Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, act.getPackageName());
                } else if ("fsi".equals(what) && android.os.Build.VERSION.SDK_INT >= 34) {
                    i = new android.content.Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT", android.net.Uri.parse("package:" + act.getPackageName()));
                } else if ("bat".equals(what)) {
                    i = new android.content.Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                } else if ("autostart".equals(what)) {
                    i = new android.content.Intent().setComponent(new android.content.ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"));
                } else {
                    i = new android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + act.getPackageName()));
                }
                try { act.startActivity(i); } catch (Throwable t) {
                    act.startActivity(new android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + act.getPackageName())));
                }
            } catch (Throwable t) { }
        });
    }

    @JavascriptInterface
    public void clearCallNotification() { Notif.clearCall(act); }

    /** v19 #12: opt-in per-chat secure view. FLAG_SECURE blocks screenshots and screen
        recording on this phone while the chat is open. It is set only for chats the user
        enables it for (default off); cleared when leaving the chat. */
    @JavascriptInterface
    public void setSecure(boolean on) {
        act.runOnUiThread(() -> {
            try {
                if (on) act.getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
                else act.getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
            } catch (Throwable t) { }
        });
    }

    /** v19 #10: keep the screen on only while a call is live (online or Nearby). */
    @JavascriptInterface
    public void setKeepScreen(boolean on) {
        act.runOnUiThread(() -> {
            try {
                if (on) act.getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else act.getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            } catch (Throwable t) { }
        });
    }

    /** v19 #9: live location in the background. Starts LocationService (foreground, with a
        persistent notification) for the given number of minutes; the JS side still sends the
        updates via watchPosition while the WebView is alive, and the service keeps the app
        process alive so Android does not kill it when the screen goes off. */
    /** v19 #9: forward a background location fix to the web app (all active live shares). */
    static void liveLoc(double la, double lo) {
        final Hub h = inst;
        if (h == null) return;
        h.wv.post(() -> h.wv.evaluateJavascript("window.__liveLoc&&window.__liveLoc(" + la + "," + lo + ")", null));
    }

    @JavascriptInterface
    public void startLiveService(int minutes) {
        try {
            android.content.Intent i = new android.content.Intent(act, LocationService.class);
            i.putExtra("minutes", minutes);
            if (android.os.Build.VERSION.SDK_INT >= 26) act.startForegroundService(i);
            else act.startService(i);
        } catch (Throwable t) { }
    }

    /** v29-fix2: foreground service (microphone type) while a call is connected, so Android keeps
        the mic and audio running when the user leaves the app. Started only from the foreground. */
    @JavascriptInterface
    public void setCallService(boolean on) {
        try {
            android.content.Intent i = new android.content.Intent(act, CallService.class);
            if (on) {
                if (android.os.Build.VERSION.SDK_INT >= 26) act.startForegroundService(i);
                else act.startService(i);
            } else act.stopService(i);
        } catch (Throwable t) { }
    }

    @JavascriptInterface
    public void stopLiveService() {
        try { act.stopService(new android.content.Intent(act, LocationService.class)); } catch (Throwable t) { }
    }

    // ---- biometric app lock (framework BiometricPrompt, API 28+, no new dependency) ----
    private void postBioResult(boolean ok) {
        wv.post(() -> wv.evaluateJavascript("window.__bioResult&&window.__bioResult(" + ok + ")", null));
    }

    /** {"ok":true} when biometric auth can be used, else {"ok":false,"why":"..."}.
        why is one of: no_hardware, unavailable, none_enrolled, unsupported, error. */
    @JavascriptInterface
    public String bioAvailable() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                BiometricManager bm30 = act.getSystemService(android.hardware.biometrics.BiometricManager.class);
                int r = bm30 == null ? BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE : bm30.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG);
                switch (r) {
                    case BiometricManager.BIOMETRIC_SUCCESS:
                        return "{\"ok\":true}";
                    case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
                        return "{\"ok\":false,\"why\":\"no_hardware\"}";
                    case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
                        return "{\"ok\":false,\"why\":\"none_enrolled\"}";
                    case BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED:
                        return "{\"ok\":false,\"why\":\"unsupported\"}";
                    case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
                    default:
                        return "{\"ok\":false,\"why\":\"unavailable\"}";
                }
            }
            if (Build.VERSION.SDK_INT >= 29) {
                // No-arg canAuthenticate() is deprecated in API 30+, but on API 29
                // it is the only BiometricManager check available.
                BiometricManager bm29 = act.getSystemService(android.hardware.biometrics.BiometricManager.class);
                int r = bm29 == null ? BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE : bm29.canAuthenticate();
                switch (r) {
                    case BiometricManager.BIOMETRIC_SUCCESS:
                        return "{\"ok\":true}";
                    case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
                        return "{\"ok\":false,\"why\":\"no_hardware\"}";
                    case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
                        return "{\"ok\":false,\"why\":\"none_enrolled\"}";
                    case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
                    default:
                        return "{\"ok\":false,\"why\":\"unavailable\"}";
                }
            }
            if (Build.VERSION.SDK_INT >= 28) {
                // API 28 has BiometricPrompt but no BiometricManager, so the only
                // way to check enrollment is FingerprintManager (needs the
                // USE_FINGERPRINT permission, declared in the manifest).
                android.hardware.fingerprint.FingerprintManager fm =
                        (android.hardware.fingerprint.FingerprintManager) act.getSystemService(android.content.Context.FINGERPRINT_SERVICE);
                if (fm == null || !fm.isHardwareDetected()) return "{\"ok\":false,\"why\":\"no_hardware\"}";
                if (!fm.hasEnrolledFingerprints()) return "{\"ok\":false,\"why\":\"none_enrolled\"}";
                return "{\"ok\":true}";
            }
            return "{\"ok\":false,\"why\":\"unsupported\"}";
        } catch (Throwable t) {
            return "{\"ok\":false,\"why\":\"error\"}";
        }
    }

    /** Opens the system biometric prompt; reports back via window.__bioResult(true/false). */
    @JavascriptInterface
    public void bioAuth() {
        if (Build.VERSION.SDK_INT < 28) { postBioResult(false); return; }
        act.runOnUiThread(() -> {
            try {
                if (Build.VERSION.SDK_INT < 28) { postBioResult(false); return; }
                CancellationSignal cancel = new CancellationSignal();
                BiometricPrompt prompt = new BiometricPrompt.Builder(act)
                        .setTitle("فتح سرّنا")
                        .setNegativeButton("إلغاء", act.getMainExecutor(), (dialog, which) -> postBioResult(false))
                        .build();
                prompt.authenticate(cancel, act.getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                        postBioResult(true);
                    }

                    @Override
                    public void onAuthenticationFailed() {
                        // Wrong biometric: keep the prompt open, do not report yet.
                    }

                    @Override
                    public void onAuthenticationError(int errorCode, CharSequence errString) {
                        postBioResult(false);
                    }
                });
            } catch (Throwable t) {
                postBioResult(false);
            }
        });
    }
}
