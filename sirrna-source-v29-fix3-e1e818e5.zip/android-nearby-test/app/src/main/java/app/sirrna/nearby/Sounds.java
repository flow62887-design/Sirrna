package app.sirrna.nearby;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;

/** In-app message tones on the notification stream instead of the media stream.
    The WebView plays Web Audio through STREAM_MUSIC, so the volume keys changed media
    volume for message sounds. Here the same tones are generated as PCM and played with
    USAGE_NOTIFICATION, so they follow the notification volume and respect silent/vibrate. */
public class Sounds {
    // Same tones as TONES in app.html: pairs of frequency (Hz) and duration (seconds).
    private static final float[][] DING  = {{880, .12f}, {1320, .18f}};
    private static final float[][] POP   = {{500, .06f}, {700, .06f}};
    private static final float[][] CHIME = {{660, .15f}, {880, .15f}, {1100, .20f}};
    private static final float[][] DROP  = {{900, .08f}, {600, .08f}, {400, .12f}};
    private static final int SR = 22050;

    public static void playTone(final Context c, final String kind) {
        final float[][] notes = notes(kind);
        if (notes == null) return;
        AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        if (am != null) {
            int rm = am.getRingerMode();
            if (rm == AudioManager.RINGER_MODE_SILENT) return;
            if (rm == AudioManager.RINGER_MODE_VIBRATE) { vibrate(c); return; }
        }
        final short[] pcm = synth(notes);
        new Thread(() -> {
            AudioTrack t = null;
            try {
                t = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build())
                        .setAudioFormat(new AudioFormat.Builder()
                                .setSampleRate(SR)
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build())
                        .setBufferSizeInBytes(pcm.length * 2)
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .build();
                t.write(pcm, 0, pcm.length);
                t.play();
                Thread.sleep((long) (pcm.length * 1000.0 / SR) + 150);
            } catch (Throwable ignored) {
            } finally {
                if (t != null) try { t.stop(); } catch (Throwable ignored) {}
                if (t != null) try { t.release(); } catch (Throwable ignored) {}
            }
        }, "sirrna-tone").start();
    }

    private static float[][] notes(String kind) {
        if (kind == null) return null;
        switch (kind) {
            case "ding":  return DING;
            case "pop":   return POP;
            case "chime": return CHIME;
            case "drop":  return DROP;
            default:      return null;
        }
    }

    /** Sine notes with the same exponential decay as the Web Audio version (0.2 -> 0.001 over each note). */
    private static short[] synth(float[][] notes) {
        int total = 0;
        for (float[] n : notes) total += (int) (n[1] * SR);
        short[] pcm = new short[total];
        int pos = 0;
        for (float[] n : notes) {
            int len = (int) (n[1] * SR);
            double decay = Math.log(0.001 / 0.2) / len; // per-sample multiplier for 0.2 -> 0.001
            for (int i = 0; i < len; i++) {
                double g = 0.2 * Math.exp(decay * i);
                pcm[pos + i] = (short) (Math.sin(2 * Math.PI * n[0] * i / SR) * g * 32767);
            }
            pos += len;
        }
        return pcm;
    }

    private static void vibrate(Context c) {
        try {
            Vibrator v = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE));
            else v.vibrate(250);
        } catch (Throwable ignored) {}
    }
}
