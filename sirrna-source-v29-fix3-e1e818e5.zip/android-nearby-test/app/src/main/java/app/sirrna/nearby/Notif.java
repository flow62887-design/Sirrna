package app.sirrna.nearby;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

/** Notifications for closed-app messages and incoming calls. No dependency on Firebase: only the FCM service (optional source set) calls it. The push payload carries no message content, so these texts are generic. */
public class Notif {
    public static volatile boolean fg = false; // true while the app screen is visible (then the live connection already handles everything)
    static final String CH_CALL = "calls2", CH_MSG = "msgs", CH_QUIET = "msgs_quiet";

    static void channels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel call = new NotificationChannel(CH_CALL, "مكالمات واردة", NotificationManager.IMPORTANCE_HIGH);
        Uri ring = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        call.setSound(ring, new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
        call.enableVibration(true);
        call.setVibrationPattern(new long[]{0, 600, 400, 600, 400, 600});
        call.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(call);
        NotificationChannel msg = new NotificationChannel(CH_MSG, "رسايل جديدة", NotificationManager.IMPORTANCE_HIGH);
        msg.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        nm.createNotificationChannel(msg);
        NotificationChannel quiet = new NotificationChannel(CH_QUIET, "رسايل (وقت عدم الإزعاج)", NotificationManager.IMPORTANCE_LOW);
        quiet.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        nm.createNotificationChannel(quiet);
    }

    static boolean inDnd(Context c) {
        android.content.SharedPreferences sp = c.getSharedPreferences("hub", 0);
        if (!sp.getBoolean("dnd_on", false)) return false;
        try {
            String[] f = sp.getString("dnd_f", "23:00").split(":"), t = sp.getString("dnd_t", "07:00").split(":");
            int a = Integer.parseInt(f[0]) * 60 + Integer.parseInt(f[1]), b = Integer.parseInt(t[0]) * 60 + Integer.parseInt(t[1]);
            java.util.Calendar k = java.util.Calendar.getInstance();
            int m = k.get(java.util.Calendar.HOUR_OF_DAY) * 60 + k.get(java.util.Calendar.MINUTE);
            return a <= b ? (m >= a && m < b) : (m >= a || m < b);
        } catch (Exception e) { return false; }
    }

    public static void showChat(Context c, String uid, String title, String text, boolean canReply) {
        if (fg) return;
        channels(c);
        String ch = inDnd(c) ? CH_QUIET : CH_MSG;
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, ch) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.stat_notify_chat).setContentTitle(title).setContentText(text).setAutoCancel(true).setContentIntent(open(c, false, 1));
        if (canReply && Build.VERSION.SDK_INT >= 24) {
            android.app.RemoteInput ri = new android.app.RemoteInput.Builder("reply").setLabel("رد").build();
            Intent in = new Intent(c, ReplyReceiver.class).putExtra("uid", uid);
            int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
            PendingIntent pi = PendingIntent.getBroadcast(c, Math.abs(uid.hashCode()), in, fl);
            b.addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_send, "رد", pi).addRemoteInput(ri).build());
        }
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(Math.abs(uid.hashCode()), b.build());
    }

    private static PendingIntent open(Context c, boolean call, int code) {
        Intent i = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (call) i.putExtra("call", true);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getActivity(c, code, i, fl);
    }

    public static void showMsg(Context c) {
        if (fg) return;
        channels(c);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, inDnd(c) ? CH_QUIET : CH_MSG) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.stat_notify_chat).setContentTitle("سرّنا").setContentText("رسالة جديدة").setAutoCancel(true).setContentIntent(open(c, false, 1));
        if (Build.VERSION.SDK_INT >= 21) b.setVisibility(Notification.VISIBILITY_PRIVATE);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(1, b.build());
    }

    public static void showCall(Context c) {
        if (fg) return;
        channels(c);
        PendingIntent pi = open(c, true, 2);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CH_CALL) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.sym_action_call).setContentTitle("سرّنا").setContentText("مكالمة صوتية واردة").setAutoCancel(true)
                .setOngoing(true).setCategory(Notification.CATEGORY_CALL).setContentIntent(pi).setFullScreenIntent(pi, true);
        if (Build.VERSION.SDK_INT >= 26) b.setTimeoutAfter(45000);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(2, b.build());
    }

    public static void clearCall(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(2);
    }

    public static void saveToken(Context c, String t) {
        c.getSharedPreferences("hub", 0).edit().putString("fcm_token", t).apply();
    }

    public static void saveTokenErr(Context c, String e) {
        c.getSharedPreferences("hub", 0).edit().putString("fcm_token_err", e == null ? "" : e).apply();
    }

    public static String tokenErr(Context c) {
        return c.getSharedPreferences("hub", 0).getString("fcm_token_err", "");
    }

    public static String token(Context c) {
        return c.getSharedPreferences("hub", 0).getString("fcm_token", "");
    }
}
