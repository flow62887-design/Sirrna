package app.sirrna.nearby;

import android.content.Context;

import com.google.firebase.messaging.FirebaseMessaging;

/** Called by reflection from Hub so the main code never depends on Firebase classes. */
public class FcmHelper {
    public static void init(Context c) {
        final Context app = c.getApplicationContext();
        FirebaseMessaging.getInstance().getToken()
                .addOnSuccessListener(t -> { Notif.saveToken(app, t); Notif.saveTokenErr(app, ""); })
                .addOnFailureListener(e -> Notif.saveTokenErr(app, e.getClass().getSimpleName() + (e.getMessage() != null ? ": " + e.getMessage() : "")));
    }
}
