# صفحة إعادة توجيه الدعوات على Firebase Hosting

نفس صفحة `site/i.html` (بتحوّل `https://<project>.web.app/i.html?id=...` لـ `sirrna://add?id=...`،
و `?g=...&a=...` لـ `sirrna://join?...`)، بس جاهزة للنشر على Firebase Hosting بدل GitHub Pages.
الصفحة نفسها مبتشوفش أي رسايل ولا بيانات — بتفتح التطبيق بس.

## النشر (مرة واحدة)

1. نزّل Firebase CLI: `npm install -g firebase-tools` (محتاج Node).
2. `firebase login`
3. من مجلد `hosting/` ده: `firebase init hosting` — اختار المشروع `sirrna`، ولما يسأل عن public directory
   اكتب `.`، ولما يسأل عن single-page app اكتب `N`.
   (لو `firebase.json` موجود أصلاً زي هنا، ممكن تتخطى الخطوة دي.)
4. `firebase deploy --only hosting`
5. الرابط هيبقى `https://sirrna.web.app/i.html` (أو الدومين اللي يطلع لك في الـ deploy).

## الربط بالتطبيق

في سرّنا: الإعدادات ← "رابط صفحة الدعوة" ← الصق `https://sirrna.web.app`
(من غير `/i.html`). من بعدها زر "مشاركة رابط الدعوة" بيبعت روابط https بتتفتح من أي شات.
لو الخانة فاضية، الروابط بتفضل `sirrna://` زي قبل.

## ملحوظة

- زر "تنزيل الـ APK" في الصفحة مخفي لحد ما تحط رابط APK مباشر في `APK_URL` جوه `i.html`.
- الصفحة دي **غير مجرّبة على موبايل حقيقي** بعد النشر — جرّب رابط دعوة من متصفح أندرويد بعد الـ deploy.
